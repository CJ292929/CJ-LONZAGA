import { createContext, useContext } from "react";
import { trpc } from "@/lib/trpc";
import { useQueryClient } from "@tanstack/react-query";

const BRANCH_TOKEN_KEY = "henlin_branch_token";

export interface BranchSession {
  branchId: number;
  username: string;
  role: string;
  accountId: number;
}

interface BranchSessionContextValue {
  session: BranchSession | null;
  loading: boolean;
  logout: () => void;
}

const BranchSessionContext = createContext<BranchSessionContextValue>({
  session: null,
  loading: true,
  logout: () => {},
});

export function BranchSessionProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();

  // This query will automatically pick up the token from localStorage via the
  // X-Branch-Token header injected in main.tsx
  const { data: session, isLoading } = trpc.branchAuth.me.useQuery(undefined, {
    retry: false,
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: true,
  });

  const utils = trpc.useUtils();
  const logoutMutation = trpc.branchAuth.logout.useMutation({
    onSuccess: () => {
      // Remove token from localStorage
      localStorage.removeItem(BRANCH_TOKEN_KEY);
      // Invalidate all queries so the header is no longer sent
      queryClient.clear();
      utils.branchAuth.me.invalidate();
    },
  });

  return (
    <BranchSessionContext.Provider
      value={{
        session: session ?? null,
        loading: isLoading,
        logout: () => logoutMutation.mutate(),
      }}
    >
      {children}
    </BranchSessionContext.Provider>
  );
}

export function useBranchSession() {
  return useContext(BranchSessionContext);
}

export { BRANCH_TOKEN_KEY };
