import React, { createContext, useContext, useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";

interface Branch {
  id: number;
  name: string;
  location: string | null;
  isActive: boolean;
}

interface BranchContextType {
  branches: Branch[];
  selectedBranchId: number | null; // null = all branches
  selectedBranch: Branch | null;
  setSelectedBranchId: (id: number | null) => void;
  isLoading: boolean;
}

const BranchContext = createContext<BranchContextType>({
  branches: [],
  selectedBranchId: null,
  selectedBranch: null,
  setSelectedBranchId: () => {},
  isLoading: true,
});

export function BranchProvider({ children }: { children: React.ReactNode }) {
  const [selectedBranchId, setSelectedBranchId] = useState<number | null>(null);
  const { data: branches = [], isLoading } = trpc.branches.list.useQuery();

  const selectedBranch = selectedBranchId
    ? branches.find((b) => b.id === selectedBranchId) ?? null
    : null;

  // Persist selection
  useEffect(() => {
    const saved = localStorage.getItem("henlin_branch");
    if (saved) setSelectedBranchId(saved === "null" ? null : parseInt(saved));
  }, []);

  const handleSetBranch = (id: number | null) => {
    setSelectedBranchId(id);
    localStorage.setItem("henlin_branch", id === null ? "null" : String(id));
  };

  return (
    <BranchContext.Provider
      value={{ branches, selectedBranchId, selectedBranch, setSelectedBranchId: handleSetBranch, isLoading }}
    >
      {children}
    </BranchContext.Provider>
  );
}

export function useBranch() {
  return useContext(BranchContext);
}
