import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { BranchProvider } from "./contexts/BranchContext";
import { BranchSessionProvider, useBranchSession } from "./contexts/BranchSessionContext";
import HenlinLayout from "./components/HenlinLayout";
import BranchLayout from "./components/BranchLayout";
import { useAuth } from "./_core/hooks/useAuth";
import { getLoginUrl } from "./const";
import { Loader2 } from "lucide-react";

// Admin / Super Admin Pages
import Dashboard from "./pages/Dashboard";
import Branches from "./pages/Branches";
import Inventory from "./pages/Inventory";
import Sales from "./pages/Sales";
import TimeRecords from "./pages/TimeRecords";
import Shifts from "./pages/Shifts";
import StaffPage from "./pages/Staff";
import Reports from "./pages/Reports";
import BranchAccounts from "./pages/BranchAccounts";

// Branch Portal Pages
import BranchLogin from "./pages/BranchLogin";
import BranchDashboard from "./pages/branch/BranchDashboard";
import BranchInventory from "./pages/branch/BranchInventory";
import BranchSales from "./pages/branch/BranchSales";
import BranchTimeRecords from "./pages/branch/BranchTimeRecords";
import BranchShifts from "./pages/branch/BranchShifts";
import BranchStaff from "./pages/branch/BranchStaff";
import BranchReports from "./pages/branch/BranchReports";

const LOGO_URL = "/manus-storage/henlin-logo_a8ae97b6.jpg";

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="animate-spin w-8 h-8 mx-auto text-[var(--henlin-red)] mb-3" />
          <p className="text-sm text-muted-foreground">Loading Henlin Operations Hub...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1a0a0a] via-[#2d1010] to-[#1a0a0a]">
        <div className="text-center max-w-sm mx-auto px-6">
          <div className="w-20 h-20 rounded-2xl bg-white/10 flex items-center justify-center mx-auto mb-5 overflow-hidden border-2 border-white/20">
            <img src={LOGO_URL} alt="Henlin" className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <h1 className="text-3xl font-black text-white mb-1 tracking-wider">HENLIN</h1>
          <p className="text-sm text-white/60 mb-8">Franchise Operations Hub</p>
          <a
            href={getLoginUrl()}
            className="inline-flex items-center justify-center w-full px-6 py-3 bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white font-semibold rounded-xl transition-colors shadow-lg"
          >
            Super Admin Sign In
          </a>
          <div className="mt-4 border-t border-white/10 pt-4">
            <p className="text-xs text-white/40 mb-3">Branch staff? Use the branch portal:</p>
            <a
              href="/branch"
              className="inline-flex items-center justify-center w-full px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white/80 font-medium rounded-xl transition-colors text-sm border border-white/20"
            >
              Branch Login →
            </a>
          </div>
          <p className="text-xs text-white/30 mt-6">
            Inventory · Sales · Staff · Reports
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

function AdminRoutes() {
  return (
    <BranchProvider>
      <HenlinLayout>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/branches" component={Branches} />
          <Route path="/inventory" component={Inventory} />
          <Route path="/sales" component={Sales} />
          <Route path="/time-records" component={TimeRecords} />
          <Route path="/shifts" component={Shifts} />
          <Route path="/staff" component={StaffPage} />
          <Route path="/reports" component={Reports} />
          <Route path="/branch-accounts" component={BranchAccounts} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </HenlinLayout>
    </BranchProvider>
  );
}

function BranchPortalRoutes() {
  const { session, loading } = useBranchSession();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="animate-spin w-8 h-8 text-[var(--henlin-red)]" />
      </div>
    );
  }
  if (!session) {
    return <BranchLogin onSuccess={() => navigate("/branch")} />;
  }

  return (
    <BranchLayout>
      <Switch>
        <Route path="/branch" component={BranchDashboard} />
        <Route path="/branch/inventory" component={BranchInventory} />
        <Route path="/branch/sales" component={BranchSales} />
        <Route path="/branch/time-records" component={BranchTimeRecords} />
        <Route path="/branch/shifts" component={BranchShifts} />
        <Route path="/branch/staff" component={BranchStaff} />
        <Route path="/branch/reports" component={BranchReports} />
        <Route component={NotFound} />
      </Switch>
    </BranchLayout>
  );
}

function Router() {
  const [location] = useLocation();
  // Only treat as branch portal if path is exactly /branch or starts with /branch/
  const isBranchRoute = location === "/branch" || location.startsWith("/branch/");

  if (isBranchRoute) {
    return (
      <BranchSessionProvider>
        <BranchPortalRoutes />
      </BranchSessionProvider>
    );
  }

  return (
    <AuthGuard>
      <AdminRoutes />
    </AuthGuard>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
