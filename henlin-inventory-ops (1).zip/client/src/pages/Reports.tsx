import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Download, FileText, BarChart3, Package, Clock, Calendar } from "lucide-react";

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

function getPHTDateStr(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

function dateToTs(dateStr: string, endOfDay = false) {
  const d = new Date(dateStr + "T00:00:00+08:00");
  return endOfDay ? d.getTime() + 86400000 - 1 : d.getTime();
}

function exportCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const csv = [headers.join(","), ...rows.map((r) => r.map((c) => `"${c}"`).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  toast.success(`${filename} downloaded`);
}

export default function Reports() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const activeBranchId = selectedBranchId ?? null;
  const activeBranchName = selectedBranch?.name ?? "All Branches";

  const [startDate, setStartDate] = useState(getPHTDateStr(-6));
  const [endDate, setEndDate] = useState(getPHTDateStr());
  const [reportBranchId, setReportBranchId] = useState<string>(activeBranchId ? String(activeBranchId) : "all");

  const startTs = useMemo(() => dateToTs(startDate), [startDate]);
  const endTs = useMemo(() => dateToTs(endDate, true), [endDate]);
  const branchIdForQuery = reportBranchId === "all" ? null : parseInt(reportBranchId);

  const { data: salesReport, isLoading: loadingSales } = trpc.reports.salesReport.useQuery({
    branchId: branchIdForQuery,
    startTs,
    endTs,
  });

  // Inventory report requires a specific branch; default to first branch when "all" is selected
  const invBranchId = branchIdForQuery ?? branches[0]?.id ?? 1;
  const { data: invReport, isLoading: loadingInv } = trpc.reports.inventoryReport.useQuery(
    { branchId: invBranchId },
    { enabled: !!invBranchId }
  );
  const invBranchName = branches.find((b) => b.id === invBranchId)?.name ?? "Branch";

  const { data: attendanceRecords = [], isLoading: loadingAtt } = trpc.reports.attendanceReport.useQuery({
    branchId: branchIdForQuery,
    startDate,
    endDate,
  });

  function exportSalesReport() {
    if (!salesReport) return;
    exportCSV(
      `henlin_sales_${startDate}_${endDate}.csv`,
      ["Branch", "Total Sales", "Transactions", "Cash", "GCash", "Card"],
      salesReport.summary.map((s) => [
        s.branchName ?? "",
        Number(s.totalSales).toFixed(2),
        s.transactionCount,
        Number(s.cashSales).toFixed(2),
        Number(s.gcashSales).toFixed(2),
        Number(s.cardSales).toFixed(2),
      ])
    );
  }

  function exportInventoryReport() {
    if (!invReport) return;
    exportCSV(
      `henlin_inventory_${new Date().toLocaleDateString("en-CA")}.csv`,
      ["Product", "Category", "Unit", "Current Stock", "Reorder Level", "Status"],
      invReport.inventory.map((i) => [
        i.productName,
        i.category ?? "",
        i.unit ?? "",
        parseFloat(i.quantity as string).toFixed(0),
        parseFloat(i.reorderLevel as string).toFixed(0),
        parseFloat(i.quantity as string) <= parseFloat(i.reorderLevel as string) ? "LOW STOCK" : "OK",
      ])
    );
  }

  function exportAttendanceReport() {
    exportCSV(
      `henlin_attendance_${startDate}_${endDate}.csv`,
      ["Staff", "Branch", "Date", "Clock In", "Clock Out", "Hours", "Status"],
      attendanceRecords.map((r) => [
        r.staffName,
        r.branchName,
        r.date,
        r.clockIn ? new Date(r.clockIn).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "",
        r.clockOut ? new Date(r.clockOut).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "",
        r.hoursRendered ? parseFloat(r.hoursRendered as string).toFixed(2) : "0",
        r.clockIn && r.clockOut ? "Complete" : r.clockIn ? "In Progress" : "Absent",
      ])
    );
  }

  const totalSales = salesReport?.summary.reduce((s, b) => s + Number(b.totalSales || 0), 0) ?? 0;
  const totalTx = salesReport?.summary.reduce((s, b) => s + Number(b.transactionCount || 0), 0) ?? 0;

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold">Reports</h2>
          <p className="text-sm text-muted-foreground">Generate and export operational reports</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-end">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Branch</label>
              <Select value={reportBranchId} onValueChange={setReportBranchId}>
                <SelectTrigger className="w-44 h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Branches</SelectItem>
                  {branches.map((b) => <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">Start Date</label>
              <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-36 h-9 text-sm" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1">End Date</label>
              <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-36 h-9 text-sm" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="sales">
        <TabsList className="grid grid-cols-4 w-full max-w-xl">
          <TabsTrigger value="sales" className="text-xs"><BarChart3 size={12} className="mr-1" />Sales</TabsTrigger>
          <TabsTrigger value="inventory" className="text-xs"><Package size={12} className="mr-1" />Inventory</TabsTrigger>
          <TabsTrigger value="attendance" className="text-xs"><Clock size={12} className="mr-1" />Attendance</TabsTrigger>
          <TabsTrigger value="shift" className="text-xs"><Calendar size={12} className="mr-1" />Shift</TabsTrigger>
        </TabsList>

        {/* Sales Report */}
        <TabsContent value="sales" className="space-y-4 mt-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Sales Report</h3>
              <p className="text-xs text-muted-foreground">{startDate} to {endDate}</p>
            </div>
            <Button variant="outline" size="sm" onClick={exportSalesReport} disabled={!salesReport}>
              <Download size={13} className="mr-1.5" /> Export CSV
            </Button>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Card><CardContent className="p-4 text-center">
              <div className="text-xl font-bold text-[var(--henlin-red)]">{formatPHP(totalSales)}</div>
              <div className="text-xs text-muted-foreground">Total Revenue</div>
            </CardContent></Card>
            <Card><CardContent className="p-4 text-center">
              <div className="text-xl font-bold">{totalTx}</div>
              <div className="text-xs text-muted-foreground">Transactions</div>
            </CardContent></Card>
            <Card><CardContent className="p-4 text-center">
              <div className="text-xl font-bold">{totalTx > 0 ? formatPHP(totalSales / totalTx) : "—"}</div>
              <div className="text-xs text-muted-foreground">Avg per Transaction</div>
            </CardContent></Card>
            <Card><CardContent className="p-4 text-center">
              <div className="text-xl font-bold">{salesReport?.summary.length ?? 0}</div>
              <div className="text-xs text-muted-foreground">Active Branches</div>
            </CardContent></Card>
          </div>

          {/* Branch Breakdown */}
          {salesReport?.summary && salesReport.summary.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">Sales by Branch</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={salesReport.summary.map((s) => ({ name: s.branchName?.split(" ").slice(0, 2).join(" ") ?? "", sales: Number(s.totalSales || 0) }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-20} textAnchor="end" />
                    <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `₱${(v / 1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v: number) => formatPHP(v)} />
                    <Bar dataKey="sales" fill="#C62828" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Top Products */}
          {salesReport?.topProducts && salesReport.topProducts.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">Top Products</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">Product</TableHead>
                      <TableHead className="text-xs text-right">Qty Sold</TableHead>
                      <TableHead className="text-xs text-right">Revenue</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {salesReport.topProducts.map((p, i) => (
                      <TableRow key={p.productId}>
                        <TableCell className="text-sm">
                          <span className="text-muted-foreground mr-2 text-xs">#{i + 1}</span>
                          {p.productName}
                        </TableCell>
                        <TableCell className="text-right text-sm">{Number(p.totalQty).toFixed(0)}</TableCell>
                        <TableCell className="text-right font-semibold text-sm">{formatPHP(Number(p.totalRevenue))}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* Transactions Table */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">All Transactions</CardTitle>
                <span className="text-xs text-muted-foreground">{salesReport?.transactions.length ?? 0} records</span>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-80 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">#</TableHead>
                      <TableHead className="text-xs">Branch</TableHead>
                      <TableHead className="text-xs">Date/Time</TableHead>
                      <TableHead className="text-xs">Cashier</TableHead>
                      <TableHead className="text-xs">Payment</TableHead>
                      <TableHead className="text-xs text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loadingSales
                      ? Array(5).fill(0).map((_, i) => <TableRow key={i}>{Array(6).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                      : salesReport?.transactions.map((s) => (
                          <TableRow key={s.id}>
                            <TableCell className="text-xs font-mono">#{s.id}</TableCell>
                            <TableCell className="text-xs">{s.branchName}</TableCell>
                            <TableCell className="text-xs">{new Date(s.timestamp).toLocaleString("en-PH", { timeZone: "Asia/Manila", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</TableCell>
                            <TableCell className="text-xs">{s.cashierName ?? "—"}</TableCell>
                            <TableCell><span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${s.paymentType === "cash" ? "bg-green-100 text-green-700" : s.paymentType === "GCash" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"}`}>{s.paymentType}</span></TableCell>
                            <TableCell className="text-right font-semibold text-sm">{formatPHP(Number(s.totalAmount))}</TableCell>
                          </TableRow>
                        ))}
                    {!loadingSales && (!salesReport?.transactions || salesReport.transactions.length === 0) && (
                      <TableRow><TableCell colSpan={6} className="text-center py-6 text-muted-foreground text-sm">No transactions in this period</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Inventory Report */}
        <TabsContent value="inventory" className="space-y-4 mt-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Inventory Report</h3>
              <p className="text-xs text-muted-foreground">
                Showing: <span className="font-medium text-foreground">{invBranchName}</span>
                {reportBranchId === "all" && <span className="ml-1 text-orange-600">(select a specific branch for full accuracy)</span>}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={exportInventoryReport} disabled={!invReport}>
              <Download size={13} className="mr-1.5" /> Export CSV
            </Button>
          </div>

          {invReport?.lowStockItems && invReport.lowStockItems.length > 0 && (
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="text-sm font-medium text-orange-800">{invReport.lowStockItems.length} items below reorder level</p>
              <p className="text-xs text-orange-700 mt-0.5">{invReport.lowStockItems.map((i) => i.productName).join(", ")}</p>
            </div>
          )}

          <Card>
            <CardContent className="p-0">
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">Product</TableHead>
                      <TableHead className="text-xs">Category</TableHead>
                      <TableHead className="text-xs text-right">Stock</TableHead>
                      <TableHead className="text-xs text-right">Reorder At</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loadingInv
                      ? Array(8).fill(0).map((_, i) => <TableRow key={i}>{Array(5).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                      : invReport?.inventory.map((item) => {
                          const qty = parseFloat(item.quantity as string);
                          const reorder = parseFloat(item.reorderLevel as string);
                          const isLow = qty <= reorder;
                          return (
                            <TableRow key={item.id} className={isLow ? "bg-orange-50/50" : ""}>
                              <TableCell className="font-medium text-sm">{item.productName}</TableCell>
                              <TableCell className="text-xs text-muted-foreground">{item.category ?? "—"}</TableCell>
                              <TableCell className={`text-right font-semibold text-sm ${isLow ? "text-orange-600" : ""}`}>{qty.toFixed(0)} {item.unit}</TableCell>
                              <TableCell className="text-right text-xs text-muted-foreground">{reorder.toFixed(0)}</TableCell>
                              <TableCell><span className={isLow ? "badge-warning" : "badge-success"}>{isLow ? "Low" : "OK"}</span></TableCell>
                            </TableRow>
                          );
                        })}
                    {!loadingInv && (!invReport?.inventory || invReport.inventory.length === 0) && (
                      <TableRow><TableCell colSpan={5} className="text-center py-6 text-muted-foreground text-sm">No inventory data</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Attendance Report */}
        <TabsContent value="attendance" className="space-y-4 mt-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Staff Attendance Report</h3>
              <p className="text-xs text-muted-foreground">{startDate} to {endDate}</p>
            </div>
            <Button variant="outline" size="sm" onClick={exportAttendanceReport}>
              <Download size={13} className="mr-1.5" /> Export CSV
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">Staff</TableHead>
                      <TableHead className="text-xs">Branch</TableHead>
                      <TableHead className="text-xs">Date</TableHead>
                      <TableHead className="text-xs">Clock In</TableHead>
                      <TableHead className="text-xs">Clock Out</TableHead>
                      <TableHead className="text-xs text-right">Hours</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loadingAtt
                      ? Array(6).fill(0).map((_, i) => <TableRow key={i}>{Array(7).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}</TableRow>)
                      : attendanceRecords.map((r) => (
                          <TableRow key={r.id}>
                            <TableCell className="font-medium text-sm">{r.staffName}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{r.branchName}</TableCell>
                            <TableCell className="text-xs">{r.date}</TableCell>
                            <TableCell className="text-xs">{r.clockIn ? new Date(r.clockIn).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" }) : "—"}</TableCell>
                            <TableCell className="text-xs">{r.clockOut ? new Date(r.clockOut).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" }) : "—"}</TableCell>
                            <TableCell className="text-right font-semibold text-sm">{r.hoursRendered ? parseFloat(r.hoursRendered as string).toFixed(2) + "h" : "—"}</TableCell>
                            <TableCell>
                              <span className={
                                !r.clockIn ? "badge-danger" :
                                !r.clockOut ? "badge-success" :
                                parseFloat(r.hoursRendered as string || "0") > 9 ? "badge-warning" :
                                "badge-success"
                              }>
                                {!r.clockIn ? "Absent" : !r.clockOut ? "On Duty" : parseFloat(r.hoursRendered as string || "0") > 9 ? "Overtime" : "Complete"}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                    {!loadingAtt && attendanceRecords.length === 0 && (
                      <TableRow><TableCell colSpan={7} className="text-center py-6 text-muted-foreground text-sm">No attendance records in this period</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Shift Summary */}
        <TabsContent value="shift" className="space-y-4 mt-4">
          <div>
            <h3 className="font-semibold">Shift Summary Report</h3>
            <p className="text-xs text-muted-foreground">Select a branch and shift to view the combined summary</p>
          </div>
          <div className="p-8 text-center text-muted-foreground border-2 border-dashed border-border rounded-lg">
            <Calendar size={32} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">Select a specific branch and shift from the Shifts page to view its summary.</p>
            <p className="text-xs mt-1">Shift summaries include: sales totals, inventory consumed, and staff on duty.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
