import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Download, BarChart3, Package, Clock, AlertTriangle } from "lucide-react";

function getPHTDateStr(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

function downloadCSV(filename: string, rows: string[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export default function BranchReports() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;

  const [startDate, setStartDate] = useState(getPHTDateStr(-6));
  const [endDate, setEndDate] = useState(getPHTDateStr());

  const startTs = useMemo(() => new Date(startDate + "T00:00:00+08:00").getTime(), [startDate]);
  const endTs = useMemo(() => new Date(endDate + "T23:59:59+08:00").getTime(), [endDate]);

  const { data: branches = [] } = trpc.branches.list.useQuery();
  const branchName = branches.find((b) => b.id === branchId)?.name ?? "Branch";

  const { data: salesReport } = trpc.reports.salesReport.useQuery({ branchId, startTs, endTs }, { enabled: !!branchId });
  const { data: inventoryReport } = trpc.reports.inventoryReport.useQuery({ branchId }, { enabled: !!branchId });
  const { data: attendanceReport = [] } = trpc.reports.attendanceReport.useQuery(
    { branchId, startDate, endDate },
    { enabled: !!branchId }
  );

  // Daily sales chart
  const dailyData = useMemo(() => {
    const map: Record<string, number> = {};
    (salesReport?.transactions ?? []).forEach((t) => {
      const d = new Date(t.timestamp).toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
      map[d] = (map[d] ?? 0) + Number(t.totalAmount);
    });
    return Object.entries(map)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, sales]) => ({
        day: new Date(date + "T12:00:00+08:00").toLocaleDateString("en-PH", { month: "short", day: "numeric" }),
        sales,
      }));
  }, [salesReport]);

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-xl font-bold">Reports</h1>
          <p className="text-sm text-muted-foreground">{branchName}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)}
            className="border border-border rounded-md px-3 py-1.5 text-sm bg-background" />
          <span className="text-muted-foreground self-center text-sm">to</span>
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)}
            className="border border-border rounded-md px-3 py-1.5 text-sm bg-background" />
        </div>
      </div>

      <Tabs defaultValue="sales">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="sales" className="text-xs"><BarChart3 size={13} className="mr-1" />Sales</TabsTrigger>
          <TabsTrigger value="inventory" className="text-xs"><Package size={13} className="mr-1" />Inventory</TabsTrigger>
          <TabsTrigger value="attendance" className="text-xs"><Clock size={13} className="mr-1" />Attendance</TabsTrigger>
        </TabsList>

        {/* Sales Tab */}
        <TabsContent value="sales" className="space-y-4 mt-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Total Revenue", value: formatPHP(Number(salesReport?.summary?.[0]?.totalSales ?? 0)) },
              { label: "Transactions", value: salesReport?.summary?.[0]?.transactionCount ?? 0 },
              { label: "Avg Sale", value: formatPHP(salesReport?.summary?.[0]?.transactionCount ? Number(salesReport.summary[0].totalSales) / Number(salesReport.summary[0].transactionCount) : 0) },
              { label: "Top Product", value: salesReport?.topProducts?.[0]?.productName ?? "—" },
            ].map((s) => (
              <Card key={s.label}><CardContent className="p-3">
                <div className="text-xs text-muted-foreground mb-1">{s.label}</div>
                <div className="font-bold text-sm truncate">{s.value}</div>
              </CardContent></Card>
            ))}
          </div>

          {dailyData.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm">Daily Sales</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={dailyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `₱${(v / 1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v: number) => formatPHP(v)} />
                    <Bar dataKey="sales" fill="#C62828" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          <Button variant="outline" size="sm" className="text-xs"
            onClick={() => {
              const rows = [
                ["Date/Time", "Cashier", "Payment", "Amount"],
                ...(salesReport?.transactions ?? []).map((t) => [
                  new Date(t.timestamp).toLocaleString("en-PH", { timeZone: "Asia/Manila" }),
                  t.cashierName ?? "", t.paymentType, String(t.totalAmount),
                ]),
              ];
              downloadCSV(`${branchName}_sales_${startDate}_${endDate}.csv`, rows);
              toast.success("Sales report downloaded");
            }}>
            <Download size={13} className="mr-1.5" /> Export Sales CSV
          </Button>
        </TabsContent>

        {/* Inventory Tab */}
        <TabsContent value="inventory" className="space-y-4 mt-4">
          {(inventoryReport?.lowStockItems?.length ?? 0) > 0 && (
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-3">
                <div className="flex items-center gap-2 text-orange-700 text-sm font-semibold mb-2">
                  <AlertTriangle size={14} /> {inventoryReport!.lowStockItems.length} Low Stock Items
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {inventoryReport!.lowStockItems.map((i) => (
                    <Badge key={i.id} variant="outline" className="text-xs border-orange-300 text-orange-700">
                      {i.productName} ({parseFloat(i.quantity as string).toFixed(0)})
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Product</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Category</th>
                    <th className="text-right px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Stock</th>
                    <th className="text-right px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Reorder</th>
                    <th className="text-center px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {(inventoryReport?.inventory ?? []).map((i) => {
                    const qty = parseFloat(i.quantity as string);
                    const reorder = parseFloat(i.reorderLevel as string);
                    const isLow = qty <= reorder;
                    return (
                      <tr key={i.id} className={isLow ? "bg-orange-50/50" : ""}>
                        <td className="px-4 py-2.5 font-medium text-sm">{i.productName}</td>
                        <td className="px-4 py-2.5 text-xs text-muted-foreground">{i.category ?? "—"}</td>
                        <td className={`px-4 py-2.5 text-right font-bold ${isLow ? "text-orange-600" : "text-green-700"}`}>{qty.toFixed(0)}</td>
                        <td className="px-4 py-2.5 text-right text-muted-foreground text-sm">{reorder.toFixed(0)}</td>
                        <td className="px-4 py-2.5 text-center">
                          <Badge className={isLow ? "bg-orange-100 text-orange-700 text-[10px]" : "bg-green-100 text-green-700 text-[10px]"}>
                            {isLow ? "Low" : "OK"}
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          <Button variant="outline" size="sm" className="text-xs"
            onClick={() => {
              const rows = [
                ["Product", "Category", "Unit", "Stock", "Reorder Level", "Status"],
                ...(inventoryReport?.inventory ?? []).map((i) => {
                  const qty = parseFloat(i.quantity as string);
                  const reorder = parseFloat(i.reorderLevel as string);
                  return [i.productName, i.category ?? "", i.unit ?? "", qty.toFixed(0), reorder.toFixed(0), qty <= reorder ? "Low" : "OK"];
                }),
              ];
              downloadCSV(`${branchName}_inventory_${new Date().toLocaleDateString("en-CA")}.csv`, rows);
              toast.success("Inventory report downloaded");
            }}>
            <Download size={13} className="mr-1.5" /> Export Inventory CSV
          </Button>
        </TabsContent>

        {/* Attendance Tab */}
        <TabsContent value="attendance" className="space-y-4 mt-4">
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Staff</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Date</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Clock In</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Clock Out</th>
                    <th className="text-right px-4 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Hours</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {attendanceReport.length === 0 ? (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No attendance records in this period</td></tr>
                  ) : attendanceReport.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      <td className="px-4 py-2.5 font-medium">{r.staffName}</td>
                      <td className="px-4 py-2.5 text-muted-foreground text-xs">{r.date}</td>
                      <td className="px-4 py-2.5 text-xs">{r.clockIn ? new Date(r.clockIn).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" }) : "—"}</td>
                      <td className="px-4 py-2.5 text-xs">{r.clockOut ? new Date(r.clockOut).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" }) : "—"}</td>
                      <td className="px-4 py-2.5 text-right font-semibold">{r.hoursRendered ? `${parseFloat(r.hoursRendered as string).toFixed(1)}h` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Button variant="outline" size="sm" className="text-xs"
            onClick={() => {
              const rows = [
                ["Staff", "Date", "Clock In", "Clock Out", "Hours"],
                ...attendanceReport.map((r) => [
                  r.staffName ?? "",
                  r.date ?? "",
                  r.clockIn ? new Date(r.clockIn).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "",
                  r.clockOut ? new Date(r.clockOut).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "",
                  r.hoursRendered ? parseFloat(r.hoursRendered as string).toFixed(1) : "",
                ]),
              ];
              downloadCSV(`${branchName}_attendance_${startDate}_${endDate}.csv`, rows);
              toast.success("Attendance report downloaded");
            }}>
            <Download size={13} className="mr-1.5" /> Export Attendance CSV
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  );
}
