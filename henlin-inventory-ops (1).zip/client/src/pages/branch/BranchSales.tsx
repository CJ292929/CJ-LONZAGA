import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ShoppingCart, Search, Plus, Minus, Trash2, CreditCard, Banknote, Smartphone, CheckCircle } from "lucide-react";
import { StripeCardModal } from "@/components/StripeCardModal";

type PaymentType = "cash" | "GCash" | "card";
interface CartItem { productId: number; productName: string; quantity: number; unitPrice: number; subtotal: number; unit: string; }

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

export default function BranchSales() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cashierName, setCashierName] = useState("");
  const [paymentType, setPaymentType] = useState<PaymentType>("cash");
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const [lastTotal, setLastTotal] = useState(0);

  // Stripe card payment state
  const [stripeClientSecret, setStripeClientSecret] = useState<string | null>(null);
  const [stripeOpen, setStripeOpen] = useState(false);
  const [pendingSaleItems, setPendingSaleItems] = useState<CartItem[]>([]);

  const utils = trpc.useUtils();
  const { data: inventory = [] } = trpc.inventory.getByBranch.useQuery({ branchId }, { enabled: !!branchId });

  const todayStart = useMemo(() => {
    const d = new Date(new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" }) + "T00:00:00+08:00");
    return d.getTime();
  }, []);
  const todayEnd = useMemo(() => todayStart + 86400000 - 1, [todayStart]);

  const { data: todaySales = [] } = trpc.sales.list.useQuery(
    { branchId, startTs: todayStart, endTs: todayEnd, limit: 50 },
    { enabled: !!branchId }
  );

  // Stripe PaymentIntent creation
  const createPaymentIntent = trpc.stripe.createPaymentIntent.useMutation({
    onSuccess: (data) => {
      if (data.clientSecret) {
        setStripeClientSecret(data.clientSecret);
        setStripeOpen(true);
        setCheckoutOpen(false);
      }
    },
    onError: (e) => toast.error("Stripe error: " + e.message),
  });

  const createSale = trpc.sales.create.useMutation({
    onSuccess: () => {
      setLastTotal(pendingSaleItems.length > 0
        ? pendingSaleItems.reduce((s, i) => s + i.subtotal, 0)
        : cart.reduce((s, i) => s + i.subtotal, 0)
      );
      setCart([]);
      setPendingSaleItems([]);
      setCheckoutOpen(false);
      setStripeOpen(false);
      setSuccessOpen(true);
      utils.sales.list.invalidate();
      utils.inventory.getByBranch.invalidate();
      toast.success("Sale recorded successfully!");
    },
    onError: (e) => toast.error(e.message),
  });

  const categories = useMemo(() => ["All", ...Array.from(new Set(inventory.map((i) => i.category ?? "Uncategorized")))], [inventory]);

  const filtered = useMemo(() => {
    const seen = new Set<number>();
    const unique = inventory.filter((i) => {
      if (seen.has(i.productId)) return false;
      seen.add(i.productId);
      return true;
    });
    return unique.filter((i) => {
      const matchSearch = i.productName?.toLowerCase().includes(search.toLowerCase());
      const matchCat = categoryFilter === "All" || (i.category ?? "Uncategorized") === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [inventory, search, categoryFilter]);

  const cartTotal = cart.reduce((s, i) => s + i.subtotal, 0);
  const todayTotal = todaySales.reduce((s, t) => s + Number(t.totalAmount), 0);

  const addToCart = (item: typeof inventory[0]) => {
    const price = parseFloat(item.price as string);
    setCart((prev) => {
      const existing = prev.find((c) => c.productId === item.productId);
      if (existing) {
        return prev.map((c) => c.productId === item.productId
          ? { ...c, quantity: c.quantity + 1, subtotal: (c.quantity + 1) * c.unitPrice }
          : c
        );
      }
      return [...prev, { productId: item.productId, productName: item.productName, quantity: 1, unitPrice: price, subtotal: price, unit: item.unit ?? "pc" }];
    });
  };

  const updateQty = (productId: number, delta: number) => {
    setCart((prev) => prev
      .map((c) => c.productId === productId ? { ...c, quantity: c.quantity + delta, subtotal: (c.quantity + delta) * c.unitPrice } : c)
      .filter((c) => c.quantity > 0)
    );
  };

  const handleCheckout = () => {
    if (cart.length === 0) { toast.error("Cart is empty"); return; }
    if (!cashierName.trim()) { toast.error("Please enter cashier name"); return; }

    if (paymentType === "card") {
      // For card payments — create Stripe PaymentIntent first
      setPendingSaleItems([...cart]);
      createPaymentIntent.mutate({
        amount: cartTotal,
        cashierName,
        branchName: session?.username ?? "Branch",
        saleRef: `SALE-${Date.now()}`,
      });
    } else {
      // Cash or GCash — record directly
      createSale.mutate({ branchId, cashierName, paymentType, items: cart });
    }
  };

  // Called after Stripe confirms the card payment
  const handleStripeSuccess = (paymentIntentId: string) => {
    setStripeOpen(false);
    setStripeClientSecret(null);
    createSale.mutate({
      branchId,
      cashierName,
      paymentType: "card",
      items: pendingSaleItems,
      stripePaymentIntentId: paymentIntentId,
    });
  };

  return (
    <div className="flex flex-col lg:flex-row h-full gap-0 overflow-hidden">
      {/* Product Grid */}
      <div className="flex-1 flex flex-col overflow-hidden p-4 md:p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold">Sales / POS</h1>
            <p className="text-sm text-muted-foreground">Today's total: <span className="font-semibold text-[var(--henlin-red)]">{formatPHP(todayTotal)}</span> ({todaySales.length} transactions)</p>
          </div>
          <div className="text-right">
            <Label className="text-xs text-muted-foreground">Cashier</Label>
            <Input value={cashierName} onChange={(e) => setCashierName(e.target.value)} placeholder="Enter cashier name" className="h-8 text-sm w-44 mt-0.5" />
          </div>
        </div>

        <div className="flex gap-2 mb-4 flex-wrap">
          <div className="relative flex-1 min-w-[160px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-9 text-sm" />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-36 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>{categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
              <ShoppingCart size={32} className="mb-2 opacity-30" />
              <p className="text-sm">No products found</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-2">
              {filtered.map((item) => {
                const stock = parseFloat(item.quantity as string);
                const inCart = cart.find((c) => c.productId === item.productId);
                return (
                  <button
                    key={item.productId}
                    onClick={() => addToCart(item)}
                    className={`relative p-3 rounded-xl border-2 text-left transition-all active:scale-95 ${
                      inCart ? "border-[var(--henlin-red)] bg-red-50" : "border-border bg-card hover:border-[var(--henlin-red)]/50 hover:bg-muted/30"
                    }`}
                  >
                    {inCart && (
                      <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[var(--henlin-red)] rounded-full flex items-center justify-center text-white text-[10px] font-bold">
                        {inCart.quantity}
                      </div>
                    )}
                    <div className="text-xs font-semibold leading-tight mb-1 line-clamp-2">{item.productName}</div>
                    <div className="text-[var(--henlin-red)] font-bold text-sm">₱{parseFloat(item.price as string).toFixed(2)}</div>
                    <div className={`text-[10px] mt-0.5 ${stock <= 0 ? "text-red-500" : "text-muted-foreground"}`}>
                      Stock: {stock.toFixed(0)} {item.unit}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Cart Panel */}
      <div className="w-full lg:w-80 xl:w-96 border-t lg:border-t-0 lg:border-l border-border flex flex-col bg-card">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <ShoppingCart size={16} className="text-[var(--henlin-red)]" />
            <h2 className="font-semibold">Cart</h2>
            {cart.length > 0 && <Badge className="bg-[var(--henlin-red)] text-white text-xs ml-auto">{cart.length} items</Badge>}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <ShoppingCart size={28} className="mb-2 opacity-30" />
              <p className="text-sm">Click products to add</p>
            </div>
          ) : cart.map((item) => (
            <div key={item.productId} className="flex items-center gap-2 p-2 rounded-lg bg-muted/30 border border-border">
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium truncate">{item.productName}</div>
                <div className="text-xs text-muted-foreground">₱{item.unitPrice.toFixed(2)} × {item.quantity}</div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => updateQty(item.productId, -1)} className="w-6 h-6 rounded bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                  <Minus size={10} />
                </button>
                <span className="text-xs font-bold w-5 text-center">{item.quantity}</span>
                <button onClick={() => updateQty(item.productId, 1)} className="w-6 h-6 rounded bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                  <Plus size={10} />
                </button>
                <button onClick={() => setCart((p) => p.filter((c) => c.productId !== item.productId))} className="w-6 h-6 rounded bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition-colors ml-1">
                  <Trash2 size={10} />
                </button>
              </div>
              <div className="text-xs font-bold text-[var(--henlin-red)] w-16 text-right">₱{item.subtotal.toFixed(2)}</div>
            </div>
          ))}
        </div>

        {cart.length > 0 && (
          <div className="p-4 border-t space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total</span>
              <span className="text-xl font-black text-[var(--henlin-red)]">{formatPHP(cartTotal)}</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(["cash", "GCash", "card"] as PaymentType[]).map((p) => (
                <button key={p} onClick={() => setPaymentType(p)}
                  className={`py-2 rounded-lg text-xs font-semibold flex flex-col items-center gap-1 border-2 transition-all ${paymentType === p ? "border-[var(--henlin-red)] bg-red-50 text-[var(--henlin-red)]" : "border-border text-muted-foreground hover:border-muted-foreground"}`}>
                  {p === "cash" ? <Banknote size={14} /> : p === "GCash" ? <Smartphone size={14} /> : <CreditCard size={14} />}
                  {p === "GCash" ? "GCash" : p.charAt(0).toUpperCase() + p.slice(1)}
                </button>
              ))}
            </div>
            {paymentType === "card" && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-xs text-blue-700 flex items-center gap-1.5">
                <CreditCard size={12} />
                Card payment will be processed via Stripe
              </div>
            )}
            <Button className="w-full bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white font-bold h-11"
              disabled={createSale.isPending || createPaymentIntent.isPending}
              onClick={() => setCheckoutOpen(true)}>
              {createPaymentIntent.isPending ? "Preparing payment..." : `Checkout — ${formatPHP(cartTotal)}`}
            </Button>
            <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => setCart([])}>Clear Cart</Button>
          </div>
        )}
      </div>

      {/* Checkout Confirm Dialog */}
      <Dialog open={checkoutOpen} onOpenChange={setCheckoutOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Confirm Sale</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="bg-muted/30 rounded-lg p-3 space-y-1.5">
              {cart.map((i) => (
                <div key={i.productId} className="flex justify-between text-sm">
                  <span>{i.productName} × {i.quantity}</span>
                  <span className="font-medium">₱{i.subtotal.toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t pt-1.5 flex justify-between font-bold">
                <span>Total</span><span className="text-[var(--henlin-red)]">{formatPHP(cartTotal)}</span>
              </div>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Payment</span>
              <Badge variant="outline" className="capitalize flex items-center gap-1">
                {paymentType === "card" && <CreditCard size={10} />}
                {paymentType}
                {paymentType === "card" && <span className="text-[10px] text-blue-600 ml-1">(Stripe)</span>}
              </Badge>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Cashier</span>
              <span className="font-medium">{cashierName || "—"}</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCheckoutOpen(false)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={createSale.isPending || createPaymentIntent.isPending}
              onClick={handleCheckout}
            >
              {createSale.isPending || createPaymentIntent.isPending
                ? "Processing..."
                : paymentType === "card" ? "Proceed to Card Payment" : "Confirm Sale"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stripe Card Payment Modal */}
      <StripeCardModal
        open={stripeOpen}
        clientSecret={stripeClientSecret}
        amount={pendingSaleItems.reduce((s, i) => s + i.subtotal, 0)}
        onSuccess={handleStripeSuccess}
        onClose={() => {
          setStripeOpen(false);
          setStripeClientSecret(null);
          setPendingSaleItems([]);
        }}
      />

      {/* Success Dialog */}
      <Dialog open={successOpen} onOpenChange={setSuccessOpen}>
        <DialogContent className="text-center">
          <div className="flex flex-col items-center gap-3 py-4">
            <CheckCircle size={48} className="text-green-500" />
            <h2 className="text-xl font-bold">Sale Recorded!</h2>
            <p className="text-2xl font-black text-[var(--henlin-red)]">{formatPHP(lastTotal)}</p>
            <p className="text-sm text-muted-foreground">Payment via {paymentType}</p>
          </div>
          <Button className="w-full bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" onClick={() => setSuccessOpen(false)}>
            New Transaction
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
