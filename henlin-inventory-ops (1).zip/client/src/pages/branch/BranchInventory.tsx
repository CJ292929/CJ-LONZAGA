import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Search, Plus, Minus, AlertTriangle, ArrowUpCircle, ArrowDownCircle, Settings2, RefreshCw } from "lucide-react";

type AdjustReason = "damaged" | "expired" | "transferred" | "correction";

export default function BranchInventory() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [stockInDialog, setStockInDialog] = useState<{ productId: number; name: string } | null>(null);
  const [stockOutDialog, setStockOutDialog] = useState<{ productId: number; name: string } | null>(null);
  const [adjustDialog, setAdjustDialog] = useState<{ productId: number; name: string } | null>(null);
  const [qty, setQty] = useState("");
  const [reason, setReason] = useState("");
  const [adjustReason, setAdjustReason] = useState<AdjustReason>("damaged");

  const utils = trpc.useUtils();
  const { data: inventory = [], isLoading } = trpc.inventory.getByBranch.useQuery(
    { branchId },
    { enabled: !!branchId }
  );

  const stockInMut = trpc.inventory.stockIn.useMutation({
    onSuccess: () => { toast.success("Stock added successfully"); utils.inventory.getByBranch.invalidate(); setStockInDialog(null); setQty(""); setReason(""); },
    onError: (e) => toast.error(e.message),
  });
  const stockOutMut = trpc.inventory.stockOut.useMutation({
    onSuccess: () => { toast.success("Stock deducted"); utils.inventory.getByBranch.invalidate(); setStockOutDialog(null); setQty(""); setReason(""); },
    onError: (e) => toast.error(e.message),
  });
  const adjustMut = trpc.inventory.adjust.useMutation({
    onSuccess: () => { toast.success("Inventory adjusted"); utils.inventory.getByBranch.invalidate(); setAdjustDialog(null); setQty(""); setReason(""); },
    onError: (e) => toast.error(e.message),
  });

  const categories = useMemo(() => ["All", ...Array.from(new Set(inventory.map((i) => i.category ?? "Uncategorized").filter(Boolean)))], [inventory]);

  const filtered = useMemo(() =>
    inventory.filter((i) => {
      const matchSearch = i.productName?.toLowerCase().includes(search.toLowerCase());
      const matchCat = categoryFilter === "All" || (i.category ?? "Uncategorized") === categoryFilter;
      return matchSearch && matchCat;
    }),
    [inventory, search, categoryFilter]
  );

  const lowStockCount = inventory.filter((i) => parseFloat(i.quantity as string) <= parseFloat(i.reorderLevel as string)).length;

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Inventory</h1>
          {lowStockCount > 0 && (
            <p className="text-sm text-orange-600 flex items-center gap-1 mt-0.5">
              <AlertTriangle size={13} /> {lowStockCount} items below reorder level
            </p>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={() => utils.inventory.getByBranch.invalidate()}>
          <RefreshCw size={14} className="mr-1.5" /> Refresh
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-9 text-sm" />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-40 h-9 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Product</th>
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Category</th>
                <th className="text-right px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Stock</th>
                <th className="text-right px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Reorder</th>
                <th className="text-right px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Price</th>
                <th className="text-center px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}><td colSpan={6} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse" /></td></tr>
                ))
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No products found</td></tr>
              ) : filtered.map((item) => {
                const qty = parseFloat(item.quantity as string);
                const reorder = parseFloat(item.reorderLevel as string);
                const isLow = qty <= reorder;
                return (
                  <tr key={item.id} className={`hover:bg-muted/20 transition-colors ${isLow ? "bg-orange-50/50" : ""}`}>
                    <td className="px-4 py-3">
                      <div className="font-medium">{item.productName}</div>
                      <div className="text-xs text-muted-foreground">{item.unit}</div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className="text-xs">{item.category ?? "—"}</Badge>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className={`font-bold ${isLow ? "text-orange-600" : "text-green-700"}`}>
                        {qty.toFixed(0)}
                      </span>
                      {isLow && <AlertTriangle size={12} className="inline ml-1 text-orange-500" />}
                    </td>
                    <td className="px-4 py-3 text-right text-muted-foreground">{reorder.toFixed(0)}</td>
                    <td className="px-4 py-3 text-right">₱{parseFloat(item.price as string).toFixed(2)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-green-700 hover:bg-green-50"
                          onClick={() => { setStockInDialog({ productId: item.productId, name: item.productName }); setQty(""); setReason(""); }}>
                          <ArrowUpCircle size={14} className="mr-1" /> In
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-red-700 hover:bg-red-50"
                          onClick={() => { setStockOutDialog({ productId: item.productId, name: item.productName }); setQty(""); setReason(""); }}>
                          <ArrowDownCircle size={14} className="mr-1" /> Out
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-blue-700 hover:bg-blue-50"
                          onClick={() => { setAdjustDialog({ productId: item.productId, name: item.productName }); setQty(""); setReason(""); setAdjustReason("damaged"); }}>
                          <Settings2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Stock In Dialog */}
      <Dialog open={!!stockInDialog} onOpenChange={(o) => !o && setStockInDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Stock In — {stockInDialog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Quantity</Label><Input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="Enter quantity" /></div>
            <div><Label>Reason (optional)</Label><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Delivery from supplier" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStockInDialog(null)}>Cancel</Button>
            <Button className="bg-green-600 hover:bg-green-700 text-white" disabled={stockInMut.isPending}
              onClick={() => { if (!qty || Number(qty) <= 0) { toast.error("Enter a valid quantity"); return; } stockInMut.mutate({ branchId, productId: stockInDialog!.productId, quantity: Number(qty), reason }); }}>
              <Plus size={14} className="mr-1" /> Add Stock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock Out Dialog */}
      <Dialog open={!!stockOutDialog} onOpenChange={(o) => !o && setStockOutDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Stock Out — {stockOutDialog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Quantity</Label><Input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="Enter quantity" /></div>
            <div><Label>Reason (optional)</Label><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Wastage, manual deduction" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStockOutDialog(null)}>Cancel</Button>
            <Button variant="destructive" disabled={stockOutMut.isPending}
              onClick={() => { if (!qty || Number(qty) <= 0) { toast.error("Enter a valid quantity"); return; } stockOutMut.mutate({ branchId, productId: stockOutDialog!.productId, quantity: Number(qty), reason }); }}>
              <Minus size={14} className="mr-1" /> Deduct Stock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Adjust Dialog */}
      <Dialog open={!!adjustDialog} onOpenChange={(o) => !o && setAdjustDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Adjust Inventory — {adjustDialog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Adjustment Reason</Label>
              <Select value={adjustReason} onValueChange={(v) => setAdjustReason(v as AdjustReason)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="damaged">Damaged</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="transferred">Transferred</SelectItem>
                  <SelectItem value="correction">Correction</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Quantity to Deduct</Label><Input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="Enter quantity" /></div>
            <div><Label>Notes (optional)</Label><Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Additional notes..." rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdjustDialog(null)}>Cancel</Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white" disabled={adjustMut.isPending}
              onClick={() => { if (!qty || Number(qty) <= 0) { toast.error("Enter a valid quantity"); return; } adjustMut.mutate({ branchId, productId: adjustDialog!.productId, quantity: Number(qty), adjustmentReason: adjustReason, reason }); }}>
              <Settings2 size={14} className="mr-1" /> Apply Adjustment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
