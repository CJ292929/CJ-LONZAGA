import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Clock, LogIn, LogOut, Coffee, Play } from "lucide-react";

function getPHTDateStr(d = new Date()) {
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

function formatTime(ts: number | null | undefined) {
  if (!ts) return "—";
  return new Date(ts).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" });
}

function calcHours(clockIn: number | null, clockOut: number | null) {
  if (!clockIn) return "—";
  const end = clockOut ?? Date.now();
  const hrs = (end - clockIn) / 3600000;
  return hrs.toFixed(1) + "h";
}

export default function BranchTimeRecords() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;
  const [date, setDate] = useState(getPHTDateStr());

  const utils = trpc.useUtils();
  const { data: staffList = [] } = trpc.staff.listByBranch.useQuery({ branchId }, { enabled: !!branchId });
  const { data: records = [], isLoading } = trpc.timeRecords.list.useQuery({ branchId, date }, { enabled: !!branchId });

  const clockInMut = trpc.timeRecords.clockIn.useMutation({
    onSuccess: () => { toast.success("Clocked in!"); utils.timeRecords.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const clockOutMut = trpc.timeRecords.clockOut.useMutation({
    onSuccess: () => { toast.success("Clocked out!"); utils.timeRecords.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const breakStartMut = trpc.timeRecords.breakStart.useMutation({
    onSuccess: () => { toast.success("Break started"); utils.timeRecords.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const breakEndMut = trpc.timeRecords.breakEnd.useMutation({
    onSuccess: () => { toast.success("Break ended"); utils.timeRecords.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  // Staff not yet clocked in today
  const clockedInIds = new Set(records.map((r) => r.staffId));
  const notClockedIn = staffList.filter((s) => !clockedInIds.has(s.id));

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-xl font-bold">Time Records</h1>
          <p className="text-sm text-muted-foreground">{records.length} records for {date}</p>
        </div>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
          className="border border-border rounded-md px-3 py-1.5 text-sm bg-background" />
      </div>

      {/* Clock In Panel */}
      {notClockedIn.length > 0 && date === getPHTDateStr() && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-green-800 flex items-center gap-2"><LogIn size={14} /> Clock In Staff</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {notClockedIn.map((s) => (
                <Button key={s.id} size="sm" variant="outline" className="border-green-400 text-green-700 hover:bg-green-100 text-xs"
                  disabled={clockInMut.isPending}
                  onClick={() => clockInMut.mutate({ staffId: s.id, branchId, date })}>
                  <LogIn size={12} className="mr-1" /> {s.name}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Records Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/30">
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Staff</th>
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Clock In</th>
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Break</th>
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Clock Out</th>
                <th className="text-left px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Hours</th>
                <th className="text-center px-4 py-3 font-semibold text-xs uppercase tracking-wide text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i}><td colSpan={6} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse" /></td></tr>
                ))
              ) : records.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  <Clock size={24} className="mx-auto mb-2 opacity-30" />
                  No time records for this date
                </td></tr>
              ) : records.map((r) => {
                const isActive = r.clockIn && !r.clockOut;
                const onBreak = r.breakStart && !r.breakEnd;
                return (
                  <tr key={r.id} className="hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <div className="font-medium">{r.staffName}</div>
                      {isActive && <Badge className="bg-green-100 text-green-700 text-[10px] mt-0.5">Active</Badge>}
                    </td>
                    <td className="px-4 py-3 text-sm">{formatTime(r.clockIn)}</td>
                    <td className="px-4 py-3 text-sm">
                      {r.breakStart ? `${formatTime(r.breakStart)} – ${r.breakEnd ? formatTime(r.breakEnd) : "ongoing"}` : "—"}
                    </td>
                    <td className="px-4 py-3 text-sm">{formatTime(r.clockOut)}</td>
                    <td className="px-4 py-3 font-semibold">{calcHours(r.clockIn, r.clockOut)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        {isActive && !onBreak && (
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-yellow-700 hover:bg-yellow-50 text-xs"
                            disabled={breakStartMut.isPending}
                            onClick={() => breakStartMut.mutate({ timeRecordId: r.id })}>
                            <Coffee size={12} className="mr-1" /> Break
                          </Button>
                        )}
                        {onBreak && (
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-blue-700 hover:bg-blue-50 text-xs"
                            disabled={breakEndMut.isPending}
                            onClick={() => breakEndMut.mutate({ timeRecordId: r.id })}>
                            <Play size={12} className="mr-1" /> Resume
                          </Button>
                        )}
                        {isActive && (
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-red-700 hover:bg-red-50 text-xs"
                            disabled={clockOutMut.isPending}
                            onClick={() => clockOutMut.mutate({ timeRecordId: r.id })}>
                            <LogOut size={12} className="mr-1" /> Out
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
