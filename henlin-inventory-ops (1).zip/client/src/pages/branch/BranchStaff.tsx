import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { UserPlus, Pencil, Trash2, Users } from "lucide-react";

export default function BranchStaff() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;

  const [addOpen, setAddOpen] = useState(false);
  const [editItem, setEditItem] = useState<{ id: number; name: string; position: string } | null>(null);
  const [name, setName] = useState("");
  const [position, setPosition] = useState("");

  const utils = trpc.useUtils();
  const { data: staffList = [], isLoading } = trpc.staff.listByBranch.useQuery({ branchId }, { enabled: !!branchId });

  const createMut = trpc.staff.create.useMutation({
    onSuccess: () => { toast.success("Staff added"); utils.staff.listByBranch.invalidate(); setAddOpen(false); setName(""); setPosition(""); },
    onError: (e) => toast.error(e.message),
  });
  const updateMut = trpc.staff.update.useMutation({
    onSuccess: () => { toast.success("Staff updated"); utils.staff.listByBranch.invalidate(); setEditItem(null); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMut = trpc.staff.delete.useMutation({
    onSuccess: () => { toast.success("Staff removed"); utils.staff.listByBranch.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">Staff</h1>
          <p className="text-sm text-muted-foreground">{staffList.length} team members</p>
        </div>
        <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white h-9"
          onClick={() => { setAddOpen(true); setName(""); setPosition(""); }}>
          <UserPlus size={14} className="mr-1.5" /> Add Staff
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}
        </div>
      ) : staffList.length === 0 ? (
        <Card><CardContent className="py-12 text-center">
          <Users size={32} className="mx-auto mb-2 opacity-30" />
          <p className="text-muted-foreground">No staff added yet. Add your first team member.</p>
        </CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {staffList.map((s) => (
            <Card key={s.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 flex items-center gap-3">
                <Avatar className="w-10 h-10 flex-shrink-0">
                  <AvatarFallback className="bg-[var(--henlin-red)] text-white font-bold text-sm">
                    {s.name?.charAt(0)?.toUpperCase() ?? "?"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm truncate">{s.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{s.position ?? "Staff"}</div>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0"
                    onClick={() => { setEditItem({ id: s.id, name: s.name ?? "", position: s.position ?? "" }); }}>
                    <Pencil size={12} />
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => { if (confirm(`Remove ${s.name}?`)) deleteMut.mutate({ id: s.id }); }}>
                    <Trash2 size={12} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Staff Member</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Full Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Juan dela Cruz" /></div>
            <div><Label>Position</Label><Input value={position} onChange={(e) => setPosition(e.target.value)} placeholder="e.g. Cashier, Cook, Manager" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={createMut.isPending}
              onClick={() => { if (!name.trim()) { toast.error("Name is required"); return; } createMut.mutate({ branchId, name, position }); }}>
              Add Staff
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editItem} onOpenChange={(o) => !o && setEditItem(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Staff</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Full Name</Label><Input value={editItem?.name ?? ""} onChange={(e) => setEditItem((p) => p ? { ...p, name: e.target.value } : p)} /></div>
            <div><Label>Position</Label><Input value={editItem?.position ?? ""} onChange={(e) => setEditItem((p) => p ? { ...p, position: e.target.value } : p)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditItem(null)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={updateMut.isPending}
              onClick={() => { if (!editItem) return; updateMut.mutate({ id: editItem.id, name: editItem.name, position: editItem.position }); }}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
