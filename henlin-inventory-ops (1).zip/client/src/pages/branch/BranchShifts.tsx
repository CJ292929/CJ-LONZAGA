import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Plus, CheckCircle, UserPlus } from "lucide-react";

function getPHTDateStr() {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

export default function BranchShifts() {
  const { session } = useBranchSession();
  const branchId = session?.branchId ?? 0;
  const [date, setDate] = useState(getPHTDateStr());
  const [addOpen, setAddOpen] = useState(false);
  const [assignOpen, setAssignOpen] = useState<number | null>(null);
  const [shiftName, setShiftName] = useState("Morning");
  const [startTime, setStartTime] = useState("06:00");
  const [endTime, setEndTime] = useState("14:00");
  const [selectedStaff, setSelectedStaff] = useState("");

  const utils = trpc.useUtils();
  const { data: shifts = [], isLoading } = trpc.shifts.listByBranch.useQuery({ branchId, date }, { enabled: !!branchId });
  const { data: staffList = [] } = trpc.staff.listByBranch.useQuery({ branchId }, { enabled: !!branchId });

  const createMut = trpc.shifts.create.useMutation({
    onSuccess: () => { toast.success("Shift created"); utils.shifts.listByBranch.invalidate(); setAddOpen(false); },
    onError: (e) => toast.error(e.message),
  });
  const closeMut = trpc.shifts.close.useMutation({
    onSuccess: () => { toast.success("Shift closed"); utils.shifts.listByBranch.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const assignMut = trpc.shifts.assignStaff.useMutation({
    onSuccess: () => { toast.success("Staff assigned"); utils.shifts.listByBranch.invalidate(); setAssignOpen(null); setSelectedStaff(""); },
    onError: (e) => toast.error(e.message),
  });

  const SHIFT_PRESETS = [
    { label: "Morning (6AM–2PM)", name: "Morning", start: "06:00", end: "14:00" },
    { label: "Afternoon (2PM–10PM)", name: "Afternoon", start: "14:00", end: "22:00" },
    { label: "Night (10PM–6AM)", name: "Night", start: "22:00", end: "06:00" },
  ];

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-xl font-bold">Shifts</h1>
          <p className="text-sm text-muted-foreground">{shifts.length} shifts on {date}</p>
        </div>
        <div className="flex gap-2">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
            className="border border-border rounded-md px-3 py-1.5 text-sm bg-background" />
          <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white h-9"
            onClick={() => setAddOpen(true)}>
            <Plus size={14} className="mr-1.5" /> New Shift
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-24 bg-muted rounded-xl animate-pulse" />)}</div>
      ) : shifts.length === 0 ? (
        <Card><CardContent className="py-12 text-center">
          <Calendar size={32} className="mx-auto mb-2 opacity-30" />
          <p className="text-muted-foreground">No shifts for this date. Create one to get started.</p>
        </CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {shifts.map((shift) => (
            <Card key={shift.id} className={`border-l-4 ${shift.status === "open" ? "border-l-green-500" : "border-l-gray-300"}`}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">{shift.name}</CardTitle>
                  <Badge className={shift.status === "open" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}>
                    {shift.status}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">{shift.startTime} – {shift.endTime}</p>
              </CardHeader>
              <CardContent className="pt-0 space-y-2">
                {shift.staffAssigned && shift.staffAssigned.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {shift.staffAssigned.map((s: any) => (
                      <Badge key={s.staffId} variant="outline" className="text-[10px]">{s.staffName}</Badge>
                    ))}
                  </div>
                )}
                <div className="flex gap-1.5">
                  {shift.status === "open" && (
                    <>
                      <Button size="sm" variant="outline" className="h-7 text-xs flex-1"
                        onClick={() => setAssignOpen(shift.id)}>
                        <UserPlus size={11} className="mr-1" /> Assign
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 text-xs flex-1 text-red-600 border-red-200 hover:bg-red-50"
                        disabled={closeMut.isPending}
                        onClick={() => { if (confirm("Close this shift?")) closeMut.mutate({ shiftId: shift.id }); }}>
                        <CheckCircle size={11} className="mr-1" /> Close
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add Shift Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create New Shift</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Quick Presets</Label>
              <div className="flex flex-wrap gap-2 mt-1.5">
                {SHIFT_PRESETS.map((p) => (
                  <button key={p.name} onClick={() => { setShiftName(p.name); setStartTime(p.start); setEndTime(p.end); }}
                    className={`px-3 py-1.5 rounded-md text-xs border transition-colors ${shiftName === p.name ? "bg-[var(--henlin-red)] text-white border-[var(--henlin-red)]" : "border-border hover:bg-muted"}`}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
            <div><Label>Shift Name</Label><Input value={shiftName} onChange={(e) => setShiftName(e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Start Time</Label><Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} /></div>
              <div><Label>End Time</Label><Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={createMut.isPending}
              onClick={() => createMut.mutate({ branchId, name: shiftName, startTime, endTime, date })}>
              Create Shift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Staff Dialog */}
      <Dialog open={assignOpen !== null} onOpenChange={(o) => !o && setAssignOpen(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Assign Staff to Shift</DialogTitle></DialogHeader>
          <div>
            <Label>Select Staff</Label>
            <Select value={selectedStaff} onValueChange={setSelectedStaff}>
              <SelectTrigger><SelectValue placeholder="Choose staff member" /></SelectTrigger>
              <SelectContent>
                {staffList.map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name} — {s.position ?? "Staff"}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignOpen(null)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={assignMut.isPending}
              onClick={() => { if (!selectedStaff) { toast.error("Select a staff member"); return; } assignMut.mutate({ shiftId: assignOpen!, staffId: Number(selectedStaff), branchId }); }}>
              Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
