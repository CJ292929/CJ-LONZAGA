import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Clock, LogIn, LogOut, Coffee, Search, UserCheck, AlertCircle } from "lucide-react";

function formatTime(ts: number | null | undefined) {
  if (!ts) return "—";
  return new Date(ts).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "2-digit", minute: "2-digit" });
}

function getPHTDateStr() {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

export default function TimeRecords() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const utils = trpc.useUtils();
  const activeBranchId = selectedBranchId ?? branches[0]?.id ?? 1;
  const activeBranchName = selectedBranch?.name ?? branches.find((b) => b.id === activeBranchId)?.name ?? "Branch";

  const [selectedDate, setSelectedDate] = useState(getPHTDateStr());
  const [search, setSearch] = useState("");
  const [showClockIn, setShowClockIn] = useState(false);
  const [clockInStaffId, setClockInStaffId] = useState<string>("");

  const { data: staffList = [] } = trpc.staff.listByBranch.useQuery({ branchId: activeBranchId });
  const { data: records = [], isLoading, refetch } = trpc.timeRecords.list.useQuery({
    branchId: activeBranchId,
    date: selectedDate,
  });

  const clockInMut = trpc.timeRecords.clockIn.useMutation({
    onSuccess: () => { refetch(); toast.success("Clocked in successfully"); setShowClockIn(false); },
    onError: (e) => toast.error(e.message),
  });
  const clockOutMut = trpc.timeRecords.clockOut.useMutation({
    onSuccess: () => { refetch(); toast.success("Clocked out successfully"); },
    onError: (e) => toast.error(e.message),
  });
  const breakStartMut = trpc.timeRecords.breakStart.useMutation({
    onSuccess: () => { refetch(); toast.success("Break started"); },
    onError: (e) => toast.error(e.message),
  });
  const breakEndMut = trpc.timeRecords.breakEnd.useMutation({
    onSuccess: () => { refetch(); toast.success("Break ended"); },
    onError: (e) => toast.error(e.message),
  });

  const filtered = records.filter((r) =>
    r.staffName.toLowerCase().includes(search.toLowerCase())
  );

  const staffOnDuty = records.filter((r) => r.clockIn && !r.clockOut).length;
  const totalHours = records.reduce((sum, r) => sum + (parseFloat(r.hoursRendered as string) || 0), 0);

  function getStatus(record: typeof records[0]) {
    if (!record.clockIn) return { label: "Absent", cls: "badge-danger" };
    if (!record.clockOut) return { label: "On Duty", cls: "badge-success" };
    const hours = parseFloat(record.hoursRendered as string) || 0;
    if (hours > 9) return { label: "Overtime", cls: "badge-warning" };
    if (hours < 7) return { label: "Undertime", cls: "badge-warning" };
    return { label: "Complete", cls: "badge-success" };
  }

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground">Time Records — {activeBranchName}</h2>
          <p className="text-sm text-muted-foreground">
            {staffOnDuty} on duty · {totalHours.toFixed(1)} total hours today
          </p>
        </div>
        <Button
          className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
          size="sm"
          onClick={() => setShowClockIn(true)}
        >
          <LogIn size={14} className="mr-1.5" /> Clock In Staff
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <UserCheck size={20} className="mx-auto text-green-600 mb-1" />
            <div className="text-2xl font-bold">{staffOnDuty}</div>
            <div className="text-xs text-muted-foreground">On Duty</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Clock size={20} className="mx-auto text-blue-600 mb-1" />
            <div className="text-2xl font-bold">{totalHours.toFixed(1)}</div>
            <div className="text-xs text-muted-foreground">Total Hours</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <AlertCircle size={20} className="mx-auto text-orange-500 mb-1" />
            <div className="text-2xl font-bold">
              {records.filter((r) => !r.clockIn).length}
            </div>
            <div className="text-xs text-muted-foreground">Absent</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <Input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="w-40 h-9 text-sm"
        />
        <div className="relative flex-1 min-w-[180px]">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search staff..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-9 text-sm" />
        </div>
      </div>

      {/* Records Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="text-xs">Staff</TableHead>
                  <TableHead className="text-xs">Position</TableHead>
                  <TableHead className="text-xs">Clock In</TableHead>
                  <TableHead className="text-xs">Break</TableHead>
                  <TableHead className="text-xs">Clock Out</TableHead>
                  <TableHead className="text-xs text-right">Hours</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading
                  ? Array(5).fill(0).map((_, i) => (
                      <TableRow key={i}>
                        {Array(8).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                      </TableRow>
                    ))
                  : filtered.map((record) => {
                      const status = getStatus(record);
                      const onBreak = record.breakStart && !record.breakEnd;
                      return (
                        <TableRow key={record.id}>
                          <TableCell className="font-medium text-sm">{record.staffName}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{record.position ?? "—"}</TableCell>
                          <TableCell className="text-sm">{formatTime(record.clockIn)}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {record.breakStart ? (
                              <span>{formatTime(record.breakStart)} {record.breakEnd ? `– ${formatTime(record.breakEnd)}` : "(ongoing)"}</span>
                            ) : "—"}
                          </TableCell>
                          <TableCell className="text-sm">{formatTime(record.clockOut)}</TableCell>
                          <TableCell className="text-right font-semibold text-sm">
                            {record.hoursRendered ? parseFloat(record.hoursRendered as string).toFixed(2) + "h" : "—"}
                          </TableCell>
                          <TableCell>
                            <span className={status.cls}>{status.label}</span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center justify-end gap-1">
                              {record.clockIn && !record.clockOut && (
                                <>
                                  {!onBreak ? (
                                    <Button variant="ghost" size="sm" className="h-7 text-xs text-orange-600 hover:bg-orange-50" onClick={() => breakStartMut.mutate({ timeRecordId: record.id })}>
                                      <Coffee size={12} className="mr-1" /> Break
                                    </Button>
                                  ) : (
                                    <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:bg-blue-50" onClick={() => breakEndMut.mutate({ timeRecordId: record.id })}>
                                      <Coffee size={12} className="mr-1" /> End Break
                                    </Button>
                                  )}
                                  <Button variant="ghost" size="sm" className="h-7 text-xs text-red-600 hover:bg-red-50" onClick={() => clockOutMut.mutate({ timeRecordId: record.id })}>
                                    <LogOut size={12} className="mr-1" /> Out
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                {!isLoading && filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                      <Clock size={28} className="mx-auto mb-2 opacity-30" />
                      No time records for {selectedDate}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Clock In Dialog */}
      <Dialog open={showClockIn} onOpenChange={setShowClockIn}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Clock In Staff</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Select Staff Member</label>
              <Select value={clockInStaffId} onValueChange={setClockInStaffId}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Choose staff..." /></SelectTrigger>
                <SelectContent>
                  {staffList.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>{s.name} — {s.position}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="p-2 bg-muted rounded text-xs text-muted-foreground">
              Clock-in time: {new Date().toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" })}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClockIn(false)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={!clockInStaffId || clockInMut.isPending}
              onClick={() => clockInMut.mutate({ staffId: parseInt(clockInStaffId), branchId: activeBranchId, date: getPHTDateStr() })}
            >
              Clock In
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
