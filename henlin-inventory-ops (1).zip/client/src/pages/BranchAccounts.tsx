import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  KeyRound,
  Eye,
  EyeOff,
  Store,
  ShieldCheck,
  RefreshCw,
  Copy,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";

interface BranchAccount {
  id: number;
  branchId: number;
  username: string;
  role: string;
  isActive: boolean;
  branchName?: string | null;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };
  return (
    <button
      onClick={handleCopy}
      className="ml-1 p-0.5 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
      title="Copy"
    >
      {copied ? <Check size={12} className="text-green-500" /> : <Copy size={12} />}
    </button>
  );
}

export default function BranchAccounts() {
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<BranchAccount | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const { data: accounts = [], isLoading, refetch } = trpc.branchAuth.listAccounts.useQuery();
  const { data: branches = [] } = trpc.branches.list.useQuery();

  const changePasswordMutation = trpc.branchAuth.changePassword.useMutation({
    onSuccess: () => {
      toast.success(`Password updated for ${selectedAccount?.username}`);
      setResetDialogOpen(false);
      setNewPassword("");
      setSelectedAccount(null);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to update password");
    },
  });

  const accountsWithBranch: BranchAccount[] = accounts.map((acc) => ({
    ...acc,
    branchName: branches.find((b) => b.id === acc.branchId)?.name ?? `Branch #${acc.branchId}`,
  }));

  const openResetDialog = (account: BranchAccount) => {
    setSelectedAccount(account);
    setNewPassword("");
    setShowPassword(false);
    setResetDialogOpen(true);
  };

  const handleResetPassword = () => {
    if (!selectedAccount) return;
    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    changePasswordMutation.mutate({
      branchId: selectedAccount.branchId,
      newPassword,
    });
  };

  const generatePassword = () => {
    const chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789@#!";
    let pwd = "";
    for (let i = 0; i < 12; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPassword(pwd);
    setShowPassword(true);
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#C62828]" />
            Branch Account Management
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            View credentials and reset passwords for all 13 branch portals
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetch()}
          className="gap-1.5"
        >
          <RefreshCw size={13} />
          Refresh
        </Button>
      </div>

      {/* Info Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 text-sm text-amber-800 flex items-start gap-2">
        <KeyRound size={15} className="mt-0.5 flex-shrink-0 text-amber-600" />
        <div>
          <strong>Branch Login URL:</strong> Go to the main login page and click{" "}
          <strong>"Branch Login →"</strong> to access the branch portal. Each branch uses
          their own username and password listed below.
        </div>
      </div>

      {/* Accounts Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 13 }).map((_, i) => (
            <div key={i} className="h-32 rounded-lg bg-muted animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {accountsWithBranch.map((account) => (
            <Card key={account.id} className="border shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-2 pt-4 px-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-[#C62828]/10 flex items-center justify-center flex-shrink-0">
                      <Store size={14} className="text-[#C62828]" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-sm font-semibold truncate leading-tight">
                        {account.branchName}
                      </CardTitle>
                      <CardDescription className="text-[10px] capitalize">
                        {account.role.replace("_", " ")}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge
                    variant={account.isActive ? "default" : "secondary"}
                    className={`text-[10px] flex-shrink-0 ${
                      account.isActive
                        ? "bg-green-100 text-green-700 hover:bg-green-100"
                        : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    {account.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                {/* Username */}
                <div className="bg-muted/50 rounded-md px-3 py-2">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">
                    Username
                  </div>
                  <div className="flex items-center gap-1">
                    <code className="text-xs font-mono font-semibold text-foreground">
                      {account.username}
                    </code>
                    <CopyButton text={account.username} />
                  </div>
                </div>

                {/* Reset Button */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full h-8 text-xs gap-1.5 border-[#C62828]/30 text-[#C62828] hover:bg-[#C62828]/5 hover:border-[#C62828]"
                  onClick={() => openResetDialog(account)}
                >
                  <KeyRound size={12} />
                  Reset Password
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Reset Password Dialog */}
      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound size={16} className="text-[#C62828]" />
              Reset Password
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="bg-muted/50 rounded-lg px-3 py-2.5 text-sm">
              <div className="text-xs text-muted-foreground mb-0.5">Branch</div>
              <div className="font-semibold">{selectedAccount?.branchName}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Username: <code className="font-mono">{selectedAccount?.username}</code>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                New Password
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password (min 6 chars)"
                    className="pr-9 h-10 text-sm font-mono"
                  />
                  <button
                    type="button"
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPassword((v) => !v)}
                  >
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-10 px-3 gap-1.5 text-xs whitespace-nowrap"
                  onClick={generatePassword}
                >
                  <RefreshCw size={12} />
                  Generate
                </Button>
              </div>
              {newPassword && newPassword.length >= 6 && (
                <div className="mt-1.5 flex items-center gap-1 text-xs text-green-600">
                  <Check size={11} />
                  Password looks good
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setResetDialogOpen(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleResetPassword}
              disabled={changePasswordMutation.isPending || newPassword.length < 6}
              className="flex-1 bg-[#C62828] hover:bg-[#b71c1c] text-white"
            >
              {changePasswordMutation.isPending ? "Saving..." : "Save Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
