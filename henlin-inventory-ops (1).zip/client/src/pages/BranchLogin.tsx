import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Eye, EyeOff, Store, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BRANCH_TOKEN_KEY } from "@/contexts/BranchSessionContext";

const LOGO_URL = "/manus-storage/henlin-logo_a8ae97b6.jpg";

interface BranchLoginProps {
  onSuccess: () => void;
}

export default function BranchLogin({ onSuccess }: BranchLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  const utils = trpc.useUtils();
  const loginMutation = trpc.branchAuth.login.useMutation({
    onSuccess: (data) => {
      // Store JWT token in localStorage so it's sent as X-Branch-Token header
      if (data.token) {
        localStorage.setItem(BRANCH_TOKEN_KEY, data.token);
      }
      toast.success(`Welcome! Logged in as ${data.username}`);
      // Small delay so the header function picks up the new token before refetch
      setTimeout(() => {
        utils.branchAuth.me.invalidate();
        onSuccess();
      }, 100);
    },
    onError: (err) => {
      toast.error(err.message || "Invalid username or password");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      toast.error("Please enter username and password");
      return;
    }
    loginMutation.mutate({ username: username.trim(), password });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1a0a0a] via-[#2d1010] to-[#1a0a0a]">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle at 25% 25%, #C62828 0%, transparent 50%), radial-gradient(circle at 75% 75%, #FFC107 0%, transparent 50%)"
        }}
      />

      <div className="relative w-full max-w-sm mx-4">
        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-[#C62828] px-8 py-8 text-center">
            <div className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-4 overflow-hidden border-2 border-white/30">
              <img
                src={LOGO_URL}
                alt="Henlin"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                  (e.target as HTMLImageElement).parentElement!.innerHTML =
                    '<span class="text-white font-black text-2xl">H</span>';
                }}
              />
            </div>
            <h1 className="text-2xl font-black text-white tracking-wider">HENLIN</h1>
            <p className="text-white/80 text-sm mt-1 flex items-center justify-center gap-1.5">
              <Store size={13} />
              Branch Operations Portal
            </p>
          </div>

          {/* Form */}
          <div className="px-8 py-8">
            <h2 className="text-lg font-bold text-gray-800 mb-1">Branch Sign In</h2>
            <p className="text-sm text-gray-500 mb-6">Enter your branch credentials to continue</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                  Username
                </label>
                <Input
                  type="text"
                  placeholder="e.g. wm_silang"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  autoFocus
                  className="h-11 border-gray-200 focus:border-[#C62828] focus:ring-[#C62828]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">
                  Password
                </label>
                <div className="relative">
                  <Input
                    type={showPass ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    className="h-11 border-gray-200 focus:border-[#C62828] focus:ring-[#C62828]/20 pr-10"
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    onClick={() => setShowPass((v) => !v)}
                    tabIndex={-1}
                  >
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={loginMutation.isPending}
                className="w-full h-11 bg-[#C62828] hover:bg-[#b71c1c] text-white font-semibold text-sm rounded-lg transition-all active:scale-[0.98]"
              >
                {loginMutation.isPending ? (
                  <>
                    <Loader2 size={15} className="mr-2 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign In to Branch"
                )}
              </Button>
            </form>

            <div className="mt-6 pt-5 border-t border-gray-100 text-center">
              <p className="text-xs text-gray-400">
                For Super Admin access,{" "}
                <a href="/" className="text-[#C62828] hover:underline font-medium">
                  use the main portal
                </a>
              </p>
            </div>
          </div>
        </div>

        <p className="text-center text-white/40 text-xs mt-6">
          Henlin Franchise Operations Hub · {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
