import { useState, useRef, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Upload,
  Search,
  ArrowUpCircle,
  ArrowDownCircle,
  Settings2,
  AlertTriangle,
  Package,
  History,
  Edit2,
  Trash2,
  Filter,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

type InventoryItem = {
  id: number;
  branchId: number;
  productId: number;
  quantity: string;
  reorderLevel: string;
  productName: string;
  category: string | null;
  unit: string | null;
  price: string | null;
};

export default function Inventory() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showStockIn, setShowStockIn] = useState<InventoryItem | null>(null);
  const [showStockOut, setShowStockOut] = useState<InventoryItem | null>(null);
  const [showAdjust, setShowAdjust] = useState<InventoryItem | null>(null);
  const [showLogs, setShowLogs] = useState<InventoryItem | null>(null);
  const [showEditProduct, setShowEditProduct] = useState<any>(null);
  const [showUpload, setShowUpload] = useState(false);
  const csvRef = useRef<HTMLInputElement>(null);
  const [sortField, setSortField] = useState<"productName" | "quantity" | "reorderLevel" | "status">("productName");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const activeBranchId = selectedBranchId ?? branches[0]?.id ?? 1;
  const activeBranchName = selectedBranch?.name ?? branches.find((b) => b.id === activeBranchId)?.name ?? "Branch";

  const { data: inventory = [], isLoading } = trpc.inventory.getByBranch.useQuery(
    { branchId: activeBranchId },
    { enabled: !!activeBranchId }
  );

  const { data: logs = [] } = trpc.inventory.getLogs.useQuery(
    { branchId: activeBranchId, productId: showLogs?.productId },
    { enabled: !!showLogs }
  );

  const { data: allProducts = [] } = trpc.products.list.useQuery();

  const stockInMut = trpc.inventory.stockIn.useMutation({
    onSuccess: () => { utils.inventory.getByBranch.invalidate(); toast.success("Stock added successfully"); setShowStockIn(null); },
    onError: (e) => toast.error(e.message),
  });
  const stockOutMut = trpc.inventory.stockOut.useMutation({
    onSuccess: () => { utils.inventory.getByBranch.invalidate(); toast.success("Stock removed successfully"); setShowStockOut(null); },
    onError: (e) => toast.error(e.message),
  });
  const adjustMut = trpc.inventory.adjust.useMutation({
    onSuccess: () => { utils.inventory.getByBranch.invalidate(); toast.success("Inventory adjusted"); setShowAdjust(null); },
    onError: (e) => toast.error(e.message),
  });
  const createProductMut = trpc.products.create.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); utils.inventory.getByBranch.invalidate(); toast.success("Product added"); setShowAddProduct(false); },
    onError: (e) => toast.error(e.message),
  });
  const updateProductMut = trpc.products.update.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); utils.inventory.getByBranch.invalidate(); toast.success("Product updated"); setShowEditProduct(null); },
    onError: (e) => toast.error(e.message),
  });
  const deleteProductMut = trpc.products.delete.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); utils.inventory.getByBranch.invalidate(); toast.success("Product removed"); },
    onError: (e) => toast.error(e.message),
  });
  const massUploadMut = trpc.products.massUpload.useMutation({
    onSuccess: (data) => { utils.products.list.invalidate(); utils.inventory.getByBranch.invalidate(); toast.success(`${data.created} products uploaded`); setShowUpload(false); },
    onError: (e) => toast.error(e.message),
  });

  const categories = useMemo(() => {
    const cats = Array.from(new Set(inventory.map((i) => i.category).filter(Boolean)));
    return cats as string[];
  }, [inventory]);

  const filtered = useMemo(() => {
    return inventory.filter((item) => {
      const matchSearch =
        item.productName.toLowerCase().includes(search.toLowerCase()) ||
        (item.category ?? "").toLowerCase().includes(search.toLowerCase());
      const matchCat = categoryFilter === "all" || item.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [inventory, search, categoryFilter]);

  const lowStockItems = filtered.filter(
    (i) => parseFloat(i.quantity) <= parseFloat(i.reorderLevel)
  );

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let va: string | number = a[sortField as keyof typeof a] as string;
      let vb: string | number = b[sortField as keyof typeof b] as string;
      if (sortField === "quantity" || sortField === "reorderLevel") {
        va = parseFloat(va as string);
        vb = parseFloat(vb as string);
        return sortDir === "asc" ? (va as number) - (vb as number) : (vb as number) - (va as number);
      }
      if (sortField === "status") {
        const statusScore = (item: typeof a) => {
          const qty = parseFloat(item.quantity);
          const reorder = parseFloat(item.reorderLevel);
          if (qty <= reorder * 0.5) return 0;
          if (qty <= reorder) return 1;
          return 2;
        };
        return sortDir === "asc" ? statusScore(a) - statusScore(b) : statusScore(b) - statusScore(a);
      }
      return sortDir === "asc"
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });
  }, [filtered, sortField, sortDir]);

  function toggleSort(field: typeof sortField) {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortField(field); setSortDir("asc"); }
  }

  function handleCSVUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split("\n").filter((l) => l.trim());
      const header = lines[0].toLowerCase().split(",").map((h) => h.trim());
      const nameIdx = header.indexOf("name");
      const catIdx = header.indexOf("category");
      const unitIdx = header.indexOf("unit");
      const priceIdx = header.indexOf("price");
      if (nameIdx === -1) { toast.error("CSV must have a 'name' column"); return; }
      const items = lines.slice(1).map((line) => {
        const cols = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
        return {
          name: cols[nameIdx] ?? "",
          category: catIdx !== -1 ? cols[catIdx] : undefined,
          unit: unitIdx !== -1 ? cols[unitIdx] : undefined,
          price: priceIdx !== -1 ? parseFloat(cols[priceIdx]) || 0 : undefined,
        };
      }).filter((i) => i.name);
      if (items.length === 0) { toast.error("No valid products found in CSV"); return; }
      massUploadMut.mutate(items);
    };
    reader.readAsText(file);
  }

  // Form state helpers
  const [stockQty, setStockQty] = useState("");
  const [stockReason, setStockReason] = useState("");
  const [adjustQty, setAdjustQty] = useState("");
  const [adjustReason, setAdjustReason] = useState<"damaged" | "expired" | "transferred" | "correction">("damaged");
  const [adjustNote, setAdjustNote] = useState("");
  const [newProduct, setNewProduct] = useState({ name: "", category: "", unit: "pcs", price: "", reorderLevel: "10" });
  const [editProduct, setEditProduct] = useState({ name: "", category: "", unit: "pcs", price: "", reorderLevel: "10" });

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground">Inventory — {activeBranchName}</h2>
          <p className="text-sm text-muted-foreground">{inventory.length} products tracked</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => setShowUpload(true)}>
            <Upload size={14} className="mr-1.5" /> Mass Upload
          </Button>
          <Button size="sm" className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"                 onClick={() => { setNewProduct({ name: "", category: "", unit: "pcs", price: "", reorderLevel: "10" }); setShowAddProduct(true); }}>
            <Plus size={14} className="mr-1.5" /> Add Product
          </Button>
        </div>
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg text-orange-800 text-sm">
          <AlertTriangle size={16} className="flex-shrink-0" />
          <span className="font-medium">{lowStockItems.length} items below reorder level:</span>
          <span className="truncate">{lowStockItems.map((i) => i.productName).join(", ")}</span>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-9 text-sm"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-40 h-9 text-sm">
            <Filter size={12} className="mr-1.5" />
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Inventory Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="text-xs font-semibold cursor-pointer select-none" onClick={() => toggleSort("productName")}>Product {sortField === "productName" ? (sortDir === "asc" ? "↑" : "↓") : ""}</TableHead>
                  <TableHead className="text-xs font-semibold">Category</TableHead>
                  <TableHead className="text-xs font-semibold text-right cursor-pointer select-none" onClick={() => toggleSort("quantity")}>Stock {sortField === "quantity" ? (sortDir === "asc" ? "↑" : "↓") : ""}</TableHead>
                  <TableHead className="text-xs font-semibold text-right cursor-pointer select-none" onClick={() => toggleSort("reorderLevel")}>Reorder At {sortField === "reorderLevel" ? (sortDir === "asc" ? "↑" : "↓") : ""}</TableHead>
                  <TableHead className="text-xs font-semibold text-right">Unit Price</TableHead>
                  <TableHead className="text-xs font-semibold cursor-pointer select-none" onClick={() => toggleSort("status")}>Status {sortField === "status" ? (sortDir === "asc" ? "↑" : "↓") : ""}</TableHead>
                  <TableHead className="text-xs font-semibold text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading
                  ? Array(6).fill(0).map((_, i) => (
                      <TableRow key={i}>
                        {Array(7).fill(0).map((_, j) => (
                          <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                        ))}
                      </TableRow>
                    ))
                  : sorted.map((item) => {
                      const qty = parseFloat(item.quantity);
                      const reorder = parseFloat(item.reorderLevel);
                      const isLow = qty <= reorder;
                      const isCritical = qty <= reorder * 0.5;
                      return (
                        <TableRow key={item.id} className={isLow ? "bg-orange-50/50" : ""}>
                          <TableCell className="font-medium text-sm">{item.productName}</TableCell>
                          <TableCell>
                            <span className="badge-neutral">{item.category ?? "—"}</span>
                          </TableCell>
                          <TableCell className="text-right font-semibold">
                            <span className={isCritical ? "text-red-600" : isLow ? "text-orange-600" : "text-foreground"}>
                              {qty.toFixed(0)} {item.unit}
                            </span>
                          </TableCell>
                          <TableCell className="text-right text-muted-foreground text-sm">
                            {reorder.toFixed(0)} {item.unit}
                          </TableCell>
                          <TableCell className="text-right text-sm">
                            {item.price ? formatPHP(parseFloat(item.price)) : "—"}
                          </TableCell>
                          <TableCell>
                            {isCritical ? (
                              <span className="badge-danger">Critical</span>
                            ) : isLow ? (
                              <span className="badge-warning">Low Stock</span>
                            ) : (
                              <span className="badge-success">OK</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-green-600 hover:bg-green-50"
                                title="Stock In"
                                onClick={() => { setStockQty(""); setStockReason(""); setShowStockIn(item); }}
                              >
                                <ArrowUpCircle size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-orange-600 hover:bg-orange-50"
                                title="Stock Out"
                                onClick={() => { setStockQty(""); setStockReason(""); setShowStockOut(item); }}
                              >
                                <ArrowDownCircle size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-blue-600 hover:bg-blue-50"
                                title="Adjust"
                                onClick={() => { setAdjustQty(""); setAdjustReason("damaged"); setAdjustNote(""); setShowAdjust(item); }}
                              >
                                <Settings2 size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-muted-foreground hover:bg-muted"
                                title="History"
                                onClick={() => setShowLogs(item)}
                              >
                                <History size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-muted-foreground hover:bg-muted"
                                title="Edit"
                                onClick={() => {
                                  const p = allProducts.find((p) => p.id === item.productId);
                                  if (p) { setEditProduct({ name: p.name, category: p.category ?? "", unit: p.unit ?? "pcs", price: p.price ?? "", reorderLevel: item.reorderLevel ?? "10" }); setShowEditProduct({ ...p, inventoryId: item.id }); }
                                }}
                              >
                                <Edit2 size={14} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-destructive hover:bg-red-50"
                                title="Delete"
                                onClick={() => { if (confirm(`Remove ${item.productName}?`)) deleteProductMut.mutate({ id: item.productId }); }}
                              >
                                <Trash2 size={14} />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                {!isLoading && filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                      <Package size={32} className="mx-auto mb-2 opacity-30" />
                      No products found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Stock In Dialog */}
      <Dialog open={!!showStockIn} onOpenChange={() => setShowStockIn(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Stock In — {showStockIn?.productName}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Quantity to Add</label>
              <Input type="number" min="0.01" step="0.01" value={stockQty} onChange={(e) => setStockQty(e.target.value)} placeholder="0" className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Reason (optional)</label>
              <Input value={stockReason} onChange={(e) => setStockReason(e.target.value)} placeholder="e.g. Delivery received" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStockIn(null)}>Cancel</Button>
            <Button
              className="bg-green-600 hover:bg-green-700 text-white"
              disabled={!stockQty || stockInMut.isPending}
              onClick={() => stockInMut.mutate({ branchId: activeBranchId, productId: showStockIn!.productId, quantity: parseFloat(stockQty), reason: stockReason || undefined })}
            >
              Add Stock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock Out Dialog */}
      <Dialog open={!!showStockOut} onOpenChange={() => setShowStockOut(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Stock Out — {showStockOut?.productName}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Quantity to Remove</label>
              <Input type="number" min="0.01" step="0.01" value={stockQty} onChange={(e) => setStockQty(e.target.value)} placeholder="0" className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Reason (optional)</label>
              <Input value={stockReason} onChange={(e) => setStockReason(e.target.value)} placeholder="e.g. Waste" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStockOut(null)}>Cancel</Button>
            <Button
              className="bg-orange-600 hover:bg-orange-700 text-white"
              disabled={!stockQty || stockOutMut.isPending}
              onClick={() => stockOutMut.mutate({ branchId: activeBranchId, productId: showStockOut!.productId, quantity: parseFloat(stockQty), reason: stockReason || undefined })}
            >
              Remove Stock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Adjust Dialog */}
      <Dialog open={!!showAdjust} onOpenChange={() => setShowAdjust(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Adjust — {showAdjust?.productName}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Quantity to Deduct</label>
              <Input type="number" min="0.01" step="0.01" value={adjustQty} onChange={(e) => setAdjustQty(e.target.value)} placeholder="0" className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Reason</label>
              <Select value={adjustReason} onValueChange={(v) => setAdjustReason(v as any)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="damaged">Damaged</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="transferred">Transferred</SelectItem>
                  <SelectItem value="correction">Correction</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Notes (optional)</label>
              <Input value={adjustNote} onChange={(e) => setAdjustNote(e.target.value)} placeholder="Additional notes" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdjust(null)}>Cancel</Button>
            <Button
              className="bg-blue-600 hover:bg-blue-700 text-white"
              disabled={!adjustQty || adjustMut.isPending}
              onClick={() => adjustMut.mutate({ branchId: activeBranchId, productId: showAdjust!.productId, quantity: parseFloat(adjustQty), adjustmentReason: adjustReason, reason: adjustNote || undefined })}
            >
              Apply Adjustment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Inventory Logs Dialog */}
      <Dialog open={!!showLogs} onOpenChange={() => setShowLogs(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>Inventory History — {showLogs?.productName}</DialogTitle></DialogHeader>
          <div className="max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Date/Time</TableHead>
                  <TableHead className="text-xs">Type</TableHead>
                  <TableHead className="text-xs text-right">Qty</TableHead>
                  <TableHead className="text-xs">Reason</TableHead>
                  <TableHead className="text-xs">By</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="text-xs">
                      {new Date(log.timestamp).toLocaleString("en-PH", { timeZone: "Asia/Manila" })}
                    </TableCell>
                    <TableCell>
                      <span className={`text-xs font-medium ${log.type === "stock_in" ? "text-green-600" : log.type === "sale" ? "text-blue-600" : log.type === "adjustment" ? "text-orange-600" : "text-red-600"}`}>
                        {log.type.replace("_", " ").toUpperCase()}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-sm font-semibold">
                      {log.type === "stock_in" ? "+" : "-"}{parseFloat(log.quantity as string).toFixed(0)}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{log.adjustmentReason ?? log.reason ?? "—"}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{log.performedByName ?? "—"}</TableCell>
                  </TableRow>
                ))}
                {logs.length === 0 && (
                  <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">No history yet</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Product Dialog */}
      <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add New Product</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Product Name *</label>
              <Input value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} placeholder="e.g. Siomai (Pork)" className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Category</label>
              <Input value={newProduct.category} onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })} placeholder="e.g. Dimsum" className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Unit</label>
                <Input value={newProduct.unit} onChange={(e) => setNewProduct({ ...newProduct, unit: e.target.value })} placeholder="pcs" className="mt-1" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Price (₱)</label>
                <Input type="number" min="0" step="0.01" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} placeholder="0.00" className="mt-1" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Reorder Level</label>
              <Input type="number" min="0" step="1" value={newProduct.reorderLevel} onChange={(e) => setNewProduct({ ...newProduct, reorderLevel: e.target.value })} placeholder="10" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddProduct(false)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={!newProduct.name || createProductMut.isPending}
              onClick={() => createProductMut.mutate({ name: newProduct.name, category: newProduct.category || undefined, unit: newProduct.unit || undefined, price: newProduct.price ? parseFloat(newProduct.price) : undefined, reorderLevel: newProduct.reorderLevel ? parseFloat(newProduct.reorderLevel) : undefined })}
            >
              Add Product
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Product Dialog */}
      <Dialog open={!!showEditProduct} onOpenChange={() => setShowEditProduct(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Edit Product</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Product Name *</label>
              <Input value={editProduct.name} onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })} className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Category</label>
              <Input value={editProduct.category} onChange={(e) => setEditProduct({ ...editProduct, category: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Unit</label>
                <Input value={editProduct.unit} onChange={(e) => setEditProduct({ ...editProduct, unit: e.target.value })} className="mt-1" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Price (₱)</label>
                <Input type="number" min="0" step="0.01" value={editProduct.price} onChange={(e) => setEditProduct({ ...editProduct, price: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Reorder Level</label>
              <Input type="number" min="0" step="1" value={editProduct.reorderLevel} onChange={(e) => setEditProduct({ ...editProduct, reorderLevel: e.target.value })} className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditProduct(null)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={!editProduct.name || updateProductMut.isPending}
              onClick={() => updateProductMut.mutate({ id: showEditProduct.id, name: editProduct.name, category: editProduct.category || undefined, unit: editProduct.unit || undefined, price: editProduct.price ? parseFloat(editProduct.price) : undefined, reorderLevel: editProduct.reorderLevel ? parseFloat(editProduct.reorderLevel) : undefined })}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mass Upload Dialog */}
      <Dialog open={showUpload} onOpenChange={setShowUpload}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Mass Upload Products via CSV</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-3 bg-muted rounded-lg text-sm">
              <p className="font-medium mb-1">CSV Format:</p>
              <code className="text-xs text-muted-foreground">name,category,unit,price</code>
              <br />
              <code className="text-xs text-muted-foreground">Siomai (Pork),Dimsum,pcs,15.00</code>
            </div>
            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
              onClick={() => csvRef.current?.click()}
            >
              <Upload size={24} className="mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Click to upload CSV file</p>
              <p className="text-xs text-muted-foreground mt-1">or drag and drop</p>
            </div>
            <input ref={csvRef} type="file" accept=".csv" className="hidden" onChange={handleCSVUpload} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUpload(false)}>Cancel</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
