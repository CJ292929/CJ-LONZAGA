import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Search,
  CreditCard,
  Smartphone,
  Banknote,
  CheckCircle,
  Receipt,
  Filter,
} from "lucide-react";

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

type CartItem = {
  productId: number;
  productName: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  unit: string;
};

export default function Sales() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const utils = trpc.useUtils();
  const activeBranchId = selectedBranchId ?? branches[0]?.id ?? 1;
  const activeBranchName = selectedBranch?.name ?? branches.find((b) => b.id === activeBranchId)?.name ?? "Branch";

  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentType, setPaymentType] = useState<"cash" | "GCash" | "card">("cash");
  const [cashierName, setCashierName] = useState("");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showConfirm, setShowConfirm] = useState(false);
  const [showSuccess, setShowSuccess] = useState<{ saleId: number; total: number } | null>(null);

  const { data: inventory = [], isLoading } = trpc.inventory.getByBranch.useQuery(
    { branchId: activeBranchId },
    { enabled: !!activeBranchId }
  );

  const { data: recentSales = [] } = trpc.sales.list.useQuery({
    branchId: activeBranchId,
    limit: 50,
  });

  const createSaleMut = trpc.sales.create.useMutation({
    onSuccess: (data) => {
      utils.inventory.getByBranch.invalidate();
      utils.sales.list.invalidate();
      setShowConfirm(false);
      setShowSuccess({ saleId: data.saleId, total: data.totalAmount });
      setCart([]);
      toast.success(`Sale #${data.saleId} recorded — ${formatPHP(data.totalAmount)}`);
    },
    onError: (e) => toast.error(e.message),
  });

  const categories = useMemo(() => {
    const cats = Array.from(new Set(inventory.map((i) => i.category).filter(Boolean)));
    return cats as string[];
  }, [inventory]);

  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      const matchSearch = item.productName.toLowerCase().includes(search.toLowerCase());
      const matchCat = categoryFilter === "all" || item.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [inventory, search, categoryFilter]);

  const cartTotal = cart.reduce((sum, i) => sum + i.subtotal, 0);
  const cartItemCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  function addToCart(item: typeof inventory[0]) {
    const price = parseFloat(item.price as string) || 0;
    setCart((prev) => {
      const existing = prev.find((c) => c.productId === item.productId);
      if (existing) {
        return prev.map((c) =>
          c.productId === item.productId
            ? { ...c, quantity: c.quantity + 1, subtotal: (c.quantity + 1) * c.unitPrice }
            : c
        );
      }
      return [...prev, {
        productId: item.productId,
        productName: item.productName,
        unitPrice: price,
        quantity: 1,
        subtotal: price,
        unit: item.unit ?? "pcs",
      }];
    });
  }

  function updateQty(productId: number, delta: number) {
    setCart((prev) =>
      prev
        .map((c) =>
          c.productId === productId
            ? { ...c, quantity: Math.max(0, c.quantity + delta), subtotal: Math.max(0, c.quantity + delta) * c.unitPrice }
            : c
        )
        .filter((c) => c.quantity > 0)
    );
  }

  function removeFromCart(productId: number) {
    setCart((prev) => prev.filter((c) => c.productId !== productId));
  }

  function handleCheckout() {
    if (cart.length === 0) { toast.error("Cart is empty"); return; }
    setShowConfirm(true);
  }

  function confirmSale() {
    createSaleMut.mutate({
      branchId: activeBranchId,
      cashierName: cashierName || "Cashier",
      paymentType,
      items: cart.map((c) => ({
        productId: c.productId,
        productName: c.productName,
        quantity: c.quantity,
        unitPrice: c.unitPrice,
        subtotal: c.subtotal,
      })),
    });
  }

  // Today's shift total
  const todayStart = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime() - 8 * 3600000;
  }, []);
  const todaySales = recentSales.filter((s) => s.timestamp >= todayStart && s.status === "completed");
  const shiftTotal = todaySales.reduce((sum, s) => sum + Number(s.totalAmount || 0), 0);

  return (
    <div className="p-5 animate-fade-in">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground">Sales / POS — {activeBranchName}</h2>
          <p className="text-sm text-muted-foreground">
            Today's total: <span className="font-semibold text-[var(--henlin-red)]">{formatPHP(shiftTotal)}</span>
            {" "}({todaySales.length} transactions)
          </p>
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mr-2">Cashier:</label>
          <Input
            value={cashierName}
            onChange={(e) => setCashierName(e.target.value)}
            placeholder="Enter cashier name"
            className="inline-block w-44 h-8 text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Product Grid */}
        <div className="lg:col-span-2 space-y-3">
          {/* Filters */}
          <div className="flex gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[160px]">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-8 text-sm" />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-36 h-8 text-sm">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* Product Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2.5">
            {isLoading
              ? Array(12).fill(0).map((_, i) => <Skeleton key={i} className="h-24 rounded-lg" />)
              : filteredInventory.map((item) => {
                  const inCart = cart.find((c) => c.productId === item.productId);
                  const price = parseFloat(item.price as string) || 0;
                  return (
                    <button
                      key={item.id}
                      className={`pos-product-card text-left relative ${inCart ? "border-[var(--henlin-red)] bg-red-50" : ""}`}
                      onClick={() => addToCart(item)}
                    >
                      {inCart && (
                        <span className="absolute top-1.5 right-1.5 bg-[var(--henlin-red)] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                          {inCart.quantity}
                        </span>
                      )}
                      <div className="text-[10px] text-muted-foreground mb-0.5">{item.category}</div>
                      <div className="text-xs font-semibold text-foreground leading-tight line-clamp-2">{item.productName}</div>
                      <div className="text-sm font-bold text-[var(--henlin-red)] mt-1">{formatPHP(price)}</div>
                      <div className="text-[10px] text-muted-foreground">Stock: {parseFloat(item.quantity as string).toFixed(0)} {item.unit}</div>
                    </button>
                  );
                })}
            {!isLoading && filteredInventory.length === 0 && (
              <div className="col-span-full text-center py-10 text-muted-foreground text-sm">
                No products available
              </div>
            )}
          </div>
        </div>

        {/* Cart */}
        <div className="space-y-3">
          <Card className="sticky top-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <ShoppingCart size={16} />
                Cart
                {cartItemCount > 0 && (
                  <span className="ml-auto bg-[var(--henlin-red)] text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    {cartItemCount}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {cart.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  <ShoppingCart size={28} className="mx-auto mb-2 opacity-30" />
                  Click products to add
                </div>
              ) : (
                <>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {cart.map((item) => (
                      <div key={item.productId} className="flex items-center gap-2 py-1.5 border-b border-border last:border-0">
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium truncate">{item.productName}</p>
                          <p className="text-[10px] text-muted-foreground">{formatPHP(item.unitPrice)} / {item.unit}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button className="w-5 h-5 rounded bg-muted hover:bg-muted/80 flex items-center justify-center" onClick={() => updateQty(item.productId, -1)}>
                            <Minus size={10} />
                          </button>
                          <span className="text-xs font-semibold w-5 text-center">{item.quantity}</span>
                          <button className="w-5 h-5 rounded bg-muted hover:bg-muted/80 flex items-center justify-center" onClick={() => updateQty(item.productId, 1)}>
                            <Plus size={10} />
                          </button>
                        </div>
                        <span className="text-xs font-bold text-foreground w-14 text-right">{formatPHP(item.subtotal)}</span>
                        <button className="text-muted-foreground hover:text-destructive" onClick={() => removeFromCart(item.productId)}>
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Total */}
                  <div className="border-t border-border pt-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-semibold">Total</span>
                      <span className="text-xl font-bold text-[var(--henlin-red)]">{formatPHP(cartTotal)}</span>
                    </div>
                  </div>

                  {/* Payment Type */}
                  <div>
                    <label className="text-xs font-medium text-muted-foreground block mb-1.5">Payment Type</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(["cash", "GCash", "card"] as const).map((type) => (
                        <button
                          key={type}
                          className={`flex flex-col items-center gap-1 py-2 rounded-lg border text-xs font-medium transition-all ${
                            paymentType === type
                              ? "border-[var(--henlin-red)] bg-red-50 text-[var(--henlin-red)]"
                              : "border-border text-muted-foreground hover:border-muted-foreground"
                          }`}
                          onClick={() => setPaymentType(type)}
                        >
                          {type === "cash" ? <Banknote size={14} /> : type === "GCash" ? <Smartphone size={14} /> : <CreditCard size={14} />}
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white font-semibold"
                    onClick={handleCheckout}
                  >
                    Checkout — {formatPHP(cartTotal)}
                  </Button>
                  <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => setCart([])}>
                    Clear Cart
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Sales Table */}
      <div className="mt-6">
        <h3 className="text-base font-semibold mb-3">Recent Transactions</h3>
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="text-xs">#</TableHead>
                    <TableHead className="text-xs">Date/Time</TableHead>
                    <TableHead className="text-xs">Cashier</TableHead>
                    <TableHead className="text-xs">Payment</TableHead>
                    <TableHead className="text-xs text-right">Amount</TableHead>
                    <TableHead className="text-xs">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentSales.slice(0, 20).map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="text-xs font-mono">#{sale.id}</TableCell>
                      <TableCell className="text-xs">
                        {new Date(sale.timestamp).toLocaleString("en-PH", { timeZone: "Asia/Manila", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </TableCell>
                      <TableCell className="text-xs">{sale.cashierName ?? "—"}</TableCell>
                      <TableCell>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                          sale.paymentType === "cash" ? "bg-green-100 text-green-700" : sale.paymentType === "GCash" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
                        }`}>
                          {sale.paymentType}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-semibold text-sm">{formatPHP(Number(sale.totalAmount))}</TableCell>
                      <TableCell>
                        <span className={sale.status === "completed" ? "badge-success" : "badge-danger"}>{sale.status}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                  {recentSales.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground text-sm">
                        <Receipt size={28} className="mx-auto mb-2 opacity-30" />
                        No transactions yet
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirm Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Confirm Sale</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="divide-y divide-border">
              {cart.map((item) => (
                <div key={item.productId} className="flex justify-between py-1.5 text-sm">
                  <span>{item.productName} × {item.quantity}</span>
                  <span className="font-semibold">{formatPHP(item.subtotal)}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-border">
              <span className="font-semibold">Total</span>
              <span className="text-xl font-bold text-[var(--henlin-red)]">{formatPHP(cartTotal)}</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted rounded-lg text-sm">
              {paymentType === "cash" ? <Banknote size={14} /> : paymentType === "GCash" ? <Smartphone size={14} /> : <CreditCard size={14} />}
              <span>Payment via <strong>{paymentType}</strong></span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirm(false)}>Back</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={createSaleMut.isPending}
              onClick={confirmSale}
            >
              {createSaleMut.isPending ? "Processing..." : "Confirm Sale"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <Dialog open={!!showSuccess} onOpenChange={() => setShowSuccess(null)}>
        <DialogContent className="max-w-xs text-center">
          <div className="py-4">
            <CheckCircle size={48} className="mx-auto text-green-500 mb-3" />
            <h3 className="text-lg font-bold">Sale Complete!</h3>
            <p className="text-muted-foreground text-sm mt-1">Transaction #{showSuccess?.saleId}</p>
            <p className="text-2xl font-bold text-[var(--henlin-red)] mt-2">{formatPHP(showSuccess?.total ?? 0)}</p>
          </div>
          <Button className="w-full bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" onClick={() => setShowSuccess(null)}>
            New Sale
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
