import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Search, Edit2, Trash2, Users } from "lucide-react";

export default function StaffPage() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const utils = trpc.useUtils();
  const activeBranchId = selectedBranchId ?? branches[0]?.id ?? 1;
  const activeBranchName = selectedBranch?.name ?? branches.find((b) => b.id === activeBranchId)?.name ?? "Branch";

  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [showEdit, setShowEdit] = useState<any>(null);
  const [form, setForm] = useState({ name: "", position: "" });

  const { data: staffList = [], isLoading, refetch } = trpc.staff.listByBranch.useQuery({ branchId: activeBranchId });

  const createMut = trpc.staff.create.useMutation({
    onSuccess: () => { refetch(); toast.success("Staff added"); setShowAdd(false); },
    onError: (e) => toast.error(e.message),
  });
  const updateMut = trpc.staff.update.useMutation({
    onSuccess: () => { refetch(); toast.success("Staff updated"); setShowEdit(null); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMut = trpc.staff.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("Staff removed"); },
    onError: (e) => toast.error(e.message),
  });

  const filtered = staffList.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold">Staff — {activeBranchName}</h2>
          <p className="text-sm text-muted-foreground">{staffList.length} active staff members</p>
        </div>
        <Button size="sm" className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" onClick={() => { setForm({ name: "", position: "" }); setShowAdd(true); }}>
          <Plus size={14} className="mr-1.5" /> Add Staff
        </Button>
      </div>

      <div className="relative max-w-xs">
        <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search staff..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-9 text-sm" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="text-xs">Name</TableHead>
                <TableHead className="text-xs">Position</TableHead>
                <TableHead className="text-xs">Status</TableHead>
                <TableHead className="text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading
                ? Array(5).fill(0).map((_, i) => (
                    <TableRow key={i}>
                      {Array(4).fill(0).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                    </TableRow>
                  ))
                : filtered.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium text-sm">{s.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{s.position ?? "—"}</TableCell>
                      <TableCell><span className="badge-success">Active</span></TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setForm({ name: s.name, position: s.position ?? "" }); setShowEdit(s); }}>
                            <Edit2 size={13} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-red-50" onClick={() => { if (confirm(`Remove ${s.name}?`)) deleteMut.mutate({ id: s.id }); }}>
                            <Trash2 size={13} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              {!isLoading && filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-10 text-muted-foreground">
                    <Users size={28} className="mx-auto mb-2 opacity-30" />
                    No staff found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add Staff Member</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Full Name *</label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Maria Santos" className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Position</label>
              <Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} placeholder="e.g. Cashier" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={!form.name || createMut.isPending} onClick={() => createMut.mutate({ branchId: activeBranchId, name: form.name, position: form.position || undefined })}>
              Add Staff
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!showEdit} onOpenChange={() => setShowEdit(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Edit Staff</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Full Name *</label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Position</label>
              <Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEdit(null)}>Cancel</Button>
            <Button className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" disabled={!form.name || updateMut.isPending} onClick={() => updateMut.mutate({ id: showEdit.id, name: form.name, position: form.position || undefined })}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
