import { useMemo } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Store, MapPin, Package, AlertTriangle, TrendingUp, ChevronRight } from "lucide-react";

function formatPHP(n: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
}

export default function Branches() {
  const { branches, setSelectedBranchId } = useBranch();
  const [, navigate] = useLocation();

  const todayStart = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime() - 8 * 3600000;
  }, []);

  const { data: inventorySummary = [] } = trpc.inventory.allBranchesSummary.useQuery();
  const { data: salesSummary = [] } = trpc.sales.summary.useQuery({
    branchId: null,
    startTs: todayStart,
    endTs: todayStart + 86400000,
  });

  const invMap = Object.fromEntries(inventorySummary.map((s) => [s.branchId, s]));
  const salesMap = Object.fromEntries(salesSummary.map((s) => [s.branchId, s]));

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      <div>
        <h2 className="text-xl font-bold">Branch Overview</h2>
        <p className="text-sm text-muted-foreground">{branches.length} franchise locations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {branches.map((branch) => {
          const inv = invMap[branch.id];
          const sales = salesMap[branch.id];
          const lowStock = Number(inv?.lowStockCount ?? 0);
          const todaySales = Number(sales?.totalSales ?? 0);

          return (
            <Card
              key={branch.id}
              className="cursor-pointer hover:shadow-md hover:border-[var(--henlin-red)] transition-all duration-150 group"
              onClick={() => { setSelectedBranchId(branch.id); navigate("/inventory"); }}
            >
              <CardHeader className="pb-2">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[var(--henlin-red)] flex items-center justify-center flex-shrink-0">
                    <Store size={16} className="text-white" />
                  </div>
                  <div className="min-w-0">
                    <CardTitle className="text-sm font-semibold leading-tight">{branch.name}</CardTitle>
                    <div className="flex items-center gap-1 mt-0.5">
                      <MapPin size={10} className="text-muted-foreground flex-shrink-0" />
                      <p className="text-[11px] text-muted-foreground truncate">{branch.location}</p>
                    </div>
                  </div>
                  <div className="ml-auto flex items-center gap-1.5 flex-shrink-0">
                    <span className={branch.isActive ? "badge-success" : "badge-neutral"}>
                      {branch.isActive ? "Active" : "Inactive"}
                    </span>
                    <ChevronRight size={13} className="text-muted-foreground group-hover:text-[var(--henlin-red)] transition-colors" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <TrendingUp size={13} className="mx-auto text-[var(--henlin-red)] mb-0.5" />
                    <div className="text-xs font-bold">{formatPHP(todaySales)}</div>
                    <div className="text-[10px] text-muted-foreground">Today</div>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <Package size={13} className="mx-auto text-blue-600 mb-0.5" />
                    <div className="text-xs font-bold">{Number(inv?.totalProducts ?? 0)}</div>
                    <div className="text-[10px] text-muted-foreground">Products</div>
                  </div>
                  <div className={`text-center p-2 rounded-lg ${lowStock > 0 ? "bg-orange-50" : "bg-muted"}`}>
                    <AlertTriangle size={13} className={`mx-auto mb-0.5 ${lowStock > 0 ? "text-orange-500" : "text-muted-foreground"}`} />
                    <div className={`text-xs font-bold ${lowStock > 0 ? "text-orange-600" : ""}`}>{lowStock}</div>
                    <div className="text-[10px] text-muted-foreground">Low Stock</div>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground mt-2 text-center group-hover:text-[var(--henlin-red)] transition-colors">
                  Click to view inventory →
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
