import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Calendar, Plus, CheckCircle, Clock, Users } from "lucide-react";

function getPHTDateStr() {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });
}

const PRESET_SHIFTS = [
  { name: "Morning", startTime: "06:00", endTime: "14:00" },
  { name: "Afternoon", startTime: "14:00", endTime: "22:00" },
  { name: "Full Day", startTime: "08:00", endTime: "17:00" },
];

export default function Shifts() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();
  const utils = trpc.useUtils();
  const activeBranchId = selectedBranchId ?? branches[0]?.id ?? 1;
  const activeBranchName = selectedBranch?.name ?? branches.find((b) => b.id === activeBranchId)?.name ?? "Branch";

  const [selectedDate, setSelectedDate] = useState(getPHTDateStr());
  const [showCreate, setShowCreate] = useState(false);
  const [showAssign, setShowAssign] = useState<number | null>(null);
  const [assignStaffId, setAssignStaffId] = useState("");
  const [newShift, setNewShift] = useState({ name: "Morning", startTime: "06:00", endTime: "14:00" });

  const { data: shifts = [], isLoading, refetch } = trpc.shifts.listByBranch.useQuery({
    branchId: activeBranchId,
    date: selectedDate,
  });

  const { data: staffList = [] } = trpc.staff.listByBranch.useQuery({ branchId: activeBranchId });

  const createMut = trpc.shifts.create.useMutation({
    onSuccess: () => { refetch(); toast.success("Shift created"); setShowCreate(false); },
    onError: (e) => toast.error(e.message),
  });
  const closeMut = trpc.shifts.close.useMutation({
    onSuccess: () => { refetch(); toast.success("Shift closed"); },
    onError: (e) => toast.error(e.message),
  });
  const assignMut = trpc.shifts.assignStaff.useMutation({
    onSuccess: () => { toast.success("Staff assigned"); setShowAssign(null); },
    onError: (e) => toast.error(e.message),
  });

  function applyPreset(preset: typeof PRESET_SHIFTS[0]) {
    setNewShift({ name: preset.name, startTime: preset.startTime, endTime: preset.endTime });
  }

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-foreground">Shifts — {activeBranchName}</h2>
          <p className="text-sm text-muted-foreground">{shifts.length} shifts on {selectedDate}</p>
        </div>
        <div className="flex gap-2">
          <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="w-40 h-9 text-sm" />
          <Button size="sm" className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white" onClick={() => setShowCreate(true)}>
            <Plus size={14} className="mr-1.5" /> New Shift
          </Button>
        </div>
      </div>

      {/* Shifts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading
          ? Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-36 rounded-lg" />)
          : shifts.map((shift) => (
              <Card key={shift.id} className={shift.status === "closed" ? "opacity-75" : ""}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{shift.name}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {shift.startTime} – {shift.endTime}
                      </p>
                    </div>
                    <span className={shift.status === "open" ? "badge-success" : "badge-neutral"}>
                      {shift.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-xs text-muted-foreground">
                    Opened: {shift.openedAt ? new Date(shift.openedAt).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" }) : "—"}
                  </div>
                  {shift.status === "closed" && shift.closedAt && (
                    <div className="text-xs text-muted-foreground">
                      Closed: {new Date(shift.closedAt).toLocaleTimeString("en-PH", { timeZone: "Asia/Manila" })}
                    </div>
                  )}
                  <div className="flex gap-2 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs h-7"
                      onClick={() => { setAssignStaffId(""); setShowAssign(shift.id); }}
                    >
                      <Users size={11} className="mr-1" /> Assign Staff
                    </Button>
                    {shift.status === "open" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 text-xs h-7 text-red-600 hover:bg-red-50"
                        onClick={() => { if (confirm("Close this shift?")) closeMut.mutate({ shiftId: shift.id }); }}
                      >
                        <CheckCircle size={11} className="mr-1" /> Close
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
        {!isLoading && shifts.length === 0 && (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            <Calendar size={32} className="mx-auto mb-2 opacity-30" />
            No shifts for {selectedDate}. Create one to get started.
          </div>
        )}
      </div>

      {/* Create Shift Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Create New Shift</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">Quick Presets</label>
              <div className="flex gap-2">
                {PRESET_SHIFTS.map((p) => (
                  <button
                    key={p.name}
                    className={`flex-1 py-1.5 rounded border text-xs font-medium transition-colors ${
                      newShift.name === p.name ? "border-[var(--henlin-red)] bg-red-50 text-[var(--henlin-red)]" : "border-border text-muted-foreground hover:border-muted-foreground"
                    }`}
                    onClick={() => applyPreset(p)}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Shift Name</label>
              <Input value={newShift.name} onChange={(e) => setNewShift({ ...newShift, name: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Start Time</label>
                <Input type="time" value={newShift.startTime} onChange={(e) => setNewShift({ ...newShift, startTime: e.target.value })} className="mt-1" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">End Time</label>
                <Input type="time" value={newShift.endTime} onChange={(e) => setNewShift({ ...newShift, endTime: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Date</label>
              <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={!newShift.name || createMut.isPending}
              onClick={() => createMut.mutate({ branchId: activeBranchId, name: newShift.name, startTime: newShift.startTime, endTime: newShift.endTime, date: selectedDate })}
            >
              Create Shift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Staff Dialog */}
      <Dialog open={!!showAssign} onOpenChange={() => setShowAssign(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Assign Staff to Shift</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Select value={assignStaffId} onValueChange={setAssignStaffId}>
              <SelectTrigger><SelectValue placeholder="Choose staff member..." /></SelectTrigger>
              <SelectContent>
                {staffList.map((s) => (
                  <SelectItem key={s.id} value={String(s.id)}>{s.name} — {s.position}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssign(null)}>Cancel</Button>
            <Button
              className="bg-[var(--henlin-red)] hover:bg-[var(--henlin-red-dark)] text-white"
              disabled={!assignStaffId || assignMut.isPending}
              onClick={() => assignMut.mutate({ shiftId: showAssign!, staffId: parseInt(assignStaffId), branchId: activeBranchId })}
            >
              Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
