import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useBranch } from "@/contexts/BranchContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import {
  TrendingUp,
  Package,
  AlertTriangle,
  Users,
  ShoppingCart,
  Store,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";

const COLORS = ["#C62828", "#FFC107", "#2E7D32", "#1565C0", "#6A1B9A"];

function formatPHP(amount: number) {
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(amount);
}

function getPHTDate(offsetDays = 0) {
  const now = new Date();
  const pht = new Date(now.getTime() + 8 * 3600000);
  pht.setDate(pht.getDate() + offsetDays);
  return pht;
}

export default function Dashboard() {
  const { selectedBranchId, selectedBranch, branches } = useBranch();

  const todayStart = useMemo(() => {
    const d = getPHTDate();
    d.setHours(0, 0, 0, 0);
    return d.getTime() - 8 * 3600000;
  }, []);
  const todayEnd = useMemo(() => todayStart + 86400000, [todayStart]);

  const weekStart = useMemo(() => todayStart - 6 * 86400000, [todayStart]);

  const { data: todaySummary, isLoading: loadingSales } = trpc.sales.summary.useQuery({
    branchId: selectedBranchId ?? null,
    startTs: todayStart,
    endTs: todayEnd,
  });

  const { data: weeklySales } = trpc.sales.list.useQuery({
    branchId: selectedBranchId ?? null,
    startTs: weekStart,
    endTs: todayEnd,
    limit: 500,
  });

  const { data: inventorySummary, isLoading: loadingInv } = trpc.inventory.allBranchesSummary.useQuery();
  const { data: topProducts } = trpc.sales.topProducts.useQuery({
    branchId: selectedBranchId ?? null,
    startTs: weekStart,
    endTs: todayEnd,
  });

  const { data: recentSales } = trpc.sales.list.useQuery({
    branchId: selectedBranchId ?? null,
    startTs: weekStart,
    endTs: todayEnd,
    limit: 8,
  });

  // Aggregate today's totals
  const todayTotal = todaySummary?.reduce((sum, s) => sum + Number(s.totalSales || 0), 0) ?? 0;
  const todayTxCount = todaySummary?.reduce((sum, s) => sum + Number(s.transactionCount || 0), 0) ?? 0;

  // Low stock count
  const totalLowStock = inventorySummary?.reduce((sum, b) => sum + Number(b.lowStockCount || 0), 0) ?? 0;
  const activeBranches = branches.filter((b) => b.isActive).length;

  // Build daily chart data for last 7 days
  const dailyChartData = useMemo(() => {
    const days: { date: string; sales: number; transactions: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = getPHTDate(-i);
      const label = d.toLocaleDateString("en-PH", { month: "short", day: "numeric", timeZone: "Asia/Manila" });
      const dayStart = new Date(d);
      dayStart.setHours(0, 0, 0, 0);
      const dayStartTs = dayStart.getTime() - 8 * 3600000;
      const dayEndTs = dayStartTs + 86400000;
      const daySales = weeklySales?.filter((s) => s.timestamp >= dayStartTs && s.timestamp < dayEndTs) ?? [];
      days.push({
        date: label,
        sales: daySales.reduce((sum, s) => sum + Number(s.totalAmount || 0), 0),
        transactions: daySales.length,
      });
    }
    return days;
  }, [weeklySales]);

  // Payment type breakdown
  const paymentBreakdown = useMemo(() => {
    if (!todaySummary) return [];
    const cash = todaySummary.reduce((s, b) => s + Number(b.cashSales || 0), 0);
    const gcash = todaySummary.reduce((s, b) => s + Number(b.gcashSales || 0), 0);
    const card = todaySummary.reduce((s, b) => s + Number(b.cardSales || 0), 0);
    return [
      { name: "Cash", value: cash },
      { name: "GCash", value: gcash },
      { name: "Card", value: card },
    ].filter((p) => p.value > 0);
  }, [todaySummary]);

  // Branch sales breakdown
  const branchSalesData = useMemo(() => {
    if (!todaySummary) return [];
    return todaySummary
      .map((b) => ({ name: b.branchName?.split(" ").slice(0, 2).join(" ") ?? "", sales: Number(b.totalSales || 0) }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 8);
  }, [todaySummary]);

  const StatCard = ({
    title,
    value,
    sub,
    icon: Icon,
    color,
    loading,
  }: {
    title: string;
    value: string;
    sub?: string;
    icon: any;
    color: string;
    loading?: boolean;
  }) => (
    <Card className="animate-fade-in">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
            {loading ? (
              <Skeleton className="h-7 w-28 mt-1" />
            ) : (
              <p className="text-2xl font-bold text-foreground mt-0.5">{value}</p>
            )}
            {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
          </div>
          <div className={`p-2.5 rounded-lg ${color} flex-shrink-0`}>
            <Icon size={18} className="text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="p-5 space-y-5 animate-fade-in">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-foreground">
          {selectedBranch ? selectedBranch.name : "All Branches"} — Dashboard
        </h2>
        <p className="text-sm text-muted-foreground mt-0.5">
          {new Date().toLocaleDateString("en-PH", {
            timeZone: "Asia/Manila",
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Today's Sales"
          value={formatPHP(todayTotal)}
          sub={`${todayTxCount} transactions`}
          icon={TrendingUp}
          color="bg-[var(--henlin-red)]"
          loading={loadingSales}
        />
        <StatCard
          title="Active Branches"
          value={String(activeBranches)}
          sub="franchise locations"
          icon={Store}
          color="bg-[var(--henlin-gold-dark)]"
        />
        <StatCard
          title="Low Stock Alerts"
          value={String(totalLowStock)}
          sub="items below reorder"
          icon={AlertTriangle}
          color={totalLowStock > 0 ? "bg-orange-500" : "bg-green-600"}
          loading={loadingInv}
        />
        <StatCard
          title="Total Products"
          value={String(inventorySummary?.[0]?.totalProducts ?? "—")}
          sub="tracked items"
          icon={Package}
          color="bg-blue-600"
          loading={loadingInv}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Sales Trend */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Sales Trend — Last 7 Days</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={dailyChartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C62828" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#C62828" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₱${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatPHP(v)} />
                <Area
                  type="monotone"
                  dataKey="sales"
                  stroke="#C62828"
                  strokeWidth={2}
                  fill="url(#salesGrad)"
                  name="Sales"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Payment Breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Today's Payment Types</CardTitle>
          </CardHeader>
          <CardContent>
            {paymentBreakdown.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={paymentBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {paymentBreakdown.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number) => formatPHP(v)} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-muted-foreground text-sm">
                No sales today
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top Products */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Top Products (This Week)</CardTitle>
          </CardHeader>
          <CardContent>
            {topProducts && topProducts.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={topProducts.slice(0, 6)} layout="vertical" margin={{ left: 0, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis type="number" tick={{ fontSize: 10 }} tickFormatter={(v) => `₱${(v / 1000).toFixed(0)}k`} />
                  <YAxis
                    type="category"
                    dataKey="productName"
                    tick={{ fontSize: 10 }}
                    width={90}
                    tickFormatter={(v) => v.length > 12 ? v.slice(0, 12) + "…" : v}
                  />
                  <Tooltip formatter={(v: number) => formatPHP(v)} />
                  <Bar dataKey="totalRevenue" fill="#C62828" name="Revenue" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-muted-foreground text-sm">
                No sales data this week
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {recentSales && recentSales.length > 0 ? (
                recentSales.slice(0, 7).map((sale) => (
                  <div key={sale.id} className="flex items-center justify-between px-5 py-2.5">
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {sale.branchName}
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        {new Date(sale.timestamp).toLocaleTimeString("en-PH", {
                          timeZone: "Asia/Manila",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}{" "}
                        · {sale.cashierName}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                          sale.paymentType === "cash"
                            ? "bg-green-100 text-green-700"
                            : sale.paymentType === "GCash"
                            ? "bg-blue-100 text-blue-700"
                            : "bg-purple-100 text-purple-700"
                        }`}
                      >
                        {sale.paymentType}
                      </span>
                      <span className="text-sm font-semibold text-foreground">
                        {formatPHP(Number(sale.totalAmount))}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex items-center justify-center h-[200px] text-muted-foreground text-sm">
                  No recent transactions
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Branch Overview */}
      {!selectedBranchId && branchSalesData.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Today's Sales by Branch</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={branchSalesData} margin={{ top: 5, right: 10, left: 0, bottom: 40 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 10 }}
                  angle={-35}
                  textAnchor="end"
                  interval={0}
                />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `₱${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatPHP(v)} />
                <Bar dataKey="sales" fill="#FFC107" name="Sales" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
