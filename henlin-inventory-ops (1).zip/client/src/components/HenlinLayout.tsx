import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useBranch } from "@/contexts/BranchContext";
import { trpc as trpcClient } from "@/lib/trpc";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Store,
  Package,
  ShoppingCart,
  Clock,
  Calendar,
  BarChart3,
  Users,
  ChevronDown,
  Menu,
  X,
  LogOut,
  Bell,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen,
  ShieldCheck,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const LOGO_URL = "/manus-storage/henlin-logo_a8ae97b6.jpg";

const navGroups = [
  {
    label: "Overview",
    items: [
      { href: "/", icon: LayoutDashboard, label: "Dashboard" },
      { href: "/branches", icon: Store, label: "Branches" },
    ],
  },
  {
    label: "Operations",
    items: [
      { href: "/inventory", icon: Package, label: "Inventory" },
      { href: "/sales", icon: ShoppingCart, label: "Sales / POS" },
    ],
  },
  {
    label: "Workforce",
    items: [
      { href: "/time-records", icon: Clock, label: "Time Records" },
      { href: "/shifts", icon: Calendar, label: "Shifts" },
      { href: "/staff", icon: Users, label: "Staff" },
    ],
  },
  {
    label: "Analytics",
    items: [
      { href: "/reports", icon: BarChart3, label: "Reports" },
    ],
  },
  {
    label: "Admin",
    items: [
      { href: "/branch-accounts", icon: ShieldCheck, label: "Branch Accounts" },
    ],
  },
];

function NavItem({
  href,
  icon: Icon,
  label,
  collapsed,
  onClick,
}: {
  href: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  collapsed?: boolean;
  onClick?: () => void;
}) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));

  if (collapsed) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Link
            href={href}
            className={`henlin-nav-item justify-center px-0 w-10 h-10 mx-auto ${isActive ? "active" : ""}`}
            onClick={onClick}
          >
            <Icon size={17} />
          </Link>
        </TooltipTrigger>
        <TooltipContent side="right" className="text-xs">{label}</TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Link
      href={href}
      className={`henlin-nav-item ${isActive ? "active" : ""}`}
      onClick={onClick}
    >
      <Icon size={16} />
      <span>{label}</span>
      {isActive && <ChevronRight size={12} className="ml-auto opacity-60" />}
    </Link>
  );
}

interface HenlinLayoutProps {
  children: React.ReactNode;
}

export default function HenlinLayout({ children }: HenlinLayoutProps) {
  // Start expanded on wide screens, collapsed on narrow
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { user, logout } = useAuth();
  const { branches, selectedBranchId, setSelectedBranchId } = useBranch();
  const { data: inventorySummary } = trpcClient.inventory.allBranchesSummary.useQuery();
  const [location] = useLocation();

  // Close mobile sidebar on route change
  useEffect(() => {
    setMobileSidebarOpen(false);
  }, [location]);

  const totalLowStock =
    inventorySummary?.reduce((sum, b) => sum + (Number(b.lowStockCount) || 0), 0) ?? 0;

  // ── Sidebar inner content ──────────────────────────────────────
  const SidebarContent = ({
    collapsed = false,
    onNavClick,
  }: {
    collapsed?: boolean;
    onNavClick?: () => void;
  }) => (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Logo */}
      <div className={`flex items-center gap-3 px-3 py-4 border-b border-[var(--sidebar-border)] flex-shrink-0 ${collapsed ? "justify-center" : ""}`}>
        <div className="w-9 h-9 rounded-lg overflow-hidden bg-[var(--henlin-gold)] flex items-center justify-center flex-shrink-0">
          <img
            src={LOGO_URL}
            alt="Henlin"
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
          />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="text-white font-bold text-sm leading-tight tracking-wide">HENLIN</div>
            <div className="text-[var(--henlin-gold)] text-[10px] font-medium leading-tight uppercase tracking-wider">Operations Hub</div>
          </div>
        )}
      </div>

      {/* Branch Switcher */}
      {!collapsed && (
        <div className="px-3 py-3 border-b border-[var(--sidebar-border)] flex-shrink-0">
          <div className="text-[10px] uppercase tracking-wider text-[var(--sidebar-muted)] mb-1.5 px-1">Active Branch</div>
          <Select
            value={selectedBranchId === null ? "all" : String(selectedBranchId)}
            onValueChange={(v) => setSelectedBranchId(v === "all" ? null : parseInt(v))}
          >
            <SelectTrigger className="h-8 text-xs bg-[var(--sidebar-hover)] border-[var(--sidebar-border)] text-[var(--sidebar-text)] focus:ring-[var(--henlin-red)]">
              <SelectValue placeholder="Select branch" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Branches</SelectItem>
              {branches.map((b) => (
                <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Navigation */}
      <nav className={`flex-1 overflow-y-auto py-3 space-y-4 ${collapsed ? "px-1" : "px-3"}`}>
        {navGroups.map((group) => (
          <div key={group.label}>
            {!collapsed && (
              <div className="text-[10px] uppercase tracking-wider text-[var(--sidebar-muted)] mb-1.5 px-1">{group.label}</div>
            )}
            {collapsed && <div className="my-1 border-t border-[var(--sidebar-border)]" />}
            <div className="space-y-0.5">
              {group.items.map((item) => (
                <NavItem
                  key={item.href}
                  {...item}
                  collapsed={collapsed}
                  onClick={onNavClick}
                />
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* User Footer */}
      <div className={`py-3 border-t border-[var(--sidebar-border)] flex-shrink-0 ${collapsed ? "px-1" : "px-3"}`}>
        {collapsed ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="w-10 h-10 mx-auto flex items-center justify-center rounded-md hover:bg-[var(--sidebar-hover)] transition-colors"
                onClick={logout}
              >
                <Avatar className="w-7 h-7">
                  <AvatarFallback className="bg-[var(--henlin-red)] text-white text-xs font-bold">
                    {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
                  </AvatarFallback>
                </Avatar>
              </button>
            </TooltipTrigger>
            <TooltipContent side="right" className="text-xs">{user?.name ?? "User"}</TooltipContent>
          </Tooltip>
        ) : (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-[var(--sidebar-hover)] transition-colors text-left">
                <Avatar className="w-7 h-7 flex-shrink-0">
                  <AvatarFallback className="bg-[var(--henlin-red)] text-white text-xs font-bold">
                    {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-[var(--sidebar-text)] truncate">{user?.name ?? "User"}</div>
                  <div className="text-[10px] text-[var(--sidebar-muted)] truncate capitalize">{user?.role ?? "staff"}</div>
                </div>
                <ChevronDown size={12} className="text-[var(--sidebar-muted)] flex-shrink-0" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="w-48">
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="text-destructive cursor-pointer">
                <LogOut size={14} className="mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* ── Desktop Sidebar ── always visible, collapsible */}
      <aside
        className={`hidden sm:flex flex-col flex-shrink-0 henlin-sidebar transition-all duration-200 ${
          sidebarCollapsed ? "w-14" : "w-56"
        }`}
      >
        <SidebarContent collapsed={sidebarCollapsed} />
      </aside>

      {/* ── Mobile Sidebar Overlay ── */}
      {mobileSidebarOpen && (
        <div className="sm:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <aside className="relative flex flex-col w-64 henlin-sidebar z-10 shadow-2xl">
            <button
              className="absolute top-3 right-3 text-[var(--sidebar-muted)] hover:text-white p-1 rounded transition-colors z-10"
              onClick={() => setMobileSidebarOpen(false)}
              aria-label="Close menu"
            >
              <X size={18} />
            </button>
            <SidebarContent onNavClick={() => setMobileSidebarOpen(false)} />
          </aside>
        </div>
      )}

      {/* ── Main Content ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Bar */}
        <header className="flex items-center gap-2 px-3 py-2 bg-white border-b border-border flex-shrink-0 shadow-sm">
          {/* Mobile hamburger */}
          <button
            className="sm:hidden p-2 rounded-md hover:bg-muted transition-colors text-foreground flex-shrink-0"
            onClick={() => setMobileSidebarOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>

          {/* Desktop sidebar toggle */}
          <button
            className="hidden sm:flex p-1.5 rounded-md hover:bg-muted transition-colors text-muted-foreground flex-shrink-0"
            onClick={() => setSidebarCollapsed((v) => !v)}
            aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {sidebarCollapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}
          </button>

          {/* Mobile logo */}
          <div className="sm:hidden flex items-center gap-2">
            <div className="w-7 h-7 rounded overflow-hidden bg-[var(--henlin-gold)]">
              <img src={LOGO_URL} alt="Henlin" className="w-full h-full object-cover" />
            </div>
            <span className="text-sm font-bold text-[var(--henlin-red)]">HENLIN</span>
          </div>

          {/* Desktop title */}
          <div className="hidden sm:block flex-1 min-w-0">
            <h1 className="text-sm font-semibold text-foreground truncate">Henlin Franchise Operations</h1>
          </div>

          <div className="flex-1 sm:flex-none" />

          {/* Low stock alert */}
          {totalLowStock > 0 && (
            <button
              className="flex items-center gap-1.5 px-2 py-1.5 bg-red-50 text-red-700 rounded-md text-xs font-medium hover:bg-red-100 transition-colors border border-red-200 flex-shrink-0"
              onClick={() => toast.warning(`${totalLowStock} items are below reorder level across all branches!`)}
            >
              <Bell size={13} className="animate-pulse" />
              <span className="hidden xs:inline">{totalLowStock} Low Stock</span>
              <span className="xs:hidden">{totalLowStock}</span>
            </button>
          )}

          {/* Date */}
          <div className="text-xs text-muted-foreground hidden md:block whitespace-nowrap flex-shrink-0">
            {new Date().toLocaleDateString("en-PH", {
              timeZone: "Asia/Manila",
              weekday: "short",
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background">
          {children}
        </main>
      </div>
    </div>
  );
}
