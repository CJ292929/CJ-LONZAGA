import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useBranchSession } from "@/contexts/BranchSessionContext";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Clock,
  Calendar,
  Users,
  BarChart3,
  Menu,
  X,
  LogOut,
  Bell,
  ChevronRight,
  Store,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const LOGO_URL = "/manus-storage/henlin-logo_a8ae97b6.jpg";

const navItems = [
  { href: "/branch", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/branch/inventory", icon: Package, label: "Inventory" },
  { href: "/branch/sales", icon: ShoppingCart, label: "Sales / POS" },
  { href: "/branch/time-records", icon: Clock, label: "Time Records" },
  { href: "/branch/shifts", icon: Calendar, label: "Shifts" },
  { href: "/branch/staff", icon: Users, label: "Staff" },
  { href: "/branch/reports", icon: BarChart3, label: "Reports" },
];

function NavItem({
  href,
  icon: Icon,
  label,
  collapsed,
  onClick,
}: {
  href: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  collapsed?: boolean;
  onClick?: () => void;
}) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/branch" && location.startsWith(href));

  if (collapsed) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Link
            href={href}
            className={`henlin-nav-item justify-center px-0 w-10 h-10 mx-auto ${isActive ? "active" : ""}`}
            onClick={onClick}
          >
            <Icon size={17} />
          </Link>
        </TooltipTrigger>
        <TooltipContent side="right" className="text-xs">{label}</TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Link
      href={href}
      className={`henlin-nav-item ${isActive ? "active" : ""}`}
      onClick={onClick}
    >
      <Icon size={16} />
      <span>{label}</span>
      {isActive && <ChevronRight size={12} className="ml-auto opacity-60" />}
    </Link>
  );
}

interface BranchLayoutProps {
  children: React.ReactNode;
}

export default function BranchLayout({ children }: BranchLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { session, logout } = useBranchSession();
  const [location] = useLocation();

  const { data: branches = [] } = trpc.branches.list.useQuery();
  const branchName = branches.find((b) => b.id === session?.branchId)?.name ?? "Branch";

  const { data: inventorySummary } = trpc.inventory.allBranchesSummary.useQuery();
  const branchLowStock = inventorySummary?.find((b) => Number(b.branchId) === session?.branchId);
  const lowStockCount = Number(branchLowStock?.lowStockCount ?? 0);

  useEffect(() => {
    setMobileSidebarOpen(false);
  }, [location]);

  const SidebarContent = ({
    collapsed = false,
    onNavClick,
  }: {
    collapsed?: boolean;
    onNavClick?: () => void;
  }) => (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Logo + Branch Name */}
      <div className={`flex items-center gap-3 px-3 py-4 border-b border-[var(--sidebar-border)] flex-shrink-0 ${collapsed ? "justify-center" : ""}`}>
        <div className="w-9 h-9 rounded-lg overflow-hidden bg-[var(--henlin-gold)] flex items-center justify-center flex-shrink-0">
          <img
            src={LOGO_URL}
            alt="Henlin"
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
          />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="text-white font-bold text-sm leading-tight tracking-wide">HENLIN</div>
            <div className="text-[var(--henlin-gold)] text-[10px] font-medium leading-tight uppercase tracking-wider">Branch Portal</div>
          </div>
        )}
      </div>

      {/* Branch Badge */}
      {!collapsed && (
        <div className="px-3 py-3 border-b border-[var(--sidebar-border)] flex-shrink-0">
          <div className="flex items-center gap-2 px-2 py-2 bg-[var(--henlin-red)]/20 rounded-md border border-[var(--henlin-red)]/30">
            <Store size={13} className="text-[var(--henlin-gold)] flex-shrink-0" />
            <div className="min-w-0">
              <div className="text-[10px] text-[var(--sidebar-muted)] uppercase tracking-wider">Active Branch</div>
              <div className="text-xs font-semibold text-white truncate">{branchName}</div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className={`flex-1 overflow-y-auto py-3 ${collapsed ? "px-1" : "px-3"}`}>
        <div className="space-y-0.5">
          {navItems.map((item) => (
            <NavItem
              key={item.href}
              {...item}
              collapsed={collapsed}
              onClick={onNavClick}
            />
          ))}
        </div>
      </nav>

      {/* User Footer */}
      <div className={`py-3 border-t border-[var(--sidebar-border)] flex-shrink-0 ${collapsed ? "px-1" : "px-3"}`}>
        {collapsed ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="w-10 h-10 mx-auto flex items-center justify-center rounded-md hover:bg-[var(--sidebar-hover)] transition-colors"
                onClick={logout}
              >
                <LogOut size={15} className="text-[var(--sidebar-muted)]" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right" className="text-xs">Sign Out</TooltipContent>
          </Tooltip>
        ) : (
          <div className="flex items-center gap-2.5 px-2 py-2">
            <Avatar className="w-7 h-7 flex-shrink-0">
              <AvatarFallback className="bg-[var(--henlin-red)] text-white text-xs font-bold">
                {session?.username?.charAt(0)?.toUpperCase() ?? "B"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-[var(--sidebar-text)] truncate">{session?.username ?? "branch"}</div>
              <div className="text-[10px] text-[var(--sidebar-muted)] capitalize">{session?.role?.replace("_", " ") ?? "manager"}</div>
            </div>
            <button
              className="p-1.5 rounded hover:bg-[var(--sidebar-hover)] transition-colors text-[var(--sidebar-muted)] hover:text-red-400"
              onClick={logout}
              title="Sign Out"
            >
              <LogOut size={13} />
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden sm:flex flex-col flex-shrink-0 henlin-sidebar transition-all duration-200 ${
          sidebarCollapsed ? "w-14" : "w-56"
        }`}
      >
        <SidebarContent collapsed={sidebarCollapsed} />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {mobileSidebarOpen && (
        <div className="sm:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <aside className="relative flex flex-col w-64 henlin-sidebar z-10 shadow-2xl">
            <button
              className="absolute top-3 right-3 text-[var(--sidebar-muted)] hover:text-white p-1 rounded transition-colors z-10"
              onClick={() => setMobileSidebarOpen(false)}
            >
              <X size={18} />
            </button>
            <SidebarContent onNavClick={() => setMobileSidebarOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Bar */}
        <header className="flex items-center gap-2 px-3 py-2 bg-white border-b border-border flex-shrink-0 shadow-sm">
          {/* Mobile hamburger */}
          <button
            className="sm:hidden p-2 rounded-md hover:bg-muted transition-colors"
            onClick={() => setMobileSidebarOpen(true)}
          >
            <Menu size={20} />
          </button>

          {/* Desktop sidebar toggle */}
          <button
            className="hidden sm:flex p-1.5 rounded-md hover:bg-muted transition-colors text-muted-foreground"
            onClick={() => setSidebarCollapsed((v) => !v)}
          >
            {sidebarCollapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}
          </button>

          {/* Mobile logo */}
          <div className="sm:hidden flex items-center gap-2">
            <div className="w-7 h-7 rounded overflow-hidden bg-[var(--henlin-gold)]">
              <img src={LOGO_URL} alt="Henlin" className="w-full h-full object-cover" />
            </div>
            <span className="text-sm font-bold text-[var(--henlin-red)]">HENLIN</span>
          </div>

          {/* Branch name */}
          <div className="hidden sm:flex items-center gap-2 flex-1 min-w-0">
            <Store size={14} className="text-[var(--henlin-red)] flex-shrink-0" />
            <h1 className="text-sm font-semibold text-foreground truncate">{branchName}</h1>
            <span className="text-xs text-muted-foreground hidden md:block">— Branch Portal</span>
          </div>

          <div className="flex-1 sm:flex-none" />

          {/* Low stock alert */}
          {lowStockCount > 0 && (
            <button
              className="flex items-center gap-1.5 px-2 py-1.5 bg-red-50 text-red-700 rounded-md text-xs font-medium hover:bg-red-100 transition-colors border border-red-200 flex-shrink-0"
              onClick={() => toast.warning(`${lowStockCount} items are below reorder level in your branch!`)}
            >
              <Bell size={13} className="animate-pulse" />
              <span>{lowStockCount} Low Stock</span>
            </button>
          )}

          {/* Date */}
          <div className="text-xs text-muted-foreground hidden md:block whitespace-nowrap flex-shrink-0">
            {new Date().toLocaleDateString("en-PH", {
              timeZone: "Asia/Manila",
              weekday: "short",
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background">
          {children}
        </main>
      </div>
    </div>
  );
}
