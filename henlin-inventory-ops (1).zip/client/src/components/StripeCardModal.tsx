import { useState, useEffect } from "react";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  CardElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, CreditCard, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY ?? "");

const CARD_ELEMENT_OPTIONS = {
  style: {
    base: {
      fontSize: "16px",
      color: "#1a1a1a",
      fontFamily: "'Inter', sans-serif",
      "::placeholder": { color: "#9ca3af" },
    },
    invalid: { color: "#ef4444" },
  },
};

interface StripeCardFormProps {
  clientSecret: string;
  amount: number;
  onSuccess: (paymentIntentId: string) => void;
  onCancel: () => void;
}

function StripeCardForm({ clientSecret, amount, onSuccess, onCancel }: StripeCardFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [succeeded, setSucceeded] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setLoading(true);
    setError(null);

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) return;

    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: { card: cardElement },
    });

    setLoading(false);

    if (stripeError) {
      setError(stripeError.message ?? "Payment failed");
      toast.error("Payment failed: " + stripeError.message);
    } else if (paymentIntent?.status === "succeeded") {
      setSucceeded(true);
      toast.success("Payment successful!");
      setTimeout(() => onSuccess(paymentIntent.id), 1200);
    }
  };

  if (succeeded) {
    return (
      <div className="flex flex-col items-center gap-4 py-8">
        <CheckCircle className="w-16 h-16 text-green-500" />
        <p className="text-lg font-semibold text-green-700">Payment Successful!</p>
        <p className="text-sm text-gray-500">Recording sale...</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <div className="flex items-center gap-2 mb-3">
          <CreditCard className="w-4 h-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Card Details</span>
        </div>
        <CardElement options={CARD_ELEMENT_OPTIONS} />
      </div>

      {error && (
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-3">
          <XCircle className="w-4 h-4 flex-shrink-0" />
          <span className="text-sm">{error}</span>
        </div>
      )}

      <div className="bg-henlin-red/5 border border-henlin-red/20 rounded-lg p-3 text-center">
        <p className="text-sm text-gray-600">Amount to charge</p>
        <p className="text-2xl font-bold text-henlin-red">
          ₱{amount.toLocaleString("en-PH", { minimumFractionDigits: 2 })}
        </p>
      </div>

      <div className="flex gap-3">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1" disabled={loading}>
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={!stripe || loading}
          className="flex-1 bg-henlin-red hover:bg-henlin-red/90 text-white"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <CreditCard className="w-4 h-4 mr-2" />
              Pay ₱{amount.toLocaleString("en-PH", { minimumFractionDigits: 2 })}
            </>
          )}
        </Button>
      </div>

      <p className="text-xs text-center text-gray-400">
        🔒 Secured by Stripe · Test card: 4242 4242 4242 4242
      </p>
    </form>
  );
}

interface StripeCardModalProps {
  open: boolean;
  clientSecret: string | null;
  amount: number;
  onSuccess: (paymentIntentId: string) => void;
  onClose: () => void;
}

export function StripeCardModal({ open, clientSecret, amount, onSuccess, onClose }: StripeCardModalProps) {
  if (!clientSecret) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-henlin-red" />
            Card Payment
          </DialogTitle>
        </DialogHeader>
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <StripeCardForm
            clientSecret={clientSecret}
            amount={amount}
            onSuccess={onSuccess}
            onCancel={onClose}
          />
        </Elements>
      </DialogContent>
    </Dialog>
  );
}
