import mysql from 'mysql2/promise';

async function run() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  console.log('Connected');

  // Get all product IDs and their reorder levels from the DB
  const [productRows] = await conn.execute(
    'SELECT id FROM products WHERE isActive = 1 ORDER BY id'
  );
  const [branchRows] = await conn.execute('SELECT id FROM branches ORDER BY id');

  console.log(`Products: ${productRows.length}, Branches: ${branchRows.length}`);

  // Reorder levels from the original Excel (same order as products were inserted)
  const reorderLevels = [
    50, 40, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, // Dimsum & Meals
    20, 20, 20, 20, // Hopia
    20, 20, 20, 20, 20, 20, 20, // Beverages
    20, 20, 20, 20, 20, 20, // Raw Ingredients (meats/noodles)
    20, 20, 20, 20, 20, 20, // Sauces
    20, 20, 20, 20, // Seasoning + wrapper
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20, // More ingredients
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, // Packaging
    20, 20, 20, 20, 20, 20, 20, 20, 20, // Supplies
  ];

  // Build bulk insert values
  const values = [];
  for (const branch of branchRows) {
    for (let i = 0; i < productRows.length; i++) {
      const productId = productRows[i].id;
      const reorderLevel = reorderLevels[i] ?? 20;
      values.push(`(${branch.id}, ${productId}, '0', '${reorderLevel}')`);
    }
  }

  // Delete any existing branch_inventory first
  await conn.execute('DELETE FROM branch_inventory');
  console.log('Cleared existing branch_inventory');

  // Bulk insert in chunks of 500
  const chunkSize = 500;
  let inserted = 0;
  for (let i = 0; i < values.length; i += chunkSize) {
    const chunk = values.slice(i, i + chunkSize);
    await conn.execute(
      `INSERT INTO branch_inventory (branchId, productId, quantity, reorderLevel) VALUES ${chunk.join(',')}`
    );
    inserted += chunk.length;
    console.log(`Inserted ${inserted}/${values.length} inventory records`);
  }

  await conn.end();
  console.log(`Done! Seeded ${inserted} branch_inventory records across ${branchRows.length} branches.`);
}

run().catch(e => { console.error(e); process.exit(1); });
