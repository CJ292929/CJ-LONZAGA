import 'dotenv/config';
import mysql from 'mysql2/promise';

const conn = await mysql.createConnection(process.env.DATABASE_URL);

console.log('Finding duplicate branch_inventory rows...');
const [dups] = await conn.query(
  'SELECT branchId, productId, COUNT(*) as cnt FROM branch_inventory GROUP BY branchId, productId HAVING COUNT(*) > 1'
);
console.log(`Found ${dups.length} duplicate groups`);

for (const dup of dups) {
  // Get all rows for this branch+product, keep the one with highest quantity (most recent meaningful value)
  const [rows] = await conn.query(
    'SELECT id, quantity FROM branch_inventory WHERE branchId = ? AND productId = ? ORDER BY quantity DESC, id ASC',
    [dup.branchId, dup.productId]
  );
  // Keep the first row (highest quantity), delete the rest
  const keepId = rows[0].id;
  const deleteIds = rows.slice(1).map(r => r.id);
  if (deleteIds.length > 0) {
    await conn.query('DELETE FROM branch_inventory WHERE id IN (?)', [deleteIds]);
    console.log(`  Kept id=${keepId} for branch=${dup.branchId} product=${dup.productId}, deleted ids: ${deleteIds.join(',')}`);
  }
}

// Add unique constraint to prevent future duplicates
console.log('\nAdding unique constraint on (branchId, productId)...');
try {
  await conn.query('ALTER TABLE branch_inventory ADD UNIQUE KEY uq_branch_product (branchId, productId)');
  console.log('Unique constraint added successfully.');
} catch (e) {
  if (e.code === 'ER_DUP_KEYNAME') {
    console.log('Unique constraint already exists.');
  } else {
    console.error('Could not add unique constraint:', e.message);
  }
}

const [total] = await conn.query('SELECT COUNT(*) as cnt FROM branch_inventory');
console.log(`\nFinal row count: ${total[0].cnt}`);

await conn.end();
console.log('Done!');
