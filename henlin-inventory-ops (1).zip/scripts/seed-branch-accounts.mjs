/**
 * Seed branch accounts for all 13 Henlin branches.
 * Passwords are hashed with bcrypt (10 rounds).
 * Run: node scripts/seed-branch-accounts.mjs
 */
import { createHash } from "crypto";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

// Simple SHA-256 + salt hash (no bcrypt dependency needed in script)
// The server will use the same approach for verification
function hashPassword(password) {
  const salt = "henlin_salt_2024";
  return createHash("sha256").update(salt + password).digest("hex");
}

const branches = [
  { id: 1,  name: "Crossing Los Baños",        username: "crossing_losb",    password: "Henlin@CrossLB1" },
  { id: 2,  name: "Waltermart Silang",          username: "wm_silang",        password: "Henlin@WMSilang2" },
  { id: 3,  name: "Waltermart Tanauan",         username: "wm_tanauan",       password: "Henlin@WMTanauan3" },
  { id: 4,  name: "Waltermart Balayan",         username: "wm_balayan",       password: "Henlin@WMBalayan4" },
  { id: 5,  name: "Robinsons Tagaytay",         username: "rob_tagaytay",     password: "Henlin@RobTagaytay5" },
  { id: 6,  name: "Puregold GMA",               username: "pg_gma",           password: "Henlin@PGGMA6" },
  { id: 7,  name: "Vega Los Baños",             username: "vega_losb",        password: "Henlin@VegaLB7" },
  { id: 8,  name: "Robinsons Los Baños",        username: "rob_losb",         password: "Henlin@RobLB8" },
  { id: 9,  name: "South Supermarket Los Baños",username: "south_losb",       password: "Henlin@SouthLB9" },
  { id: 10, name: "Puregold San Pablo",         username: "pg_sanpablo",      password: "Henlin@PGSanPablo10" },
  { id: 11, name: "Ultimart San Pablo",         username: "ultimart_sanpablo",password: "Henlin@UltimartSP11" },
  { id: 12, name: "City Mall Tiaong",           username: "citymall_tiaong",  password: "Henlin@CityTiaong12" },
  { id: 13, name: "Puregold Tiaong",            username: "pg_tiaong",        password: "Henlin@PGTiaong13" },
];

const conn = await mysql.createConnection(process.env.DATABASE_URL);

console.log("Seeding branch accounts...");
for (const b of branches) {
  const hash = hashPassword(b.password);
  await conn.execute(
    `INSERT INTO branch_accounts (branchId, username, passwordHash, role, isActive)
     VALUES (?, ?, ?, 'branch_manager', 1)
     ON DUPLICATE KEY UPDATE username = VALUES(username), passwordHash = VALUES(passwordHash)`,
    [b.id, b.username, hash]
  );
  console.log(`  ✓ ${b.name} → ${b.username} / ${b.password}`);
}

await conn.end();
console.log("\nDone! All 13 branch accounts seeded.");
