import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, branchProcedure, router } from "./_core/trpc";
import {
  getBranches, getProducts, createProduct, updateProduct, deleteProduct,
  getInventoryByBranch, getAllBranchesSummary, stockIn, stockOut, adjustInventory, getInventoryLogs,
  createSale, getSales, getSalesSummary, getTopProducts,
  getStaffByBranch, createStaff, updateStaff, deleteStaff,
  getShiftsByBranch, createShift, closeShift, assignStaffToShift,
  getTimeRecords, clockIn, clockOut, startBreak, endBreak, getAttendanceReport,
  verifyBranchPassword, getAllBranchAccounts, updateBranchAccountPassword,
} from "./db";
import { BRANCH_COOKIE_NAME } from "@shared/const";
import Stripe from "stripe";
import { CURRENCY, FRANCHISE_PLANS } from "./stripeProducts";
import { SignJWT, jwtVerify } from "jose";

const BRANCH_JWT_SECRET = new TextEncoder().encode((process.env.JWT_SECRET ?? "henlin_branch_secret") + "_branch");

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Branch Auth ─────────────────────────────────────────────────
  branchAuth: router({
    login: publicProcedure
      .input(z.object({ username: z.string(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const account = await verifyBranchPassword(input.username, input.password);
        if (!account) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
        const token = await new SignJWT({
          branchId: account.branchId,
          username: account.username,
          role: account.role,
          accountId: account.id,
        })
          .setProtectedHeader({ alg: "HS256" })
          .setExpirationTime("12h")
          .sign(BRANCH_JWT_SECRET);
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(BRANCH_COOKIE_NAME, token, { ...cookieOptions, maxAge: 12 * 60 * 60 * 1000 });
        // Also return token in body so client can store in localStorage (proxy may strip Set-Cookie)
        return { success: true, token, branchId: account.branchId, username: account.username, role: account.role };
      }),
    me: publicProcedure.query(async ({ ctx }) => {
      // Read from X-Branch-Token header first (localStorage-based), then fall back to cookie
      const headerToken = ctx.req.headers["x-branch-token"] as string | undefined;
      const cookieToken = ctx.req.cookies?.[BRANCH_COOKIE_NAME];
      const token = headerToken || cookieToken;
      if (!token) return null;
      try {
        const { payload } = await jwtVerify(token, BRANCH_JWT_SECRET);
        return {
          branchId: payload.branchId as number,
          username: payload.username as string,
          role: payload.role as string,
          accountId: payload.accountId as number,
        };
      } catch {
        return null;
      }
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(BRANCH_COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),
    listAccounts: protectedProcedure.query(() => getAllBranchAccounts()),
    changePassword: protectedProcedure
      .input(z.object({ branchId: z.number(), newPassword: z.string().min(6) }))
      .mutation(async ({ input }) => {
        await updateBranchAccountPassword(input.branchId, input.newPassword);
        return { success: true };
      }),
  }),

  // ─── Branches ───────────────────────────────────────────────────
  branches: router({
    list: publicProcedure.query(() => getBranches()),
  }),

  // ─── Products ───────────────────────────────────────────────────
  products: router({
    list: publicProcedure.query(() => getProducts()),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        category: z.string().optional(),
        unit: z.string().optional(),
        price: z.number().optional(),
        reorderLevel: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await createProduct(input);
        return { id };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        category: z.string().optional(),
        unit: z.string().optional(),
        price: z.number().optional(),
        reorderLevel: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await updateProduct(input.id, input);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteProduct(input.id);
        return { success: true };
      }),
    massUpload: protectedProcedure
      .input(z.array(z.object({
        name: z.string().min(1),
        category: z.string().optional(),
        unit: z.string().optional(),
        price: z.number().optional(),
      })))
      .mutation(async ({ input }) => {
        let created = 0;
        for (const item of input) {
          await createProduct(item);
          created++;
        }
        return { created };
      }),
  }),

  // ─── Inventory ──────────────────────────────────────────────────
  inventory: router({
    getByBranch: publicProcedure
      .input(z.object({ branchId: z.number() }))
      .query(({ input }) => getInventoryByBranch(input.branchId)),
    allBranchesSummary: publicProcedure.query(() => getAllBranchesSummary()),
    stockIn: branchProcedure
      .input(z.object({
        branchId: z.number(),
        productId: z.number(),
        quantity: z.number().positive(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const actor = ctx.user?.name ?? (ctx.branchSession as any)?.username ?? undefined;
        await stockIn(input.branchId, input.productId, input.quantity, input.reason, actor);
        return { success: true };
      }),
    stockOut: branchProcedure
      .input(z.object({
        branchId: z.number(),
        productId: z.number(),
        quantity: z.number().positive(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const actor = ctx.user?.name ?? (ctx.branchSession as any)?.username ?? undefined;
        await stockOut(input.branchId, input.productId, input.quantity, input.reason, actor);
        return { success: true };
      }),
    adjust: branchProcedure
      .input(z.object({
        branchId: z.number(),
        productId: z.number(),
        quantity: z.number().positive(),
        adjustmentReason: z.enum(["damaged", "expired", "transferred", "correction"]),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const actor = ctx.user?.name ?? (ctx.branchSession as any)?.username ?? undefined;
        await adjustInventory(input.branchId, input.productId, input.quantity, input.adjustmentReason, input.reason, actor);
        return { success: true };
      }),
    getLogs: publicProcedure
      .input(z.object({ branchId: z.number(), productId: z.number().optional() }))
      .query(({ input }) => getInventoryLogs(input.branchId, input.productId)),
  }),

  // ─── Sales ──────────────────────────────────────────────────────
  sales: router({
    create: branchProcedure
      .input(z.object({
        branchId: z.number(),
        cashierName: z.string().optional(),
        paymentType: z.enum(["cash", "GCash", "card"]),
        stripePaymentIntentId: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          productName: z.string(),
          quantity: z.number().positive(),
          unitPrice: z.number().min(0),
          subtotal: z.number().min(0),
        })),
      }))
      .mutation(async ({ input }) => {
        const result = await createSale(input);
        return result;
      }),
    list: publicProcedure
      .input(z.object({
        branchId: z.number().nullable().optional(),
        startTs: z.number().optional(),
        endTs: z.number().optional(),
        limit: z.number().optional(),
      }))
      .query(({ input }) => getSales(input)),
    summary: publicProcedure
      .input(z.object({
        branchId: z.number().nullable().optional(),
        startTs: z.number(),
        endTs: z.number(),
      }))
      .query(({ input }) => getSalesSummary(input)),
    topProducts: publicProcedure
      .input(z.object({
        branchId: z.number().nullable().optional(),
        startTs: z.number(),
        endTs: z.number(),
      }))
      .query(({ input }) => getTopProducts(input)),
  }),

  // ─── Staff ──────────────────────────────────────────────────────
  staff: router({
    listByBranch: publicProcedure
      .input(z.object({ branchId: z.number() }))
      .query(({ input }) => getStaffByBranch(input.branchId)),
    create: branchProcedure
      .input(z.object({ branchId: z.number(), name: z.string().min(1), position: z.string().optional() }))
      .mutation(async ({ input }) => {
        const id = await createStaff(input);
        return { id };
      }),
    update: branchProcedure
      .input(z.object({ id: z.number(), name: z.string().optional(), position: z.string().optional() }))
      .mutation(async ({ input }) => {
        await updateStaff(input.id, input);
        return { success: true };
      }),
    delete: branchProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteStaff(input.id);
        return { success: true };
      }),
  }),

  // ─── Shifts ─────────────────────────────────────────────────────
  shifts: router({
    listByBranch: publicProcedure
      .input(z.object({ branchId: z.number(), date: z.string() }))
      .query(({ input }) => getShiftsByBranch(input.branchId, input.date)),
    create: branchProcedure
      .input(z.object({
        branchId: z.number(),
        name: z.string().min(1),
        startTime: z.string(),
        endTime: z.string(),
        date: z.string(),
      }))
      .mutation(async ({ input }) => {
        const id = await createShift(input);
        return { id };
      }),
    close: branchProcedure
      .input(z.object({ shiftId: z.number() }))
      .mutation(async ({ input }) => {
        await closeShift(input.shiftId);
        return { success: true };
      }),
    assignStaff: branchProcedure
      .input(z.object({ shiftId: z.number(), staffId: z.number(), branchId: z.number() }))
      .mutation(async ({ input }) => {
        await assignStaffToShift(input.shiftId, input.staffId, input.branchId);
        return { success: true };
      }),
  }),

  // ─── Time Records ───────────────────────────────────────────────
  timeRecords: router({
    list: publicProcedure
      .input(z.object({ branchId: z.number(), date: z.string() }))
      .query(({ input }) => getTimeRecords(input.branchId, input.date)),
    clockIn: branchProcedure
      .input(z.object({ staffId: z.number(), branchId: z.number(), date: z.string() }))
      .mutation(async ({ input }) => {
        const id = await clockIn(input.staffId, input.branchId, input.date);
        return { id };
      }),
    clockOut: branchProcedure
      .input(z.object({ timeRecordId: z.number() }))
      .mutation(async ({ input }) => {
        await clockOut(input.timeRecordId);
        return { success: true };
      }),
    breakStart: branchProcedure
      .input(z.object({ timeRecordId: z.number() }))
      .mutation(async ({ input }) => {
        await startBreak(input.timeRecordId);
        return { success: true };
      }),
    breakEnd: branchProcedure
      .input(z.object({ timeRecordId: z.number() }))
      .mutation(async ({ input }) => {
        await endBreak(input.timeRecordId);
        return { success: true };
      }),
  }),

  // ─── Reports ────────────────────────────────────────────────────
  reports: router({
    salesReport: publicProcedure
      .input(z.object({
        branchId: z.number().nullable().optional(),
        startTs: z.number(),
        endTs: z.number(),
      }))
      .query(async ({ input }) => {
        const [summary, transactions, topProducts] = await Promise.all([
          getSalesSummary(input),
          getSales({ ...input, limit: 500 }),
          getTopProducts(input),
        ]);
        return { summary, transactions, topProducts };
      }),
    inventoryReport: publicProcedure
      .input(z.object({ branchId: z.number() }))
      .query(async ({ input }) => {
        const inventory = await getInventoryByBranch(input.branchId);
        const lowStockItems = inventory.filter(
          (i) => parseFloat(i.quantity as string) <= parseFloat(i.reorderLevel as string)
        );
        return { inventory, lowStockItems };
      }),
    attendanceReport: publicProcedure
      .input(z.object({
        branchId: z.number().nullable().optional(),
        startDate: z.string(),
        endDate: z.string(),
      }))
      .query(({ input }) => getAttendanceReport(input)),
  }),

  // ─── Stripe Payments ─────────────────────────────────────────────
  stripe: router({
    /**
     * Create a PaymentIntent for a POS card transaction.
     * Called when the cashier selects "card" payment and confirms the sale.
     * Returns the clientSecret so the frontend can confirm with Stripe.js.
     */
    createPaymentIntent: branchProcedure
      .input(z.object({
        amount: z.number().min(1), // amount in PHP (not centavos)
        saleRef: z.string().optional(), // internal reference
        branchName: z.string().optional(),
        cashierName: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const stripeKey = process.env.STRIPE_SECRET_KEY;
        if (!stripeKey) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Stripe not configured" });
        const stripe = new Stripe(stripeKey, { apiVersion: "2026-04-22.dahlia" });
        // Stripe PHP uses centavos (smallest unit)
        const amountInCentavos = Math.round(input.amount * 100);
        const paymentIntent = await stripe.paymentIntents.create({
          amount: amountInCentavos,
          currency: CURRENCY,
          description: `Henlin POS Sale — ${input.branchName ?? "Branch"} — ${input.cashierName ?? "Cashier"}`,
          metadata: {
            sale_ref: input.saleRef ?? "",
            branch_name: input.branchName ?? "",
            cashier_name: input.cashierName ?? "",
            branch_id: String(ctx.branchSession?.branchId ?? ctx.user?.id ?? ""),
          },
        });
        return { clientSecret: paymentIntent.client_secret, paymentIntentId: paymentIntent.id };
      }),

    /**
     * Create a Stripe Checkout Session for franchise subscription billing.
     * Opens a hosted Stripe checkout page for the selected plan.
     */
    createSubscriptionCheckout: protectedProcedure
      .input(z.object({
        planId: z.enum(["basic", "pro", "enterprise"]),
        interval: z.enum(["monthly", "annual"]),
        origin: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const stripeKey = process.env.STRIPE_SECRET_KEY;
        if (!stripeKey) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Stripe not configured" });
        const stripe = new Stripe(stripeKey, { apiVersion: "2026-04-22.dahlia" });
        const plan = FRANCHISE_PLANS.find(p => p.id === input.planId);
        if (!plan) throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid plan" });
        const amount = input.interval === "monthly" ? plan.monthlyAmount : plan.annualAmount;
        const intervalLabel = input.interval === "monthly" ? "month" : "year";
        const session = await stripe.checkout.sessions.create({
          mode: "subscription",
          payment_method_types: ["card"],
          allow_promotion_codes: true,
          customer_email: ctx.user?.email ?? undefined,
          line_items: [{
            price_data: {
              currency: CURRENCY,
              unit_amount: amount,
              recurring: { interval: intervalLabel as "month" | "year" },
              product_data: {
                name: `Henlin ${plan.name}`,
                description: plan.description,
              },
            },
            quantity: 1,
          }],
          client_reference_id: String(ctx.user?.id ?? ""),
          metadata: {
            user_id: String(ctx.user?.id ?? ""),
            customer_email: ctx.user?.email ?? "",
            customer_name: ctx.user?.name ?? "",
            plan_id: input.planId,
            interval: input.interval,
          },
          success_url: `${input.origin}/billing?success=1`,
          cancel_url: `${input.origin}/billing?cancelled=1`,
        });
        return { url: session.url };
      }),

    /**
     * Get available franchise subscription plans.
     */
    getPlans: publicProcedure.query(() => FRANCHISE_PLANS),
  }),
});
export type AppRouter = typeof appRouter;
