import { eq, and, gte, lte, desc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users, branches, products, branchInventory, inventoryLogs,
  sales, saleItems, staff, shifts, shiftStaff, timeRecords, branchAccounts,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = typeof textFields[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Branches ─────────────────────────────────────────────────────
export async function getBranches() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(branches).orderBy(branches.id);
}

// ─── Products ─────────────────────────────────────────────────────
export async function getProducts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).where(eq(products.isActive, true)).orderBy(products.name);
}

export async function createProduct(data: { name: string; category?: string; unit?: string; price?: number; reorderLevel?: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(products).values({
    name: data.name,
    category: data.category ?? null,
    unit: data.unit ?? "pcs",
    price: data.price ? String(data.price) : null,
  });
  return result[0].insertId;
}

export async function updateProduct(id: number, data: { name?: string; category?: string; unit?: string; price?: number; reorderLevel?: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(products).set({
    name: data.name,
    category: data.category ?? null,
    unit: data.unit ?? "pcs",
    price: data.price !== undefined ? String(data.price) : undefined,
  }).where(eq(products.id, id));
  // Update reorder level in all branch inventories if provided
  if (data.reorderLevel !== undefined) {
    await db.update(branchInventory)
      .set({ reorderLevel: String(data.reorderLevel) })
      .where(eq(branchInventory.productId, id));
  }
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(products).set({ isActive: false }).where(eq(products.id, id));
}

// ─── Inventory ────────────────────────────────────────────────────
export async function getInventoryByBranch(branchId: number) {
  const db = await getDb();
  if (!db) return [];
  // Use LEFT JOIN from products → branchInventory so ALL active products
  // always appear even if no inventory row exists yet (shows 0 stock).
  const rows = await db
    .select({
      id: sql<number>`COALESCE(${branchInventory.id}, 0)`,
      branchId: sql<number>`COALESCE(${branchInventory.branchId}, ${branchId})`,
      productId: products.id,
      quantity: sql<string>`COALESCE(${branchInventory.quantity}, '0')`,
      reorderLevel: sql<string>`COALESCE(${branchInventory.reorderLevel}, '10')`,
      productName: products.name,
      category: products.category,
      unit: products.unit,
      price: products.price,
    })
    .from(products)
    .leftJoin(
      branchInventory,
      and(eq(branchInventory.productId, products.id), eq(branchInventory.branchId, branchId))
    )
    .where(eq(products.isActive, true))
    .orderBy(products.category, products.name);
  return rows;
}

export async function getAllBranchesSummary() {
  const db = await getDb();
  if (!db) return [];
  const result = await db
    .select({
      branchId: branchInventory.branchId,
      totalProducts: sql<number>`COUNT(DISTINCT ${branchInventory.productId})`,
      lowStockCount: sql<number>`SUM(CASE WHEN ${branchInventory.quantity} <= ${branchInventory.reorderLevel} THEN 1 ELSE 0 END)`,
    })
    .from(branchInventory)
    .innerJoin(products, eq(branchInventory.productId, products.id))
    .where(eq(products.isActive, true))
    .groupBy(branchInventory.branchId);
  return result;
}

export async function stockIn(branchId: number, productId: number, quantity: number, reason?: string, performedByName?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Upsert inventory
  await db.insert(branchInventory).values({
    branchId, productId, quantity: String(quantity), reorderLevel: "10",
  }).onDuplicateKeyUpdate({
    set: { quantity: sql`${branchInventory.quantity} + ${quantity}` },
  });
  // Log
  await db.insert(inventoryLogs).values({
    branchId, productId, type: "stock_in", quantity: String(quantity),
    reason: reason ?? null, performedByName: performedByName ?? null,
    timestamp: Date.now(),
  });
}

export async function stockOut(branchId: number, productId: number, quantity: number, reason?: string, performedByName?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(branchInventory)
    .set({ quantity: sql`GREATEST(0, ${branchInventory.quantity} - ${quantity})` })
    .where(and(eq(branchInventory.branchId, branchId), eq(branchInventory.productId, productId)));
  await db.insert(inventoryLogs).values({
    branchId, productId, type: "stock_out", quantity: String(quantity),
    reason: reason ?? null, performedByName: performedByName ?? null,
    timestamp: Date.now(),
  });
}

export async function adjustInventory(
  branchId: number, productId: number, quantity: number,
  adjustmentReason: "damaged" | "expired" | "transferred" | "correction",
  reason?: string, performedByName?: string
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(branchInventory)
    .set({ quantity: sql`GREATEST(0, ${branchInventory.quantity} - ${quantity})` })
    .where(and(eq(branchInventory.branchId, branchId), eq(branchInventory.productId, productId)));
  await db.insert(inventoryLogs).values({
    branchId, productId, type: "adjustment", quantity: String(quantity),
    adjustmentReason, reason: reason ?? null, performedByName: performedByName ?? null,
    timestamp: Date.now(),
  });
}

export async function getInventoryLogs(branchId: number, productId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(inventoryLogs.branchId, branchId)];
  if (productId) conditions.push(eq(inventoryLogs.productId, productId));
  return db.select().from(inventoryLogs).where(and(...conditions)).orderBy(desc(inventoryLogs.timestamp)).limit(100);
}

// ─── Sales ────────────────────────────────────────────────────────
export async function createSale(data: {
  branchId: number;
  cashierName?: string;
  paymentType: "cash" | "GCash" | "card";
  stripePaymentIntentId?: string;
  items: Array<{ productId: number; productName: string; quantity: number; unitPrice: number; subtotal: number }>;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const totalAmount = data.items.reduce((sum, i) => sum + i.subtotal, 0);
  const now = Date.now();
  const result = await db.insert(sales).values({
    branchId: data.branchId,
    cashierName: data.cashierName ?? null,
    paymentType: data.paymentType,
    stripePaymentIntentId: data.stripePaymentIntentId ?? null,
    totalAmount: String(totalAmount),
    timestamp: now,
  });
  const saleId = result[0].insertId;
  // Insert items
  await db.insert(saleItems).values(
    data.items.map((i) => ({
      saleId,
      productId: i.productId,
      productName: i.productName,
      quantity: String(i.quantity),
      unitPrice: String(i.unitPrice),
      subtotal: String(i.subtotal),
    }))
  );
  // Deduct inventory
  for (const item of data.items) {
    await db.update(branchInventory)
      .set({ quantity: sql`GREATEST(0, ${branchInventory.quantity} - ${item.quantity})` })
      .where(and(eq(branchInventory.branchId, data.branchId), eq(branchInventory.productId, item.productId)));
    await db.insert(inventoryLogs).values({
      branchId: data.branchId,
      productId: item.productId,
      type: "sale",
      quantity: String(item.quantity),
      performedByName: data.cashierName ?? null,
      timestamp: now,
    });
  }
  return { saleId, totalAmount };
}

export async function getSales(params: { branchId?: number | null; startTs?: number; endTs?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (params.branchId) conditions.push(eq(sales.branchId, params.branchId));
  if (params.startTs) conditions.push(gte(sales.timestamp, params.startTs));
  if (params.endTs) conditions.push(lte(sales.timestamp, params.endTs));
  const result = await db
    .select({
      id: sales.id,
      branchId: sales.branchId,
      branchName: branches.name,
      cashierName: sales.cashierName,
      paymentType: sales.paymentType,
      totalAmount: sales.totalAmount,
      status: sales.status,
      timestamp: sales.timestamp,
    })
    .from(sales)
    .leftJoin(branches, eq(sales.branchId, branches.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(sales.timestamp))
    .limit(params.limit ?? 100);
  return result;
}

export async function getSalesSummary(params: { branchId?: number | null; startTs: number; endTs: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [
    gte(sales.timestamp, params.startTs),
    lte(sales.timestamp, params.endTs),
    eq(sales.status, "completed"),
  ];
  if (params.branchId) conditions.push(eq(sales.branchId, params.branchId));
  return db
    .select({
      branchId: sales.branchId,
      branchName: branches.name,
      totalSales: sql<number>`SUM(${sales.totalAmount})`,
      transactionCount: sql<number>`COUNT(*)`,
      cashSales: sql<number>`SUM(CASE WHEN ${sales.paymentType} = 'cash' THEN ${sales.totalAmount} ELSE 0 END)`,
      gcashSales: sql<number>`SUM(CASE WHEN ${sales.paymentType} = 'GCash' THEN ${sales.totalAmount} ELSE 0 END)`,
      cardSales: sql<number>`SUM(CASE WHEN ${sales.paymentType} = 'card' THEN ${sales.totalAmount} ELSE 0 END)`,
    })
    .from(sales)
    .leftJoin(branches, eq(sales.branchId, branches.id))
    .where(and(...conditions))
    .groupBy(sales.branchId, branches.name);
}

export async function getTopProducts(params: { branchId?: number | null; startTs: number; endTs: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [
    gte(sales.timestamp, params.startTs),
    lte(sales.timestamp, params.endTs),
    eq(sales.status, "completed"),
  ];
  if (params.branchId) conditions.push(eq(sales.branchId, params.branchId));
  return db
    .select({
      productId: saleItems.productId,
      productName: saleItems.productName,
      totalQty: sql<number>`SUM(${saleItems.quantity})`,
      totalRevenue: sql<number>`SUM(${saleItems.subtotal})`,
    })
    .from(saleItems)
    .innerJoin(sales, eq(saleItems.saleId, sales.id))
    .where(and(...conditions))
    .groupBy(saleItems.productId, saleItems.productName)
    .orderBy(desc(sql`SUM(${saleItems.subtotal})`))
    .limit(10);
}

// ─── Staff ────────────────────────────────────────────────────────
export async function getStaffByBranch(branchId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(staff).where(and(eq(staff.branchId, branchId), eq(staff.isActive, true))).orderBy(staff.name);
}

export async function createStaff(data: { branchId: number; name: string; position?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(staff).values({
    branchId: data.branchId,
    name: data.name,
    position: data.position ?? null,
  });
  return result[0].insertId;
}

export async function updateStaff(id: number, data: { name?: string; position?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(staff).set({ name: data.name, position: data.position ?? null }).where(eq(staff.id, id));
}

export async function deleteStaff(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(staff).set({ isActive: false }).where(eq(staff.id, id));
}

// ─── Shifts ───────────────────────────────────────────────────────
export async function getShiftsByBranch(branchId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  const shiftRows = await db.select().from(shifts).where(and(eq(shifts.branchId, branchId), eq(shifts.date, date))).orderBy(shifts.startTime);
  if (shiftRows.length === 0) return [];
  const shiftIds = shiftRows.map((s) => s.id);
  // Fetch staff assigned to these shifts
  const assignedRows = await db
    .select({ shiftId: shiftStaff.shiftId, staffId: shiftStaff.staffId, staffName: staff.name })
    .from(shiftStaff)
    .innerJoin(staff, eq(shiftStaff.staffId, staff.id))
    .where(inArray(shiftStaff.shiftId, shiftIds));
  return shiftRows.map((s) => ({
    ...s,
    staffAssigned: assignedRows.filter((a) => a.shiftId === s.id),
  }));
}

export async function createShift(data: { branchId: number; name: string; startTime: string; endTime: string; date: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const result = await db.insert(shifts).values({
    branchId: data.branchId,
    name: data.name,
    startTime: data.startTime,
    endTime: data.endTime,
    date: data.date,
    openedAt: Date.now(),
  });
  return result[0].insertId;
}

export async function closeShift(shiftId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(shifts).set({ status: "closed", closedAt: Date.now() }).where(eq(shifts.id, shiftId));
}

export async function assignStaffToShift(shiftId: number, staffId: number, branchId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(shiftStaff).values({ shiftId, staffId, branchId });
}

// ─── Time Records ─────────────────────────────────────────────────
export async function getTimeRecords(branchId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: timeRecords.id,
      staffId: timeRecords.staffId,
      staffName: staff.name,
      position: staff.position,
      branchId: timeRecords.branchId,
      date: timeRecords.date,
      clockIn: timeRecords.clockIn,
      clockOut: timeRecords.clockOut,
      breakStart: timeRecords.breakStart,
      breakEnd: timeRecords.breakEnd,
      hoursRendered: timeRecords.hoursRendered,
    })
    .from(timeRecords)
    .innerJoin(staff, eq(timeRecords.staffId, staff.id))
    .where(and(eq(timeRecords.branchId, branchId), eq(timeRecords.date, date)))
    .orderBy(staff.name);
}

export async function clockIn(staffId: number, branchId: number, date: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Check if already clocked in today
  const existing = await db.select().from(timeRecords)
    .where(and(eq(timeRecords.staffId, staffId), eq(timeRecords.branchId, branchId), eq(timeRecords.date, date)))
    .limit(1);
  if (existing.length > 0 && existing[0].clockIn) throw new Error("Staff already clocked in today");
  if (existing.length > 0) {
    await db.update(timeRecords).set({ clockIn: Date.now() }).where(eq(timeRecords.id, existing[0].id));
    return existing[0].id;
  }
  const result = await db.insert(timeRecords).values({
    staffId, branchId, date, clockIn: Date.now(),
  });
  return result[0].insertId;
}

export async function clockOut(timeRecordId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const records = await db.select().from(timeRecords).where(eq(timeRecords.id, timeRecordId)).limit(1);
  if (!records.length || !records[0].clockIn) throw new Error("No clock-in found");
  const record = records[0];
  const clockOutTime = Date.now();
  // Calculate hours (subtract break time if applicable)
  let breakMs = 0;
  if (record.breakStart && record.breakEnd) {
    breakMs = record.breakEnd - record.breakStart;
  }
  const totalMs = clockOutTime - record.clockIn! - breakMs;
  const hours = Math.max(0, totalMs / 3600000);
  await db.update(timeRecords).set({
    clockOut: clockOutTime,
    hoursRendered: String(hours.toFixed(2)),
  }).where(eq(timeRecords.id, timeRecordId));
}

export async function startBreak(timeRecordId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(timeRecords).set({ breakStart: Date.now() }).where(eq(timeRecords.id, timeRecordId));
}

export async function endBreak(timeRecordId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(timeRecords).set({ breakEnd: Date.now() }).where(eq(timeRecords.id, timeRecordId));
}

export async function getAttendanceReport(params: { branchId?: number | null; startDate: string; endDate: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [
    sql`${timeRecords.date} >= ${params.startDate}`,
    sql`${timeRecords.date} <= ${params.endDate}`,
  ];
  if (params.branchId) conditions.push(eq(timeRecords.branchId, params.branchId));
  return db
    .select({
      id: timeRecords.id,
      staffId: timeRecords.staffId,
      staffName: staff.name,
      branchId: timeRecords.branchId,
      branchName: branches.name,
      date: timeRecords.date,
      clockIn: timeRecords.clockIn,
      clockOut: timeRecords.clockOut,
      hoursRendered: timeRecords.hoursRendered,
    })
    .from(timeRecords)
    .innerJoin(staff, eq(timeRecords.staffId, staff.id))
    .innerJoin(branches, eq(timeRecords.branchId, branches.id))
    .where(and(...conditions))
    .orderBy(timeRecords.date, staff.name);
}

// ─── Branch Accounts ─────────────────────────────────────────────
import { createHash } from "crypto";

function hashBranchPassword(password: string): string {
  const salt = "henlin_salt_2024";
  return createHash("sha256").update(salt + password).digest("hex");
}

export async function getBranchAccountByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select({
      id: branchAccounts.id,
      branchId: branchAccounts.branchId,
      username: branchAccounts.username,
      passwordHash: branchAccounts.passwordHash,
      role: branchAccounts.role,
      isActive: branchAccounts.isActive,
    })
    .from(branchAccounts)
    .where(eq(branchAccounts.username, username))
    .limit(1);
  return rows[0] ?? undefined;
}

export async function verifyBranchPassword(username: string, password: string) {
  const account = await getBranchAccountByUsername(username);
  if (!account || !account.isActive) return null;
  const hash = hashBranchPassword(password);
  if (hash !== account.passwordHash) return null;
  // Update lastLogin
  const db = await getDb();
  if (db) {
    await db.update(branchAccounts)
      .set({ lastLogin: Date.now() })
      .where(eq(branchAccounts.id, account.id));
  }
  return account;
}

export async function getAllBranchAccounts() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: branchAccounts.id,
      branchId: branchAccounts.branchId,
      username: branchAccounts.username,
      role: branchAccounts.role,
      isActive: branchAccounts.isActive,
      lastLogin: branchAccounts.lastLogin,
      branchName: branches.name,
    })
    .from(branchAccounts)
    .innerJoin(branches, eq(branchAccounts.branchId, branches.id))
    .orderBy(branchAccounts.branchId);
}

export async function updateBranchAccountPassword(branchId: number, newPassword: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const hash = hashBranchPassword(newPassword);
  await db.update(branchAccounts)
    .set({ passwordHash: hash })
    .where(eq(branchAccounts.branchId, branchId));
}
