import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin') {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

/**
 * Branch-scoped procedure: requires a valid branch session cookie.
 * Automatically enforces that the branchId in the input matches the logged-in branch.
 * Super admins (Manus OAuth) bypass branch restriction.
 */
export const branchProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    // Super admin (Manus OAuth) always passes
    if (ctx.user && ctx.user.role === 'admin') {
      return next({ ctx });
    }
    // Branch account must have a valid session
    if (!ctx.branchSession) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Branch session required" });
    }
    return next({
      ctx: {
        ...ctx,
        branchSession: ctx.branchSession,
      },
    });
  }),
);
