import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { jwtVerify } from "jose";
import { BRANCH_COOKIE_NAME } from "../../shared/const";

export interface BranchSessionPayload {
  branchId: number;
  username: string;
  role: string;
  accountId: number;
}

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  branchSession: BranchSessionPayload | null;
};

const BRANCH_JWT_SECRET = new TextEncoder().encode(
  (process.env.JWT_SECRET ?? "henlin_branch_secret") + "_branch"
);

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let branchSession: BranchSessionPayload | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch {
    user = null;
  }

  try {
    // Read from X-Branch-Token header first (used by branch portal via localStorage),
    // then fall back to cookie (legacy / same-origin)
    const headerToken = opts.req.headers["x-branch-token"] as string | undefined;
    const cookieToken = opts.req.cookies?.[BRANCH_COOKIE_NAME];
    const token = headerToken || cookieToken;
    if (token) {
      const { payload } = await jwtVerify(token, BRANCH_JWT_SECRET);
      branchSession = {
        branchId: payload.branchId as number,
        username: payload.username as string,
        role: payload.role as string,
        accountId: payload.accountId as number,
      };
    }
  } catch {
    branchSession = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
    branchSession,
  };
}
