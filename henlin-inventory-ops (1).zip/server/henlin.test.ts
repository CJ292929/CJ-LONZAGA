import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME, BRANCH_COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: { name: string; options: Record<string, unknown> }[] } {
  const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@henlin.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  const ctx: TrpcContext = {
    user,
    branchSession: null,
    req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
      cookie: () => {},
    } as unknown as TrpcContext["res"],
  };
  return { ctx, clearedCookies };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    branchSession: null,
    req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
    res: { clearCookie: () => {}, cookie: () => {} } as unknown as TrpcContext["res"],
  };
}

// ─── Auth Tests ────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1 });
  });

  it("returns null user when not authenticated", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user).toBeNull();
  });
});

// ─── Branch Auth Tests ─────────────────────────────────────────────
describe("branchAuth.me", () => {
  it("returns null when no branch cookie is present", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.branchAuth.me();
    expect(result).toBeNull();
  });

  it("returns null when branch cookie is invalid", async () => {
    const ctx: TrpcContext = {
      user: null,
      branchSession: null,
      req: { protocol: "https", headers: {}, cookies: { [BRANCH_COOKIE_NAME]: "invalid.token.here" } } as TrpcContext["req"],
      res: { clearCookie: () => {}, cookie: () => {} } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.branchAuth.me();
    expect(result).toBeNull();
  });
});

describe("branchAuth.logout", () => {
  it("clears the branch cookie and reports success", async () => {
    const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
    const ctx: TrpcContext = {
      user: null,
      branchSession: null,
      req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
      res: {
        clearCookie: (name: string, options: Record<string, unknown>) => clearedCookies.push({ name, options }),
        cookie: () => {},
      } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.branchAuth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(BRANCH_COOKIE_NAME);
  });
});

describe("branchAuth.login", () => {
  it("throws UNAUTHORIZED for invalid credentials", async () => {
    const ctx: TrpcContext = {
      user: null,
      branchSession: null,
      req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
      res: { clearCookie: () => {}, cookie: () => {} } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.branchAuth.login({ username: "nonexistent_branch", password: "wrongpassword" })
    ).rejects.toThrow("Invalid username or password");
  });

  it("returns token in response body on successful login (DB-dependent)", async () => {
    // This test only runs if DB is available and the seed account exists
    const ctx: TrpcContext = {
      user: null,
      branchSession: null,
      req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
      res: { clearCookie: () => {}, cookie: () => {} } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    try {
      const result = await caller.branchAuth.login({ username: "crossing_losb", password: "Henlin@CrossLB1" });
      expect(result.success).toBe(true);
      expect(typeof result.token).toBe("string");
      expect(result.token.length).toBeGreaterThan(10);
      expect(result.branchId).toBe(1);
    } catch (e: any) {
      // DB not available in test env — acceptable
      expect(e.message).not.toContain("token");
    }
  });
});

// ─── Branches Tests ────────────────────────────────────────────────
describe("branches.list", () => {
  it("returns an array (may be empty in test env without DB)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    try {
      const branches = await caller.branches.list();
      expect(Array.isArray(branches)).toBe(true);
    } catch (e) {
      expect(e).toBeDefined();
    }
  });
});

// ─── Products Tests ────────────────────────────────────────────────
describe("products.list", () => {
  it("returns an array", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    try {
      const products = await caller.products.list();
      expect(Array.isArray(products)).toBe(true);
    } catch (e) {
      expect(e).toBeDefined();
    }
  });
});

// ─── Router Structure Tests ────────────────────────────────────────
describe("router structure", () => {
  it("branchAuth.listAccounts requires admin auth", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.branchAuth.listAccounts()).rejects.toThrow();
  });

  it("branchAuth.changePassword requires admin auth", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.branchAuth.changePassword({ branchId: 1, newPassword: "newpass123" })
    ).rejects.toThrow();
  });

  it("has all required routers including branchAuth", () => {
    const caller = appRouter.createCaller(createPublicContext());
    expect(typeof caller.branches.list).toBe("function");
    expect(typeof caller.products.list).toBe("function");
    expect(typeof caller.inventory.getByBranch).toBe("function");
    expect(typeof caller.sales.list).toBe("function");
    expect(typeof caller.staff.listByBranch).toBe("function");
    expect(typeof caller.shifts.listByBranch).toBe("function");
    expect(typeof caller.timeRecords.list).toBe("function");
    expect(typeof caller.reports.salesReport).toBe("function");
    expect(typeof caller.reports.inventoryReport).toBe("function");
    expect(typeof caller.reports.attendanceReport).toBe("function");
    expect(typeof caller.branchAuth.login).toBe("function");
    expect(typeof caller.branchAuth.me).toBe("function");
    expect(typeof caller.branchAuth.logout).toBe("function");
  });

  it("protected procedures require authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.inventory.stockIn({ branchId: 1, productId: 1, quantity: 10 })
    ).rejects.toThrow();
  });

  it("authenticated user can call protected procedures (DB may not be available)", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.staff.create({ branchId: 1, name: "Test Staff", position: "Cashier" });
    } catch (e: any) {
      expect(e.message).not.toContain("UNAUTHORIZED");
    }
  });
});

// ─── Input Validation Tests ────────────────────────────────────────
describe("input validation", () => {
  it("rejects invalid payment type in sales.create", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.sales.create({
        branchId: 1,
        paymentType: "bitcoin" as any,
        items: [{ productId: 1, productName: "Test", quantity: 1, unitPrice: 10, subtotal: 10 }],
      })
    ).rejects.toThrow();
  });

  it("rejects invalid adjustment reason", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.inventory.adjust({
        branchId: 1,
        productId: 1,
        quantity: 5,
        adjustmentReason: "stolen" as any,
      })
    ).rejects.toThrow();
  });

  it("accepts valid payment types", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    for (const type of ["cash", "GCash", "card"] as const) {
      try {
        await caller.sales.create({
          branchId: 1,
          paymentType: type,
          items: [{ productId: 1, productName: "Test", quantity: 1, unitPrice: 10, subtotal: 10 }],
        });
      } catch (e: any) {
        expect(e.message).not.toContain("invalid_enum_value");
      }
    }
  });

  it("accepts valid adjustment reasons", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    for (const reason of ["damaged", "expired", "transferred", "correction"] as const) {
      try {
        await caller.inventory.adjust({ branchId: 1, productId: 1, quantity: 1, adjustmentReason: reason });
      } catch (e: any) {
        expect(e.message).not.toContain("invalid_enum_value");
      }
    }
  });
});

// ─── Branch Session Procedure Access Tests ────────────────────────
describe("branchProcedure access", () => {
  function createBranchSessionContext(branchId: number): TrpcContext {
    return {
      user: null,
      branchSession: { branchId, username: "wm_silang", role: "branch_manager", accountId: 2 },
      req: { protocol: "https", headers: {}, cookies: {} } as TrpcContext["req"],
      res: { clearCookie: () => {}, cookie: () => {} } as unknown as TrpcContext["res"],
    };
  }

  it("branch session can call sales.create (branchProcedure)", async () => {
    const ctx = createBranchSessionContext(2);
    const caller = appRouter.createCaller(ctx);
    // Should pass auth check (may fail at DB level — that's OK)
    try {
      await caller.sales.create({
        branchId: 2,
        paymentType: "cash",
        items: [{ productId: 1, productName: "Test", quantity: 1, unitPrice: 65, subtotal: 65 }],
      });
    } catch (e: any) {
      // Must NOT throw UNAUTHORIZED — only DB errors are acceptable
      expect(e.message).not.toContain("UNAUTHORIZED");
      expect(e.message).not.toContain("Branch session required");
    }
  });

  it("branch session can call inventory.stockIn (branchProcedure)", async () => {
    const ctx = createBranchSessionContext(2);
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.inventory.stockIn({ branchId: 2, productId: 1, quantity: 10 });
    } catch (e: any) {
      expect(e.message).not.toContain("UNAUTHORIZED");
      expect(e.message).not.toContain("Branch session required");
    }
  });

  it("unauthenticated user cannot call sales.create (branchProcedure)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.sales.create({
        branchId: 1,
        paymentType: "cash",
        items: [{ productId: 1, productName: "Test", quantity: 1, unitPrice: 65, subtotal: 65 }],
      })
    ).rejects.toThrow();
  });

  it("admin user can call branchProcedure endpoints", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.inventory.stockIn({ branchId: 1, productId: 1, quantity: 5 });
    } catch (e: any) {
      // Must NOT throw UNAUTHORIZED — only DB errors are acceptable
      expect(e.message).not.toContain("UNAUTHORIZED");
      expect(e.message).not.toContain("Branch session required");
    }
  });
});
