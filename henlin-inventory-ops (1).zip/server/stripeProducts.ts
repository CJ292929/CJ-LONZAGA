/**
 * Henlin Franchise — Stripe Products & Prices
 *
 * Two use-cases:
 *  1. POS card payments  — one-time PaymentIntent per sale transaction
 *  2. Franchise subscriptions — monthly/annual billing plans for franchise operators
 *
 * Prices are in PHP centavos (Stripe uses smallest currency unit).
 * PHP does not use sub-units officially but Stripe still expects integer amounts.
 */

export const CURRENCY = "php";

/**
 * Franchise subscription plans available for purchase by branch operators.
 * These are created dynamically in Stripe via the checkout session.
 */
export const FRANCHISE_PLANS = [
  {
    id: "basic",
    name: "Basic Plan",
    description: "Single-branch access — inventory, sales, and staff tracking",
    monthlyAmount: 99900, // ₱999/month in centavos
    annualAmount: 999900, // ₱9,999/year in centavos
    features: [
      "1 branch access",
      "Inventory management",
      "POS sales recording",
      "Staff time tracking",
      "Monthly reports",
    ],
  },
  {
    id: "pro",
    name: "Pro Plan",
    description: "Up to 5 branches — full operations management",
    monthlyAmount: 299900, // ₱2,999/month
    annualAmount: 2999900, // ₱29,999/year
    features: [
      "Up to 5 branches",
      "All Basic features",
      "Advanced analytics",
      "Shift management",
      "CSV/PDF exports",
      "Priority support",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise Plan",
    description: "Unlimited branches — full franchise network management",
    monthlyAmount: 599900, // ₱5,999/month
    annualAmount: 5999900, // ₱59,999/year
    features: [
      "Unlimited branches",
      "All Pro features",
      "Custom branding",
      "API access",
      "Dedicated support",
      "SLA guarantee",
    ],
  },
];
