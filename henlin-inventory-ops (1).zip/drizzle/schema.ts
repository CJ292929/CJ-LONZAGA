import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ──────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Branches ───────────────────────────────────────────────────
export const branches = mysqlTable("branches", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  location: varchar("location", { length: 255 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Branch = typeof branches.$inferSelect;

// ─── Products ───────────────────────────────────────────────────
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  category: varchar("category", { length: 80 }),
  unit: varchar("unit", { length: 30 }).default("pcs"),
  price: decimal("price", { precision: 10, scale: 2 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Product = typeof products.$inferSelect;

// ─── Branch Inventory ────────────────────────────────────────────
export const branchInventory = mysqlTable("branch_inventory", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  productId: int("productId").notNull(),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).default("0").notNull(),
  reorderLevel: decimal("reorderLevel", { precision: 12, scale: 2 }).default("10").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type BranchInventory = typeof branchInventory.$inferSelect;

// ─── Inventory Logs ──────────────────────────────────────────────
export const inventoryLogs = mysqlTable("inventory_logs", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  productId: int("productId").notNull(),
  type: mysqlEnum("type", ["stock_in", "stock_out", "sale", "adjustment"]).notNull(),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
  adjustmentReason: mysqlEnum("adjustmentReason", ["damaged", "expired", "transferred", "correction"]),
  reason: text("reason"),
  performedBy: int("performedBy"),
  performedByName: varchar("performedByName", { length: 120 }),
  timestamp: bigint("timestamp", { mode: "number" }).notNull(),
});
export type InventoryLog = typeof inventoryLogs.$inferSelect;

// ─── Sales ───────────────────────────────────────────────────────
export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  shiftId: int("shiftId"),
  cashierName: varchar("cashierName", { length: 120 }),
  paymentType: mysqlEnum("paymentType", ["cash", "GCash", "card"]).default("cash").notNull(),
  totalAmount: decimal("totalAmount", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["completed", "voided"]).default("completed").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  timestamp: bigint("timestamp", { mode: "number" }).notNull(),
});
export type Sale = typeof sales.$inferSelect;

// ─── Sale Items ──────────────────────────────────────────────────
export const saleItems = mysqlTable("sale_items", {
  id: int("id").autoincrement().primaryKey(),
  saleId: int("saleId").notNull(),
  productId: int("productId").notNull(),
  productName: varchar("productName", { length: 120 }).notNull(),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
});
export type SaleItem = typeof saleItems.$inferSelect;

// ─── Staff ───────────────────────────────────────────────────────
export const staff = mysqlTable("staff", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  position: varchar("position", { length: 80 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Staff = typeof staff.$inferSelect;

// ─── Shifts ──────────────────────────────────────────────────────
export const shifts = mysqlTable("shifts", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  date: varchar("date", { length: 20 }).notNull(),
  startTime: varchar("startTime", { length: 8 }).notNull(),
  endTime: varchar("endTime", { length: 8 }).notNull(),
  status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
  openedAt: bigint("openedAt", { mode: "number" }),
  closedAt: bigint("closedAt", { mode: "number" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Shift = typeof shifts.$inferSelect;

// ─── Shift Staff ─────────────────────────────────────────────────
export const shiftStaff = mysqlTable("shift_staff", {
  id: int("id").autoincrement().primaryKey(),
  shiftId: int("shiftId").notNull(),
  staffId: int("staffId").notNull(),
  branchId: int("branchId").notNull(),
});

// ─── Time Records ────────────────────────────────────────────────
export const timeRecords = mysqlTable("time_records", {
  id: int("id").autoincrement().primaryKey(),
  staffId: int("staffId").notNull(),
  branchId: int("branchId").notNull(),
  date: varchar("date", { length: 20 }).notNull(),
  clockIn: bigint("clockIn", { mode: "number" }),
  clockOut: bigint("clockOut", { mode: "number" }),
  breakStart: bigint("breakStart", { mode: "number" }),
  breakEnd: bigint("breakEnd", { mode: "number" }),
  hoursRendered: decimal("hoursRendered", { precision: 6, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type TimeRecord = typeof timeRecords.$inferSelect;

// ─── Branch Accounts ────────────────────────────────────────────────
export const branchAccounts = mysqlTable("branch_accounts", {
  id: int("id").autoincrement().primaryKey(),
  branchId: int("branchId").notNull().unique(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["branch_manager", "staff"]).default("branch_manager").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastLogin: bigint("lastLogin", { mode: "number" }),
});
export type BranchAccount = typeof branchAccounts.$inferSelect;
