CREATE TABLE `branch_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`branchId` int NOT NULL,
	`username` varchar(64) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`role` enum('branch_manager','staff') NOT NULL DEFAULT 'branch_manager',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`lastLogin` bigint,
	CONSTRAINT `branch_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `branch_accounts_branchId_unique` UNIQUE(`branchId`),
	CONSTRAINT `branch_accounts_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `shift_staff` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shiftId` int NOT NULL,
	`staffId` int NOT NULL,
	`branchId` int NOT NULL,
	CONSTRAINT `shift_staff_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `shift_assignments`;--> statement-breakpoint
ALTER TABLE `branch_inventory` MODIFY COLUMN `quantity` decimal(12,2) NOT NULL DEFAULT '0';--> statement-breakpoint
ALTER TABLE `branch_inventory` MODIFY COLUMN `reorderLevel` decimal(12,2) NOT NULL DEFAULT '10';--> statement-breakpoint
ALTER TABLE `branches` MODIFY COLUMN `name` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `inventory_logs` MODIFY COLUMN `type` enum('stock_in','stock_out','sale','adjustment') NOT NULL;--> statement-breakpoint
ALTER TABLE `inventory_logs` MODIFY COLUMN `quantity` decimal(12,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `inventory_logs` MODIFY COLUMN `reason` text;--> statement-breakpoint
ALTER TABLE `inventory_logs` MODIFY COLUMN `performedByName` varchar(120);--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `name` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `category` varchar(80);--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `unit` varchar(30) DEFAULT 'pcs';--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `price` decimal(10,2);--> statement-breakpoint
ALTER TABLE `sale_items` MODIFY COLUMN `productName` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `sale_items` MODIFY COLUMN `quantity` decimal(12,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `sale_items` MODIFY COLUMN `subtotal` decimal(12,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `sales` MODIFY COLUMN `cashierName` varchar(120);--> statement-breakpoint
ALTER TABLE `sales` MODIFY COLUMN `paymentType` enum('cash','GCash','card') NOT NULL DEFAULT 'cash';--> statement-breakpoint
ALTER TABLE `sales` MODIFY COLUMN `totalAmount` decimal(12,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `shifts` MODIFY COLUMN `name` varchar(80) NOT NULL;--> statement-breakpoint
ALTER TABLE `shifts` MODIFY COLUMN `startTime` varchar(8) NOT NULL;--> statement-breakpoint
ALTER TABLE `shifts` MODIFY COLUMN `endTime` varchar(8) NOT NULL;--> statement-breakpoint
ALTER TABLE `staff` MODIFY COLUMN `name` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `staff` MODIFY COLUMN `position` varchar(80);--> statement-breakpoint
ALTER TABLE `time_records` MODIFY COLUMN `hoursRendered` decimal(6,2);--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `sales` ADD `stripePaymentIntentId` varchar(255);--> statement-breakpoint
ALTER TABLE `inventory_logs` DROP COLUMN `referenceId`;--> statement-breakpoint
ALTER TABLE `inventory_logs` DROP COLUMN `createdAt`;--> statement-breakpoint
ALTER TABLE `products` DROP COLUMN `updatedAt`;--> statement-breakpoint
ALTER TABLE `sales` DROP COLUMN `cashierId`;--> statement-breakpoint
ALTER TABLE `sales` DROP COLUMN `createdAt`;--> statement-breakpoint
ALTER TABLE `shifts` DROP COLUMN `openedBy`;--> statement-breakpoint
ALTER TABLE `shifts` DROP COLUMN `closedBy`;--> statement-breakpoint
ALTER TABLE `staff` DROP COLUMN `userId`;--> statement-breakpoint
ALTER TABLE `time_records` DROP COLUMN `shiftId`;--> statement-breakpoint
ALTER TABLE `time_records` DROP COLUMN `status`;--> statement-breakpoint
ALTER TABLE `time_records` DROP COLUMN `notes`;--> statement-breakpoint
ALTER TABLE `time_records` DROP COLUMN `updatedAt`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `branchId`;