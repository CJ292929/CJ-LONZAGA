# Henlin Inventory & Operations Management System - TODO

## Phase 1: Database Schema & Backend
- [x] Design and apply full database schema (branches, products, inventory, sales, staff, shifts, time records, adjustments)
- [x] Create all tRPC routers: branches, products, inventory, sales, staff, shifts, timeRecords, reports
- [x] Seed default branches (13 locations) and default shifts
- [x] Role-based access control (super_admin, branch_manager, staff)

## Phase 2: Core Layout & Branding
- [x] Apply Henlin brand colors (red #C62828, yellow/gold #FFC107) to global CSS
- [x] Henlin logo in top-left of sidebar
- [x] Dark sidebar navigation with all module links
- [x] Branch switcher in header (all branches or specific branch)
- [x] Responsive layout (tablet + desktop)

## Phase 3: Dashboard (Home)
- [x] Summary cards: total sales today, active branches, low stock alerts, total products
- [x] Sales trend area chart (Recharts) — daily/weekly
- [x] Payment type pie chart
- [x] Top products bar chart
- [x] Recent transactions list
- [x] Branch overview table

## Phase 4: Branch Management
- [x] List all 13 branches with status
- [x] Branch detail view with stats (today's sales, low stock)
- [x] Admin branch switcher

## Phase 5: Inventory Management
- [x] Product list table with search, filter, sort
- [x] Add/Edit/Delete product modal (name, category, unit, reorder level)
- [x] Stock quantity display per branch
- [x] Stock-in / Stock-out logging with timestamps
- [x] Low stock alerts (toast + badge)
- [x] Inventory adjustments (damaged, expired, transferred, correction)
- [x] Mass CSV upload for products
- [x] Inventory log history per product

## Phase 6: Sales Recording (POS)
- [x] POS grid — click product to add to cart
- [x] Cart with quantity controls and running total
- [x] Payment type selection (cash, GCash, card)
- [x] Cashier name capture
- [x] Auto-deduct inventory on sale confirmation
- [x] Sales history table with search/filter/sort
- [x] Per-shift running total display

## Phase 7: Staff Time Records
- [x] Clock-in / Clock-out per staff per branch
- [x] Break time recording (break start/end)
- [x] Hours rendered computation (minus break time)
- [x] Status flags: On Duty, Complete, Absent, Overtime, Undertime
- [x] Daily time record table with date selector

## Phase 8: Shift Management
- [x] Define shifts (Morning 06:00–14:00, Afternoon 14:00–22:00 defaults)
- [x] Assign staff to shifts per branch
- [x] Open/close shifts with timestamps
- [x] End-of-shift summary view

## Phase 9: Reports
- [x] Sales Report (per day/branch/all branches; product breakdown; CSV export)
- [x] Inventory Report (stock levels, low-stock alerts)
- [x] Staff Attendance Report (hours, per staff/branch; CSV export)
- [x] Date range filter for all reports
- [x] Branch filter for all reports

## Phase 10: User & Role Management
- [x] Role-based access (admin vs user via Manus OAuth)
- [x] Protected procedures for write operations

## Phase 11: Polish & Testing
- [x] Toast notifications for all actions and alerts
- [x] All tables with search, filter, sort
- [x] Empty states and loading skeletons
- [x] Vitest unit tests: auth, router structure, input validation (12 tests passing)
- [x] Final checkpoint

## Phase 12: Branch Account System
- [x] Add branchAccounts table to schema (username, passwordHash, branchId, role)
- [x] Add branch login/logout/me tRPC procedures with JWT cookie
- [x] Build branch login page (username/password, no Manus OAuth)
- [x] Build BranchSessionContext for branch-account auth state
- [x] Branch-scoped interface: all queries locked to logged-in branch only
- [x] Branch interface hides Super Admin controls (no branch switcher, no all-branches)
- [x] Seed all 13 branch accounts with default credentials
- [x] Super Admin can view/reset branch account credentials

## Phase 13: Stripe Payment Integration
- [ ] Add Stripe feature scaffold (webdev_add_feature)
- [ ] Build createPaymentIntent tRPC procedure for POS card payments
- [ ] Build Stripe webhook handler to confirm payments and update sale status
- [ ] Build subscription plans tRPC procedures (franchise billing)
- [ ] Add Stripe card payment UI to branch Sales POS (card payment type)
- [ ] Add Super Admin Billing/Subscriptions page
- [ ] Test Stripe checkout flow end-to-end
